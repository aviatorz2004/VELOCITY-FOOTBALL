export type Difficulty = "rookie" | "pro" | "legend";
export type MatchMode = "quick" | "career" | "event" | "training" | "online" | "tournament";

export type KeeperStyle = "reader" | "acrobat" | "wall";
export type StrikerStyle = "placement" | "power" | "deceiver";

export interface Opponent {
  id: string;
  club: string;
  short: string;
  captain: string;
  keeper: string;
  keeperStyle: KeeperStyle;
  strikerStyle: StrikerStyle;
  rating: number;
  reward: number;
  color: string;
  description: string;
}

export interface OnlineRecord {
  rating: number;
  wins: number;
  losses: number;
  streak: number;
}

export const divisionFor = (rating: number) =>
  Math.max(1, Math.min(10, 10 - Math.floor((rating - 1000) / 100)));

export const OPPONENTS: Opponent[] = [
  {
    id: "harbor",
    club: "Harbor Athletic",
    short: "HAR",
    captain: "M. Torres",
    keeper: "The Wall",
    keeperStyle: "wall",
    strikerStyle: "power",
    rating: 74,
    reward: 350,
    color: "#65d9ff",
    description: "A direct side. Their keeper guards the centre and their striker favours powerful central finishes.",
  },
  {
    id: "northgate",
    club: "Northgate City",
    short: "NGC",
    captain: "J. Okafor",
    keeper: "The Reader",
    keeperStyle: "reader",
    strikerStyle: "deceiver",
    rating: 79,
    reward: 450,
    color: "#c8ff18",
    description: "Patient and observant. Repeating the same corner makes you easy to read.",
  },
  {
    id: "metro",
    club: "Metro Rovers",
    short: "MET",
    captain: "S. Bennett",
    keeper: "The Acrobat",
    keeperStyle: "acrobat",
    strikerStyle: "placement",
    rating: 83,
    reward: 550,
    color: "#ff875f",
    description: "Explosive and aggressive. Expect full-stretch dives toward the corners.",
  },
  {
    id: "royal",
    club: "Royal Alba",
    short: "ALB",
    captain: "L. Santos",
    keeper: "The Reader",
    keeperStyle: "reader",
    strikerStyle: "placement",
    rating: 87,
    reward: 700,
    color: "#b79cff",
    description: "Technically elite. Their placement is precise and their keeper learns quickly.",
  },
  {
    id: "velocity-xi",
    club: "Velocity XI",
    short: "VXI",
    captain: "A. Morgan",
    keeper: "The Acrobat",
    keeperStyle: "acrobat",
    strikerStyle: "deceiver",
    rating: 92,
    reward: 1000,
    color: "#c8ff18",
    description: "The city's champions. Unpredictable placement and elite reactions demand your best.",
  },
  {
    id: "eastside",
    club: "Eastside United",
    short: "EST",
    captain: "D. Mwangi",
    keeper: "The Wall",
    keeperStyle: "wall",
    strikerStyle: "placement",
    rating: 77,
    reward: 400,
    color: "#ffd166",
    description: "Compact and disciplined. Their keeper protects the middle while their striker picks the corners.",
  },
  {
    id: "coastline",
    club: "Coastline FC",
    short: "CST",
    captain: "R. Haddad",
    keeper: "The Acrobat",
    keeperStyle: "acrobat",
    strikerStyle: "power",
    rating: 81,
    reward: 500,
    color: "#4ef0c2",
    description: "Fast and fearless. Expect spectacular dives and powerful, central finishing.",
  },
];

export const EVENT_STAGES = [
  { opponent: OPPONENTS[1], name: "Qualifiers", reward: 500, unlock: "Volt Strike kit" },
  { opponent: OPPONENTS[2], name: "Semi-final", reward: 800, unlock: "Volt ball trail" },
  { opponent: OPPONENTS[4], name: "City Final", reward: 1500, unlock: "Champions badge" },
];

export interface ShopItem {
  id: string;
  name: string;
  category: "kit" | "gloves" | "trail";
  price: number;
  description: string;
  color: string;
}

export const SHOP_ITEMS: ShopItem[] = [
  {
    id: "classic",
    name: "Classic White",
    category: "kit",
    price: 0,
    description: "The original Velocity match kit.",
    color: "#f1f1e9",
  },
  {
    id: "lime-kit",
    name: "Volt Strike",
    category: "kit",
    price: 1200,
    description: "A high-visibility volt match kit.",
    color: "#c8ff18",
  },
  {
    id: "midnight-kit",
    name: "Midnight Away",
    category: "kit",
    price: 1800,
    description: "Deep navy with an ice-blue trim.",
    color: "#71b7ff",
  },
  {
    id: "pro-gloves",
    name: "Pro Grip Gloves",
    category: "gloves",
    price: 950,
    description: "+10% save chance when you pick the correct zone.",
    color: "#ffcf5a",
  },
  {
    id: "lime-trail",
    name: "Volt Ball Trail",
    category: "trail",
    price: 750,
    description: "Adds a volt streak to every shot you take.",
    color: "#c8ff18",
  },
];

export const ZONE_NAMES = [
  "Top left",
  "Top centre",
  "Top right",
  "Middle left",
  "Centre",
  "Middle right",
  "Bottom left",
  "Bottom centre",
  "Bottom right",
];
