import { useEffect, useState } from "react";
import { ArrowRight, Radio, Search, X } from "lucide-react";
import { divisionFor, type OnlineRecord } from "../gameData";

type Phase = "idle" | "searching" | "unavailable";

interface OnlineMatchmakingProps {
  record: OnlineRecord;
  onClose: () => void;
  playSound: (sound: "whistle") => void;
}

const REGIONS = [
  { id: "AFRICA", hub: "Nairobi hub" },
  { id: "EUROPE", hub: "Frankfurt hub" },
  { id: "AMERICAS", hub: "São Paulo hub" },
  { id: "ASIA", hub: "Singapore hub" },
];

const clock = (seconds: number) =>
  `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;

export default function OnlineMatchmaking({ record, onClose, playSound }: OnlineMatchmakingProps) {
  const [phase, setPhase] = useState<Phase>("idle");
  const [region, setRegion] = useState(REGIONS[0].id);
  const [elapsed, setElapsed] = useState(0);
  const division = divisionFor(record.rating);

  const startSearch = () => {
    setElapsed(0);
    setPhase("searching");
  };

  useEffect(() => {
    if (phase !== "searching") return;
    const startedAt = Date.now();
    const ticker = window.setInterval(() => setElapsed(Math.floor((Date.now() - startedAt) / 1000)), 250);
    const finder = window.setTimeout(() => {
      setPhase("unavailable");
      playSound("whistle");
    }, 2400 + Math.random() * 1800);
    return () => {
      window.clearInterval(ticker);
      window.clearTimeout(finder);
    };
  }, [phase]);

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <section
        className="modal online-modal"
        role="dialog"
        aria-modal="true"
        aria-label="Online match"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="modal-header">
          <div>
            <span className="eyebrow">03 / RANKED SHOOTOUT</span>
            <h2>ONLINE MATCH</h2>
          </div>
          <button className="modal-close push" onClick={onClose} aria-label="Close online match"><X size={18} /></button>
        </div>

        <div className="online-stats">
          <div><strong>{record.rating.toLocaleString("en-US")}</strong><span>SKILL RATING</span></div>
          <div><strong>{division}</strong><span>DIVISION</span></div>
          <div><strong>{record.wins}–{record.losses}</strong><span>WIN / LOSS</span></div>
          <div><strong>{record.streak}</strong><span>WIN STREAK</span></div>
        </div>

        {phase === "idle" && (
          <div className="online-body">
            <span className="region-label">SELECT MATCHMAKING REGION</span>
            <div className="region-picker">
              {REGIONS.map((item) => (
                <button
                  key={item.id}
                  className={region === item.id ? "selected" : ""}
                  onClick={() => setRegion(item.id)}
                  aria-pressed={region === item.id}
                >
                  {item.id}
                  <small>{item.hub}</small>
                </button>
              ))}
            </div>
            <button className="primary-action online-find" autoFocus onClick={startSearch}><Search size={15} /> FIND MATCH</button>
            <p className="online-note">Prototype preview · the online feature is under construction.</p>
          </div>
        )}

        {phase === "searching" && (
          <div className="online-body">
            <div className="radar" aria-hidden="true" />
            <div className="search-status">
              <strong>SEARCHING FOR A RIVAL</strong>
              <span>{region} · Division {Math.max(1, division - 1)}–{Math.min(10, division + 1)}</span>
            </div>
            <span className="search-timer" aria-live="polite">{clock(elapsed)}</span>
            <button className="secondary-action" onClick={() => setPhase("idle")}>CANCEL SEARCH</button>
          </div>
        )}

        {phase === "unavailable" && (
          <div className="online-body online-unavailable">
            <span className="cup-result-icon muted"><Radio size={24} /></span>
            <span className="eyebrow">FEATURE UNAVAILABLE</span>
            <div className="search-status">
              <strong>ONLINE MATCH COMING SOON</strong>
              <span>Feature hii haipo kwa sasa. Itapatikana kwenye toleo linalofuata.</span>
              <span>Online matchmaking is not available yet — it will arrive in a future Velocity Football update.</span>
            </div>
            <button className="primary-action" onClick={onClose}>GOT IT <ArrowRight size={14} /></button>
          </div>
        )}
      </section>
    </div>
  );
}
