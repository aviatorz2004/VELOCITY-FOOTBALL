import { useEffect, useState } from "react";
import { ArrowLeft, Flag, Play, ShieldCheck, User } from "lucide-react";

export type FieldPosition = "GK" | "DEF" | "MID" | "FWD";

export interface PlayerProfileInput {
  name: string;
  club: string;
  number: number;
  position: FieldPosition;
}

interface RegistrationScreenProps {
  defaultClub: string;
  onBack: () => void;
  onComplete: (profile: PlayerProfileInput) => void;
}

const POSITIONS: FieldPosition[] = ["GK", "DEF", "MID", "FWD"];
const POSITION_LABELS: Record<FieldPosition, string> = {
  GK: "Goalkeeper",
  DEF: "Defender",
  MID: "Midfielder",
  FWD: "Forward",
};

const initialsOf = (value: string, fallback: string) => {
  const letters = value
    .trim()
    .split(/\s+/)
    .map((word) => word[0])
    .filter(Boolean)
    .slice(0, 3)
    .join("")
    .toUpperCase();
  return letters || fallback;
};

export default function RegistrationScreen({ defaultClub, onBack, onComplete }: RegistrationScreenProps) {
  const [name, setName] = useState("");
  const [club, setClub] = useState(defaultClub);
  const [number, setNumber] = useState(9);
  const [position, setPosition] = useState<FieldPosition>("FWD");
  const [touched, setTouched] = useState(false);

  const trimmedName = name.trim();
  const trimmedClub = club.trim() || defaultClub;
  const validName = trimmedName.length >= 2;
  const initials = initialsOf(trimmedName, "VF");
  const short = initialsOf(trimmedClub, "VF");

  const submit = () => {
    setTouched(true);
    if (!validName) return;
    onComplete({
      name: trimmedName,
      club: trimmedClub,
      number: Math.min(99, Math.max(1, number || 1)),
      position,
    });
  };

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (event.key === "Escape") {
        event.preventDefault();
        onBack();
        return;
      }
      if (event.key === "Enter" && !target?.closest("button, select")) {
        event.preventDefault();
        submit();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  });

  return (
    <section className="register-screen" aria-label="Player registration">
      <button className="register-back" onClick={onBack}>
        <ArrowLeft size={13} /> BACK
      </button>

      <div className="register-layout">
        <div className="register-intro">
          <span className="eyebrow"><span />VELOCITY FOOTBALL / NEW PLAYER REGISTRATION</span>
          <h2>CREATE YOUR<br /><em>PLAYER.</em></h2>
          <p>
            Before you step onto the pitch, register your in-game identity. Your name, club and kit number
            appear across every screen, and everything is stored locally on this device.
          </p>
          <ul className="register-points">
            <li>
              <User size={14} />
              <span><strong>PROFILE EVERYWHERE</strong>Shown in the header, career hub and profile card.</span>
            </li>
            <li>
              <Flag size={14} />
              <span><strong>YOUR CLUB IDENTITY</strong>Your club name and crest code follow you into every mode.</span>
            </li>
            <li>
              <ShieldCheck size={14} />
              <span><strong>LOCAL &amp; PRIVATE</strong>Nothing is uploaded; clear your browser data to reset.</span>
            </li>
          </ul>
        </div>

        <form
          className="register-card"
          onSubmit={(event) => {
            event.preventDefault();
            submit();
          }}
        >
          <div className="register-card-head">
            <span className="register-avatar" aria-hidden="true">{validName ? initials : "VF"}</span>
            <span className="register-crest" aria-hidden="true">{short}</span>
            <div>
              <strong>{validName ? trimmedName.toUpperCase() : "NEW PLAYER"}</strong>
              <small>{trimmedClub.toUpperCase()} · #{number} · {position}</small>
            </div>
          </div>

          <label className="register-field">
            <span>DISPLAY NAME <em>*</em></span>
            <input
              className="register-input"
              value={name}
              onChange={(event) => setName(event.target.value)}
              onBlur={() => setTouched(true)}
              placeholder="E.G. DENISE MCGREGOR"
              autoFocus
              maxLength={22}
              aria-label="Display name"
              autoComplete="name"
            />
          </label>

          <label className="register-field">
            <span>CLUB NAME</span>
            <input
              className="register-input"
              value={club}
              onChange={(event) => setClub(event.target.value)}
              placeholder={defaultClub}
              maxLength={24}
              aria-label="Club name"
            />
          </label>

          <div className="register-row">
            <label className="register-field">
              <span>SHIRT NUMBER</span>
              <input
                className="register-input"
                type="number"
                min={1}
                max={99}
                value={number}
                onChange={(event) => setNumber(Number(event.target.value))}
                aria-label="Shirt number"
              />
            </label>
            <div className="register-field">
              <span>PREFERRED POSITION</span>
              <div className="register-positions" role="group" aria-label="Preferred position">
                {POSITIONS.map((item) => (
                  <button
                    key={item}
                    type="button"
                    className={position === item ? "selected" : ""}
                    onClick={() => setPosition(item)}
                    aria-pressed={position === item}
                    title={POSITION_LABELS[item]}
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <span className="register-error" role="alert">
            {touched && !validName ? "Display name needs at least 2 characters." : ""}
          </span>

          <button type="submit" className="primary-action register-submit" disabled={!trimmedName}>
            <Play size={15} /> REGISTER &amp; ENTER THE PITCH
          </button>

          <span className="register-note">
            <ShieldCheck size={12} /> Saved on this device only — no account or server required.
          </span>
        </form>
      </div>
    </section>
  );
}
