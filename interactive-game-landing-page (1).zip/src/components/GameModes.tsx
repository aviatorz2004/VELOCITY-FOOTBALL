import { useEffect, useRef, type CSSProperties } from "react";
import {
  BriefcaseBusiness,
  ChevronRight,
  Trophy,
  Volleyball,
  Wifi,
  WifiOff,
  Zap,
  type LucideIcon,
} from "lucide-react";
import ScreenHeading from "./ScreenHeading";

export type ModeTileId = "quick" | "career" | "online" | "tournament" | "training";
type ArrowKey = "ArrowLeft" | "ArrowRight" | "ArrowUp" | "ArrowDown";

interface ModeTile {
  id: ModeTileId;
  number: string;
  title: string;
  description?: string;
  icon: LucideIcon;
  network: "offline" | "online";
  column: number;
}

export const MODE_TILES: ModeTile[] = [
  {
    id: "quick",
    number: "01",
    title: "QUICK MATCH",
    description: "Jump straight into the action with your favorite clubs.",
    icon: Zap,
    network: "offline",
    column: 0,
  },
  { id: "career", number: "02", title: "CAREER MODE", icon: BriefcaseBusiness, network: "offline", column: 1 },
  { id: "online", number: "03", title: "ONLINE MATCH", icon: Wifi, network: "online", column: 2 },
  { id: "tournament", number: "04", title: "TOURNAMENT", icon: Trophy, network: "offline", column: 1 },
  { id: "training", number: "05", title: "TRAINING", icon: Volleyball, network: "offline", column: 2 },
];

const ARROWS: ArrowKey[] = ["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"];

/** Spatial navigation that follows the visual bento layout. */
const NAVIGATION: Partial<Record<ArrowKey, number>>[] = [
  { ArrowRight: 1 },
  { ArrowLeft: 0, ArrowRight: 2, ArrowDown: 3 },
  { ArrowLeft: 1, ArrowDown: 4 },
  { ArrowLeft: 0, ArrowRight: 4, ArrowUp: 1 },
  { ArrowLeft: 3, ArrowUp: 2 },
];

interface GameModesProps {
  selected: number;
  interactive: boolean;
  onSelect: (index: number) => void;
  onActivate: (index: number) => void;
  onBack: () => void;
}

export default function GameModes({ selected, interactive, onSelect, onActivate, onBack }: GameModesProps) {
  const tileRefs = useRef<(HTMLButtonElement | null)[]>([]);

  useEffect(() => {
    if (!interactive) return;
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target?.closest("input, select, textarea")) return;

      if (ARROWS.includes(event.key as ArrowKey)) {
        event.preventDefault();
        const next = NAVIGATION[selected]?.[event.key as ArrowKey];
        if (next !== undefined) {
          onSelect(next);
          tileRefs.current[next]?.focus();
        }
        return;
      }

      if ((event.key === "Enter" || event.code === "Space") && !target?.closest("button, a, summary")) {
        event.preventDefault();
        onActivate(selected);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [interactive, selected, onSelect, onActivate]);

  const activeColumn = MODE_TILES[selected]?.column ?? 0;

  return (
    <section className="modes-screen" aria-label="Game modes">
      <ScreenHeading
        eyebrow="VELOCITY FOOTBALL"
        title="GAME MODES"
        subtitle="Every match. Your story."
        index="02"
        onBack={onBack}
      />

      <div className="modes-grid">
        {MODE_TILES.map((tile, index) => {
          const Icon = tile.icon;
          return (
            <button
              key={tile.id}
              ref={(element) => {
                tileRefs.current[index] = element;
              }}
              className={`mode-tile mode-tile-${tile.id} ${selected === index ? "is-selected" : ""}`}
              style={{ "--i": index } as CSSProperties}
              onClick={() => onActivate(index)}
              onMouseEnter={() => onSelect(index)}
              onFocus={() => onSelect(index)}
            >
              <span className="mode-tile-media" aria-hidden="true" />
              <span className="mode-tile-top">
                <Icon className="mode-tile-icon" size={18} strokeWidth={1.8} aria-hidden="true" />
                <span className={`network-badge network-${tile.network}`}>
                  {tile.network === "online" ? <Wifi size={9} /> : <WifiOff size={9} />}
                  {tile.network.toUpperCase()}
                </span>
              </span>
              <span className="mode-tile-bottom">
                <span className="mode-tile-copy">
                  <small>{tile.number}</small>
                  <strong>{tile.title}</strong>
                  {tile.description && <em>{tile.description}</em>}
                </span>
                <ChevronRight className="mode-tile-arrow" size={14} aria-hidden="true" />
              </span>
            </button>
          );
        })}
      </div>

      <div className="modes-rail" aria-hidden="true">
        {[0, 1, 2].map((column) => (
          <span key={column} className={activeColumn === column ? "active" : ""} />
        ))}
      </div>
    </section>
  );
}
