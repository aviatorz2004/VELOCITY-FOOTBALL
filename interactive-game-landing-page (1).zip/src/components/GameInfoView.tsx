import { useEffect, useRef, useState } from "react";
import VelocityLogo from "./VelocityLogo";
import {
  ArrowLeft,
  ChevronRight,
  ExternalLink,
  Globe,
  ShieldCheck,
  Scale,
  Users,
  Code,
  Palette,
  Headphones,
  Bug,
  Heart,
  Gamepad2,
  Keyboard,
  Dumbbell,
  Swords,
  Shield,
  Trophy,
  Monitor,
  Sparkles,
  Award,
  Layers,
  Flame,
  Building2,
  Mail,
  Crown,
  Flag,
  Lightbulb,
  Cpu,
} from "lucide-react";

export type InfoTab = "overview" | "controls" | "changelog";
export type InfoSubpage = "credits" | "privacy" | "terms" | null;

const GAME_NAME = "Velocity Football";
const STUDIO_NAME = "McGregor Studio";
const FOUNDER_NAME = "McGregor Denise";
const OFFICIAL_SITE = "velocityfootball.com";
const OFFICIAL_SITE_URL = "https://velocityfootball.com";

interface GameInfoViewProps {
  onBack: () => void;
  onTrainingLaunch: () => void;
  showToast: (title: string, detail: string) => void;
}

export default function GameInfoView({ onBack, onTrainingLaunch, showToast }: GameInfoViewProps) {
  const [activeTab, setActiveTab] = useState<InfoTab>("overview");
  const [subpage, setSubpage] = useState<InfoSubpage>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Scroll back to the top whenever the subpage or tab changes
  useEffect(() => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollTop = 0;
    }
  }, [subpage, activeTab]);

  // ESC inside a subpage returns to the main Game Info page first
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && subpage !== null) {
        e.preventDefault();
        e.stopPropagation();
        setSubpage(null);
      }
    };
    window.addEventListener("keydown", handleKeyDown, true);
    return () => window.removeEventListener("keydown", handleKeyDown, true);
  }, [subpage]);

  const announceWebsite = () => {
    showToast("Official Website", `Opening ${OFFICIAL_SITE} in a new browser tab…`);
  };

  // =========================================================================
  // 1. CREDITS DEDICATED VIEW
  // =========================================================================
  if (subpage === "credits") {
    return (
      <section className="content-view info-subpage-view credits-view" aria-label="Game Credits">
        <div className="view-heading">
          <button
            className="back-button highlight-back"
            onClick={() => setSubpage(null)}
            aria-label="Return to Game Info"
          >
            <ArrowLeft size={16} /> BACK TO GAME INFO
          </button>
          <div>
            <span className="eyebrow"><span />PRODUCTION & TALENT CREDITS</span>
            <h1>GAME CREDITS</h1>
          </div>
          <div className="view-heading-aside">
            <span className="developer-tag">
              <Sparkles size={12} /> DEVELOPED BY: <strong>{STUDIO_NAME.toUpperCase()}</strong>
            </span>
          </div>
        </div>

        <div className="subpage-scroll-container glass-panel" ref={scrollContainerRef}>
          {/* Studio Banner */}
          <div className="credits-hero-banner">
            <div className="credits-hero-badge">
              <Award size={28} className="text-lime" />
            </div>
            <div className="credits-hero-content">
              <span className="eyebrow text-lime">AAA FOOTBALL PRODUCTION</span>
              <h2>{GAME_NAME.toUpperCase()}</h2>
              <p>
                Crafted with unwavering dedication to competitive precision, football culture, and fluid responsiveness.
              </p>
              <div className="developer-spotlight">
                <span className="spotlight-label">LEAD GAME STUDIO</span>
                <span className="spotlight-studio">Developed by: <strong>{STUDIO_NAME}</strong></span>
              </div>
            </div>
          </div>

          {/* Founder Spotlight */}
          <div className="founder-spotlight">
            <span className="founder-monogram" aria-hidden="true">MD</span>
            <div className="founder-copy">
              <span className="founder-eyebrow"><Crown size={12} /> FOUNDER SPOTLIGHT</span>
              <h3>{FOUNDER_NAME}</h3>
              <p>
                Founder, creator and lead engineer of {GAME_NAME} — the vision and the engineering behind every kick.
              </p>
            </div>
            <ul className="founder-roles" aria-label={`${FOUNDER_NAME}'s roles`}>
              <li><Flag size={14} /><span><small>ROLE</small>Founder</span></li>
              <li><Lightbulb size={14} /><span><small>ROLE</small>Creator</span></li>
              <li><Cpu size={14} /><span><small>ROLE</small>Lead Engineer</span></li>
            </ul>
          </div>

          {/* Credits Grid */}
          <div className="credits-disciplines-grid">
            {/* 1. Game Design */}
            <div className="credit-card">
              <div className="credit-card-header">
                <Gamepad2 size={18} className="credit-icon" />
                <h3>Game Design</h3>
              </div>
              <ul className="credit-members">
                <li className="is-founder">
                  <strong>Game Creator</strong>
                  <span>{FOUNDER_NAME}</span>
                </li>
                <li>
                  <strong>Lead Game Designer</strong>
                  <span>Kiran Mercer</span>
                </li>
                <li>
                  <strong>Match Mechanics & Physics Lead</strong>
                  <span>Tariq Al-Mansoor</span>
                </li>
                <li>
                  <strong>Economy & Progression Balancing</strong>
                  <span>Elena Rostova</span>
                </li>
                <li>
                  <strong>Shootout Scenario Designer</strong>
                  <span>Marcus Vance</span>
                </li>
              </ul>
            </div>

            {/* 2. Game Development */}
            <div className="credit-card">
              <div className="credit-card-header">
                <Code size={18} className="credit-icon" />
                <h3>Game Development</h3>
              </div>
              <ul className="credit-members">
                <li className="is-founder">
                  <strong>Founder & Lead Engineer</strong>
                  <span>{FOUNDER_NAME}</span>
                </li>
                <li>
                  <strong>Lead Gameplay Developer</strong>
                  <span>Darius Sterling</span>
                </li>
                <li>
                  <strong>Match Simulation Architecture</strong>
                  <span>Siddharth Rao</span>
                </li>
                <li>
                  <strong>State Management & Data Persistence</strong>
                  <span>Amina Diallo</span>
                </li>
              </ul>
            </div>

            {/* 3. Programming */}
            <div className="credit-card">
              <div className="credit-card-header">
                <Layers size={18} className="credit-icon" />
                <h3>Programming</h3>
              </div>
              <ul className="credit-members">
                <li>
                  <strong>Engine & Systems Programmer</strong>
                  <span>Jonas Lindqvist</span>
                </li>
                <li>
                  <strong>Goalkeeper AI & Pattern Recognition</strong>
                  <span>Chloe Chen</span>
                </li>
                <li>
                  <strong>Ball Kinematics & Trajectory Logic</strong>
                  <span>Mateo Fernandez</span>
                </li>
                <li>
                  <strong>Input Latency & Timing Systems</strong>
                  <span>Devon Brooks</span>
                </li>
              </ul>
            </div>

            {/* 4. UI/UX Design */}
            <div className="credit-card">
              <div className="credit-card-header">
                <Palette size={18} className="credit-icon" />
                <h3>UI/UX Design</h3>
              </div>
              <ul className="credit-members">
                <li>
                  <strong>Lead UI/UX Architect</strong>
                  <span>Maya Lindemann</span>
                </li>
                <li>
                  <strong>HUD & Motion Graphics Designer</strong>
                  <span>Julian Thorne</span>
                </li>
                <li>
                  <strong>Design System & Typography Lead</strong>
                  <span>Sophia Kim</span>
                </li>
                <li>
                  <strong>Accessibility & Contrast Specialist</strong>
                  <span>Oliver Hayes</span>
                </li>
              </ul>
            </div>

            {/* 5. 3D Art & Graphics */}
            <div className="credit-card">
              <div className="credit-card-header">
                <Building2 size={18} className="credit-icon" />
                <h3>3D Art & Graphics</h3>
              </div>
              <ul className="credit-members">
                <li>
                  <strong>Lead Stadium & Environment Artist</strong>
                  <span>Lucas Van Dijk</span>
                </li>
                <li>
                  <strong>Lighting & Atmospheric Shader Lead</strong>
                  <span>Andrei Volkov</span>
                </li>
                <li>
                  <strong>Character Kits & Visual Assets</strong>
                  <span>Nia Washington</span>
                </li>
                <li>
                  <strong>Post-Processing & Vignette Effects</strong>
                  <span>Liam O&apos;Connor</span>
                </li>
              </ul>
            </div>

            {/* 6. Animation */}
            <div className="credit-card">
              <div className="credit-card-header">
                <Flame size={18} className="credit-icon" />
                <h3>Animation</h3>
              </div>
              <ul className="credit-members">
                <li>
                  <strong>Lead Motion & Kinematics Director</strong>
                  <span>Rafael Mendoza</span>
                </li>
                <li>
                  <strong>Goalkeeper Diving & Save Animations</strong>
                  <span>Sora Takahashi</span>
                </li>
                <li>
                  <strong>Striker Run-up & Power Striking Poses</strong>
                  <span>Gabriel Silva</span>
                </li>
                <li>
                  <strong>Dynamic Net Physics & Rebound Motion</strong>
                  <span>Hannah Weber</span>
                </li>
              </ul>
            </div>

            {/* 7. Audio & Sound Design */}
            <div className="credit-card">
              <div className="credit-card-header">
                <Headphones size={18} className="credit-icon" />
                <h3>Audio & Sound Design</h3>
              </div>
              <ul className="credit-members">
                <li>
                  <strong>Audio Director & Composer</strong>
                  <span>Caleb Sterling</span>
                </li>
                <li>
                  <strong>Dynamic Match Acoustic Engineer</strong>
                  <span>Leila Benali</span>
                </li>
                <li>
                  <strong>Ball Strike & Woodwork Sound FX</strong>
                  <span>Eirik Haaland</span>
                </li>
                <li>
                  <strong>Synthesizer & UI Sound Palette</strong>
                  <span>Zane Takahashi</span>
                </li>
              </ul>
            </div>

            {/* 8. Quality Assurance & Testing */}
            <div className="credit-card">
              <div className="credit-card-header">
                <Bug size={18} className="credit-icon" />
                <h3>Quality Assurance & Testing</h3>
              </div>
              <ul className="credit-members">
                <li>
                  <strong>Lead QA Engineer</strong>
                  <span>Dominic Clarke</span>
                </li>
                <li>
                  <strong>Game Balance & AI Exploit Analyst</strong>
                  <span>Farah Mansour</span>
                </li>
                <li>
                  <strong>Multi-Platform & Input Verification</strong>
                  <span>Sean Murphy</span>
                </li>
                <li>
                  <strong>Beta Playtest Community Group</strong>
                  <span>{GAME_NAME} Playtest Community</span>
                </li>
              </ul>
            </div>

            {/* 9. Special Thanks */}
            <div className="credit-card credit-card-special">
              <div className="credit-card-header">
                <Heart size={18} className="credit-icon text-lime" />
                <h3>Special Thanks</h3>
              </div>
              <ul className="credit-members">
                <li>
                  <strong>Community & Supporters</strong>
                  <span>Every player who has stepped up to the penalty spot worldwide</span>
                </li>
                <li>
                  <strong>Football Culture & Heritage</strong>
                  <span>The iconic clubs, legendary keepers, and unforgettable shootouts</span>
                </li>
                <li>
                  <strong>Technology Partners</strong>
                  <span>The open source React, Vite, Tailwind & Web Audio communities</span>
                </li>
                <li>
                  <strong>Tactical Advisors</strong>
                  <span>Professional coaching staff and goalkeeper specialists</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Credits Footer */}
          <div className="credits-footer">
            <div className="credits-footer-seal">
              <VelocityLogo height={30} />
              <div>
                <strong>{GAME_NAME.toUpperCase()}</strong>
                <small>
                  DEVELOPED BY {STUDIO_NAME.toUpperCase()} • FOUNDED BY {FOUNDER_NAME.toUpperCase()}
                </small>
              </div>
            </div>
            <p className="credits-copyright">
              Built with precision by {STUDIO_NAME}. All rights reserved. Unauthorized copying, reverse engineering,
              or redistribution is strictly prohibited.
            </p>
            <button className="primary-action" onClick={() => setSubpage(null)}>
              <ArrowLeft size={14} /> RETURN TO GAME INFO
            </button>
          </div>
        </div>
      </section>
    );
  }

  // =========================================================================
  // 2. PRIVACY POLICY DEDICATED VIEW
  // =========================================================================
  if (subpage === "privacy") {
    return (
      <section className="content-view info-subpage-view legal-view" aria-label="Privacy Policy">
        <div className="view-heading">
          <button
            className="back-button highlight-back"
            onClick={() => setSubpage(null)}
            aria-label="Return to Game Info"
          >
            <ArrowLeft size={16} /> BACK TO GAME INFO
          </button>
          <div>
            <span className="eyebrow"><span />LEGAL & COMPLIANCE</span>
            <h1>PRIVACY POLICY</h1>
          </div>
          <div className="view-heading-aside">
            <span className="policy-badge">
              <ShieldCheck size={13} /> EFFECTIVE: JANUARY 2025 • V2.4
            </span>
          </div>
        </div>

        <div className="subpage-scroll-container glass-panel" ref={scrollContainerRef}>
          <div className="legal-intro-banner">
            <ShieldCheck size={26} className="text-lime" />
            <div>
              <h3>YOUR PRIVACY ON AND OFF THE PITCH</h3>
              <p>
                {GAME_NAME} by {STUDIO_NAME} is engineered with privacy as a foundational principle.
                This Privacy Policy explains what information is collected, how it is handled, and how your player rights are protected.
              </p>
            </div>
          </div>

          <div className="legal-sections-list">
            {/* Section 1 */}
            <article className="legal-section">
              <div className="legal-section-header">
                <span className="section-num">01</span>
                <h2>Introduction</h2>
              </div>
              <p>
                Welcome to {GAME_NAME}, developed by {STUDIO_NAME} (&quot;we&quot;, &quot;our&quot;, or &quot;us&quot;). We are committed to
                protecting the personal privacy of all players who access our application, website, and related game services.
                This Privacy Policy outlines our transparent approach to data management, telemetry, and player records.
              </p>
              <p>
                By downloading, loading, or playing {GAME_NAME}, you acknowledge that you understand and agree to the practices
                described herein. We do not sell player data, execute unauthorized tracking, or share identifiable information with third-party data brokers.
              </p>
            </article>

            {/* Section 2 */}
            <article className="legal-section">
              <div className="legal-section-header">
                <span className="section-num">02</span>
                <h2>Information We Collect</h2>
              </div>
              <p>
                {GAME_NAME} is primarily architected as an offline-first, client-rendered experience. The information we handle falls into the following categories:
              </p>
              <ul className="legal-bullets">
                <li>
                  <strong>Locally Stored Game Data:</strong> Player level, XP earned, virtual coin balances, unlocked kits and cosmetics, career fixtures, tournament state, and penalty shot placement history.
                </li>
                <li>
                  <strong>Client Configuration Preferences:</strong> Visual graphic quality tier, master/SFX volume levels, audio mute preferences, camera shake settings, and accessibility/reduced-motion toggles.
                </li>
                <li>
                  <strong>Anonymized Telemetry:</strong> Hardware frame rate statistics, input latency logs, and crash stack traces used strictly to optimize performance across devices.
                </li>
              </ul>
            </article>

            {/* Section 3 */}
            <article className="legal-section">
              <div className="legal-section-header">
                <span className="section-num">03</span>
                <h2>How We Use Information</h2>
              </div>
              <p>
                All data collected or stored is utilized solely to deliver and elevate the authentic football gaming experience:
              </p>
              <ul className="legal-bullets">
                <li>Preserving seamless career, tournament, and weekly progression across your browser and hardware sessions.</li>
                <li>Balancing goalkeeper reaction curves and striker AI difficulty curves to ensure fair and competitive matches.</li>
                <li>Enabling instant match resumes, accurate coin expenditure in the Club Shop, and verifiable achievement logs.</li>
                <li>Diagnosing rendering issues and memory utilization across varied display sizes and mobile browsers.</li>
              </ul>
            </article>

            {/* Section 4 */}
            <article className="legal-section">
              <div className="legal-section-header">
                <span className="section-num">04</span>
                <h2>Data Protection</h2>
              </div>
              <p>
                We employ industry-standard security measures to safeguard all stored records against unauthorized alteration, disclosure, or loss.
                All game state keys are isolated within sandboxed browser storage or device local directories.
              </p>
              <p>
                Because {GAME_NAME} minimizes cloud data transmission, your profile records remain within your direct possession and control.
                No third-party advertising tracking scripts or behavioral cookies are embedded within the core game experience.
              </p>
            </article>

            {/* Section 5 */}
            <article className="legal-section">
              <div className="legal-section-header">
                <span className="section-num">05</span>
                <h2>Account Information</h2>
              </div>
              <p>
                Your display name and club identity (chosen during first-launch registration) are managed locally. You have the perpetual right to:
              </p>
              <ul className="legal-bullets">
                <li>Review your full match statistics, goals, win ratios, and division standings at any time via the Player Profile modal.</li>
                <li>Purge or reset your local save file directly through browser settings or the game options menu.</li>
                <li>Request clarification regarding any future cloud-linked account services introduced in upcoming title updates.</li>
              </ul>
            </article>

            {/* Section 6 */}
            <article className="legal-section">
              <div className="legal-section-header">
                <span className="section-num">06</span>
                <h2>Online Services</h2>
              </div>
              <p>
                Ranked matchmaking and multiplayer lobbies within {GAME_NAME} operate under fair-play protocols.
                When connecting to online lobbies or simulated regional hubs (e.g., Nairobi, Frankfurt, São Paulo, Singapore),
                connection parameters such as approximate ping and matchmaking Skill Rating (SR) are evaluated solely to form balanced pairings.
              </p>
              <p>
                We maintain zero tolerance for harassment, cheating, memory injection, or griefing across all connected gameplay experiences.
              </p>
            </article>

            {/* Section 7 */}
            <article className="legal-section">
              <div className="legal-section-header">
                <span className="section-num">07</span>
                <h2>Contact Information</h2>
              </div>
              <p>
                For any inquiries, requests for data clarification, or questions regarding this Privacy Policy, please reach out to the {STUDIO_NAME} team:
              </p>
              <div className="contact-box">
                <div className="contact-row">
                  <Mail size={16} className="text-lime" />
                  <span>Privacy Inquiries: <strong>privacy@{OFFICIAL_SITE}</strong></span>
                </div>
                <div className="contact-row">
                  <Globe size={16} className="text-lime" />
                  <span>Official Website: <strong>{OFFICIAL_SITE}</strong></span>
                </div>
                <div className="contact-row">
                  <Building2 size={16} className="text-lime" />
                  <span>Developer Studio: <strong>{STUDIO_NAME}</strong></span>
                </div>
              </div>
            </article>
          </div>

          <div className="legal-footer-bar">
            <span>{GAME_NAME.toUpperCase()} PRIVACY POLICY • {STUDIO_NAME.toUpperCase()}</span>
            <button className="primary-action" onClick={() => setSubpage(null)}>
              <ArrowLeft size={14} /> RETURN TO GAME INFO
            </button>
          </div>
        </div>
      </section>
    );
  }

  // =========================================================================
  // 3. TERMS & CONDITIONS DEDICATED VIEW
  // =========================================================================
  if (subpage === "terms") {
    return (
      <section className="content-view info-subpage-view legal-view" aria-label="Terms and Conditions">
        <div className="view-heading">
          <button
            className="back-button highlight-back"
            onClick={() => setSubpage(null)}
            aria-label="Return to Game Info"
          >
            <ArrowLeft size={16} /> BACK TO GAME INFO
          </button>
          <div>
            <span className="eyebrow"><span />END USER LICENSE AGREEMENT</span>
            <h1>TERMS & CONDITIONS</h1>
          </div>
          <div className="view-heading-aside">
            <span className="policy-badge">
              <Scale size={13} /> LAST UPDATED: JANUARY 2025 • V1.8
            </span>
          </div>
        </div>

        <div className="subpage-scroll-container glass-panel" ref={scrollContainerRef}>
          <div className="legal-intro-banner">
            <Scale size={26} className="text-lime" />
            <div>
              <h3>{GAME_NAME.toUpperCase()} TERMS OF SERVICE</h3>
              <p>
                Please read these Terms & Conditions carefully prior to playing {GAME_NAME}.
                These terms govern your access to and use of all gameplay, software, and services provided by {STUDIO_NAME}.
              </p>
            </div>
          </div>

          <div className="legal-sections-list">
            {/* Section 1 */}
            <article className="legal-section">
              <div className="legal-section-header">
                <span className="section-num">01</span>
                <h2>Acceptance of Terms</h2>
              </div>
              <p>
                By accessing, downloading, launching, or playing {GAME_NAME} (the &quot;Game&quot;), you acknowledge that you have read,
                understood, and agree to be legally bound by these Terms & Conditions and all applicable laws and regulations.
                If you do not agree to these terms in their entirety, you must discontinue access immediately.
              </p>
            </article>

            {/* Section 2 */}
            <article className="legal-section">
              <div className="legal-section-header">
                <span className="section-num">02</span>
                <h2>User Accounts</h2>
              </div>
              <p>
                Players are responsible for maintaining the confidentiality of their local save state and hardware access.
                You agree to provide true and accurate player handles and acknowledge that all profile progression, trophies, and tournament
                milestones are tied to your device&apos;s authenticated storage. {STUDIO_NAME} is not liable for data loss resulting from cleared browser cache.
              </p>
            </article>

            {/* Section 3 */}
            <article className="legal-section">
              <div className="legal-section-header">
                <span className="section-num">03</span>
                <h2>Game Usage Rules</h2>
              </div>
              <p>
                To maintain an enjoyable and competitive pitch environment for everyone, you agree that you will not:
              </p>
              <ul className="legal-bullets">
                <li>Deploy automated bots, macro scripts, or input manipulation software to gain unfair timing advantages on penalty meters.</li>
                <li>Decompile, disassemble, reverse engineer, or modify any portion of the game&apos;s source code or compiled bundles.</li>
                <li>Exploit unintended bugs, glitches, or save-state manipulation for fraudulent coin multiplication or leaderboard manipulation.</li>
                <li>Impersonate game moderators, studio representatives, or professional players in online lobbies.</li>
              </ul>
            </article>

            {/* Section 4 */}
            <article className="legal-section">
              <div className="legal-section-header">
                <span className="section-num">04</span>
                <h2>Subscriptions and Payments</h2>
              </div>
              <p>
                {GAME_NAME} features in-game virtual currency (&quot;Coins&quot;) earned exclusively through gameplay achievements,
                match victories, weekly club grants, and tournament triumphs. Virtual coins possess zero real-world cash value,
                cannot be redeemed for fiat currency, and remain strictly for cosmetic kit, glove, and match trail unlocks within the Club Shop.
              </p>
              <p>
                Any potential future premium passes or digital add-ons will be clearly itemized with explicit confirmation before transaction completion.
              </p>
            </article>

            {/* Section 5 */}
            <article className="legal-section">
              <div className="legal-section-header">
                <span className="section-num">05</span>
                <h2>Online Gameplay</h2>
              </div>
              <p>
                All participants in ranked matchmaking, online friendlies, or regional tournaments must uphold standard sportsmanship.
                Intentional match disconnection, abusive conduct, or griefing during penalty shootouts will be recorded and may result
                in Skill Rating (SR) penalties or matchmaking timeouts.
              </p>
            </article>

            {/* Section 6 */}
            <article className="legal-section">
              <div className="legal-section-header">
                <span className="section-num">06</span>
                <h2>Intellectual Property</h2>
              </div>
              <p>
                All rights, titles, and interests in and to {GAME_NAME}—including but not limited to the codebase, 3D stadium renders,
                original UI designs, audio compositions, brand marks, kit aesthetics, and tournament structures—are the exclusive intellectual
                property of <strong>{STUDIO_NAME}</strong> and its licensors.
              </p>
              <p>
                You are granted a non-exclusive, revocable, non-transferable personal license to play the Game for entertainment purposes only.
              </p>
            </article>

            {/* Section 7 */}
            <article className="legal-section">
              <div className="legal-section-header">
                <span className="section-num">07</span>
                <h2>Account Suspension</h2>
              </div>
              <p>
                {STUDIO_NAME} reserves the right, in its sole discretion and without prior notice, to restrict, suspend, or terminate access
                to online lobbies or game features for any player who violates these Terms & Conditions or engages in activities disruptive
                to the community.
              </p>
            </article>

            {/* Section 8 */}
            <article className="legal-section">
              <div className="legal-section-header">
                <span className="section-num">08</span>
                <h2>Changes to Terms</h2>
              </div>
              <p>
                We may revise, update, or expand these Terms & Conditions periodically to reflect gameplay balances, legal requirements,
                or feature enhancements. Any material revisions will be reflected in the Game Info section and accompanying patch notes.
                Continued use of the Game following notice represents acceptance of updated terms.
              </p>
            </article>

            {/* Section 9 */}
            <article className="legal-section">
              <div className="legal-section-header">
                <span className="section-num">09</span>
                <h2>Contact Information</h2>
              </div>
              <p>
                If you have questions, feedback, or legal inquiries regarding these Terms & Conditions, please contact:
              </p>
              <div className="contact-box">
                <div className="contact-row">
                  <Mail size={16} className="text-lime" />
                  <span>Legal Inquiries: <strong>legal@{OFFICIAL_SITE}</strong></span>
                </div>
                <div className="contact-row">
                  <Globe size={16} className="text-lime" />
                  <span>Official Website: <strong>{OFFICIAL_SITE}</strong></span>
                </div>
                <div className="contact-row">
                  <Building2 size={16} className="text-lime" />
                  <span>Developer Studio: <strong>{STUDIO_NAME}</strong></span>
                </div>
              </div>
            </article>
          </div>

          <div className="legal-footer-bar">
            <span>{GAME_NAME.toUpperCase()} TERMS & CONDITIONS • DEVELOPED BY {STUDIO_NAME.toUpperCase()}</span>
            <button className="primary-action" onClick={() => setSubpage(null)}>
              <ArrowLeft size={14} /> RETURN TO GAME INFO
            </button>
          </div>
        </div>
      </section>
    );
  }

  // =========================================================================
  // MAIN GAME INFO VIEW
  // =========================================================================
  return (
    <section className="content-view info-view" aria-label="Game Info">
      <div className="view-heading">
        <button className="back-button" onClick={onBack}>
          <ArrowLeft size={16} /> BACK
        </button>
        <div>
          <span className="eyebrow"><span />{GAME_NAME.toUpperCase()} / VERSION 1.1</span>
          <h1>GAME INFO</h1>
        </div>
        <div className="view-heading-aside">
          <span className="developer-tag">
            <Sparkles size={12} /> DEVELOPED BY: <strong>{STUDIO_NAME.toUpperCase()}</strong>
          </span>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="info-tabs">
        {([
          { id: "overview", label: "OVERVIEW" },
          { id: "controls", label: "CONTROLS" },
          { id: "changelog", label: "PATCH NOTES" },
        ] as { id: InfoTab; label: string }[]).map((tab) => (
          <button
            key={tab.id}
            className={activeTab === tab.id ? "selected" : ""}
            onClick={() => setActiveTab(tab.id)}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div className="info-content glass-panel" ref={scrollContainerRef}>
        {/* Four featured sections: Credits, Privacy Policy, Terms & Conditions, Official Website */}
        <div className="game-info-featured-grid">
          {/* Card 1: CREDITS */}
          <article className="info-feature-card info-card-credits" onClick={() => setSubpage("credits")}>
            <div className="feature-card-top">
              <span className="feature-icon-badge">
                <Users size={20} className="text-lime" />
              </span>
              <span className="card-badge">PRODUCTION TALENT</span>
            </div>
            <div className="feature-card-body">
              <span className="feature-eyebrow">STUDIO & CREDITS</span>
              <h3>GAME CREDITS</h3>
              <p>
                Meet {FOUNDER_NAME} — founder, creator and lead engineer — and the team behind {GAME_NAME}.
              </p>
              <div className="card-developer-credit">
                <span>DEVELOPED BY:</span> <strong>{STUDIO_NAME}</strong>
              </div>
            </div>
            <div className="feature-card-footer">
              <span className="action-link">
                VIEW CREDITS <ChevronRight size={13} />
              </span>
            </div>
          </article>

          {/* Card 2: PRIVACY POLICY */}
          <article className="info-feature-card info-card-privacy" onClick={() => setSubpage("privacy")}>
            <div className="feature-card-top">
              <span className="feature-icon-badge">
                <ShieldCheck size={20} className="text-lime" />
              </span>
              <span className="card-badge">COMPLIANCE</span>
            </div>
            <div className="feature-card-body">
              <span className="feature-eyebrow">DATA & TRANSPARENCY</span>
              <h3>PRIVACY POLICY</h3>
              <p>Learn how your local game data, telemetry, and player privacy are protected by {STUDIO_NAME}.</p>
              <div className="card-meta-notes">
                <span>7 Sections • Version 2.4</span>
              </div>
            </div>
            <div className="feature-card-footer">
              <span className="action-link">
                READ PRIVACY POLICY <ChevronRight size={13} />
              </span>
            </div>
          </article>

          {/* Card 3: TERMS & CONDITIONS */}
          <article className="info-feature-card info-card-terms" onClick={() => setSubpage("terms")}>
            <div className="feature-card-top">
              <span className="feature-icon-badge">
                <Scale size={20} className="text-lime" />
              </span>
              <span className="card-badge">EULA & RULES</span>
            </div>
            <div className="feature-card-body">
              <span className="feature-eyebrow">AGREEMENT & CODE</span>
              <h3>TERMS & CONDITIONS</h3>
              <p>Read end user license terms, fair play conduct, account ownership, and rules of engagement.</p>
              <div className="card-meta-notes">
                <span>9 Sections • Updated 2025</span>
              </div>
            </div>
            <div className="feature-card-footer">
              <span className="action-link">
                READ TERMS <ChevronRight size={13} />
              </span>
            </div>
          </article>

          {/* Card 4: OFFICIAL WEBSITE */}
          <article className="info-feature-card info-card-website">
            <div className="feature-card-top">
              <span className="feature-icon-badge website-icon-badge">
                <Globe size={22} className="text-lime" />
              </span>
              <span className="card-badge live-web-badge">
                <span className="live-pulse" /> OFFICIAL WEB
              </span>
            </div>
            <div className="feature-card-body">
              <span className="feature-eyebrow">NEWS & COMMUNITY</span>
              <h3>OFFICIAL WEBSITE</h3>
              <p>Get the latest {GAME_NAME} news, updates and announcements from {STUDIO_NAME}.</p>
              <div className="website-url-box">
                <Globe size={13} className="text-lime" />
                <span className="url-text">{OFFICIAL_SITE}</span>
              </div>
              <small className="external-disclaimer">
                Opens {OFFICIAL_SITE} in a new browser tab.
              </small>
            </div>
            <div className="feature-card-footer">
              <a
                className="primary-action visit-website-btn"
                href={OFFICIAL_SITE_URL}
                target="_blank"
                rel="noopener noreferrer"
                onClick={announceWebsite}
                aria-label={`Visit the official ${GAME_NAME} website at ${OFFICIAL_SITE} (opens in a new tab)`}
              >
                <Globe size={14} /> VISIT WEBSITE <ExternalLink size={13} />
              </a>
            </div>
          </article>
        </div>

        {/* Tab 1: OVERVIEW */}
        {activeTab === "overview" && (
          <div className="tab-pane-container">
            <div className="overview-grid">
              <div>
                <span className="eyebrow"><span />PLAY BEYOND LIMITS</span>
                <h2>EVERY KICK<br />TELLS A STORY.</h2>
                <p>
                  {GAME_NAME} is a focused arcade football experience built around the most decisive moment
                  in the game: the penalty shootout.
                </p>
                <p>
                  Read opponent tendencies, vary your placement, master the moving power gauge, then take your turn in goal.
                  Career results, cup runs, ranked rating, coins, XP, and equipment are all saved locally.
                </p>
              </div>
              <div className="feature-list">
                <div>
                  <Swords size={18} />
                  <span><strong>FIVE GAME MODES</strong>Quick match, career, online, tournament, and training.</span>
                </div>
                <div>
                  <Shield size={18} />
                  <span><strong>REACTIVE OPPONENTS</strong>Keepers read patterns; strikers adapt to your dives.</span>
                </div>
                <div>
                  <Trophy size={18} />
                  <span><strong>MEANINGFUL PROGRESSION</strong>Win coins, climb divisions, lift cups, and equip real gameplay boosts.</span>
                </div>
                <div>
                  <Monitor size={18} />
                  <span><strong>LOCAL & PRIVATE</strong>No account or server. Progress stays in this browser.</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: CONTROLS */}
        {activeTab === "controls" && (
          <div className="tab-pane-container">
            <div className="controls-grid">
              <div>
                <div className="panel-title"><span><Keyboard size={16} /> KEYBOARD</span></div>
                {[
                  ["ARROW KEYS", "Navigate menus and mode cards"],
                  ["ENTER / SPACE", "Select / take action"],
                  ["1 — 9", "Select a goal zone directly"],
                  ["SPACE", "Shoot or dive"],
                  ["ESC", "Back / leave match"],
                ].map(([key, action]) => (
                  <div className="control-row" key={key}>
                    <kbd>{key}</kbd>
                    <span>{action}</span>
                  </div>
                ))}
              </div>
              <div>
                <div className="panel-title"><span><Gamepad2 size={16} /> MOUSE & TOUCH</span></div>
                <p>
                  Every action also supports pointer input. Select any of the nine zones inside the goal,
                  time your power, and use the Shoot or Dive button.
                </p>
                <div className="power-explainer">
                  <span className="power-demo"><i /></span>
                  <p>
                    <strong>MASTER THE SWEET SPOT</strong>The centre lime band gives you the best balance of power and control.
                    Very low or maximum power can send the ball off target.
                  </p>
                </div>
                <button className="primary-action" onClick={onTrainingLaunch}>
                  <Dumbbell size={15} /> OPEN TRAINING
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: PATCH NOTES */}
        {activeTab === "changelog" && (
          <div className="tab-pane-container">
            <div className="patch-list">
              <details open>
                <summary>
                  <span>VERSION 1.1</span> THE MODES & INFO EXPANSION <small>CURRENT</small>
                </summary>
                <ul>
                  <li>Added a dedicated Game Credits view featuring founder {FOUNDER_NAME} and the {STUDIO_NAME} team.</li>
                  <li>Added full interactive Privacy Policy and Terms & Conditions pages.</li>
                  <li>Added an Official Website link to {OFFICIAL_SITE}.</li>
                  <li>Redesigned the Game Modes hub with five dedicated modes.</li>
                  <li>Added the eight-club {GAME_NAME} Cup knockout tournament.</li>
                  <li>Added ranked online-style matches with skill rating and divisions.</li>
                  <li>Added a Quick Match kick-off setup with opponent and difficulty selection.</li>
                </ul>
              </details>
              <details>
                <summary><span>VERSION 1.0</span> THE OPENING WHISTLE</summary>
                <ul>
                  <li>Added five-round shootouts with early wins and sudden death.</li>
                  <li>Added Reader, Acrobat, and Wall goalkeeper behaviours.</li>
                  <li>Added placement, power, and deceiver striker tendencies.</li>
                  <li>Added persistent career, city event, inventory, XP, and coins.</li>
                </ul>
              </details>
              <details>
                <summary><span>LOCAL SAVE</span> YOUR DATA</summary>
                <p>
                  Progress is stored using this browser&apos;s local storage. No information is transmitted.
                  Clearing site data will reset your career and inventory.
                </p>
              </details>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
