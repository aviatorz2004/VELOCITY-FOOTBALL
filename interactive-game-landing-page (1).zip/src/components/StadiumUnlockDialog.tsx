import { createPortal } from "react-dom";
import { Coins, Lock, MapPin, Users } from "lucide-react";
import { STADIUMS } from "../matchdaySettings";
import "./MatchdaySettings.css";

type Stadium = (typeof STADIUMS)[number];

interface StadiumUnlockDialogProps {
  stadium: Stadium;
  coins: number;
  onConfirm: () => void;
  onCancel: () => void;
}

const money = (value: number) => value.toLocaleString("en-US");

export default function StadiumUnlockDialog({ stadium, coins, onConfirm, onCancel }: StadiumUnlockDialogProps) {
  const canAfford = coins >= stadium.price;
  // On phones the matchday screen scrolls, which would carry an absolutely positioned dialog out of view.
  // Rendering into the game screen itself keeps the dialog covering the whole screen wherever the player has scrolled.
  const host = document.querySelector<HTMLElement>(".game-screen") ?? document.body;

  return createPortal(
    <div className="modal-backdrop mdv-unlock-backdrop" onClick={onCancel}>
      <section
        className="modal mdv-unlock"
        role="dialog"
        aria-modal="true"
        aria-labelledby="mdv-unlock-title"
        aria-describedby="mdv-unlock-copy"
        data-stadium={stadium.id}
        onClick={(event) => event.stopPropagation()}
      >
        <span className="mdv-unlock-image" role="img" aria-label={stadium.imageDescription}>
          <span className="mdv-unlock-lock"><Lock size={18} /></span>
        </span>

        <div className="mdv-unlock-body">
          <span className="eyebrow">LOCKED VENUE</span>
          <h2 id="mdv-unlock-title">Unlock {stadium.name}?</h2>
          <p id="mdv-unlock-copy">
            <span><MapPin size={11} /> {stadium.city}, {stadium.country}</span>
            <span><Users size={11} /> {stadium.capacity} seats</span>
            <span>{stadium.atmosphere}</span>
          </p>

          <dl className="mdv-unlock-ledger">
            <div><dt>Your balance</dt><dd><Coins size={12} /> {money(coins)}</dd></div>
            <div><dt>Stadium price</dt><dd className="cost">− {money(stadium.price)}</dd></div>
            <div className="total">
              <dt>Balance after</dt>
              <dd className={canAfford ? "" : "short"}>{canAfford ? money(coins - stadium.price) : "Not enough"}</dd>
            </div>
          </dl>

          {!canAfford && (
            <p className="mdv-unlock-warning" role="alert">
              You need <strong>{money(stadium.price - coins)}</strong> more coins. Win matches to earn coins, then come back.
            </p>
          )}

          <div className="mdv-unlock-actions">
            <button type="button" className="secondary-action" autoFocus={!canAfford} onClick={onCancel}>NOT NOW</button>
            <button type="button" className="primary-action" autoFocus={canAfford} disabled={!canAfford} onClick={onConfirm}>
              <Coins size={14} /> UNLOCK FOR {money(stadium.price)}
            </button>
          </div>
        </div>
      </section>
    </div>,
    host,
  );
}
