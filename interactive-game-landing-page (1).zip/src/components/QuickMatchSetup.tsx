import { useEffect, useState } from "react";
import { ChevronLeft, ChevronRight, Coins, Play, Shield, Shuffle, Target, User, X } from "lucide-react";
import { OPPONENTS, type Difficulty } from "../gameData";

interface QuickMatchSetupProps {
  initialIndex: number;
  difficulty: Difficulty;
  kitColor: string;
  clubName?: string;
  clubShort?: string;
  playerOvr: number;
  onDifficultyChange: (difficulty: Difficulty) => void;
  onClose: () => void;
  onKickOff: (index: number) => void;
}

const DIFFICULTY_COPY: Record<Difficulty, string> = {
  rookie: "Slower keeper reads and more forgiving strikers.",
  pro: "Balanced reactions with smart pattern reading.",
  legend: "Elite keepers, a faster power meter, and clinical strikers.",
};

export default function QuickMatchSetup({
  initialIndex,
  difficulty,
  kitColor,
  clubName = "VELOCITY FC",
  clubShort = "VF",
  playerOvr,
  onDifficultyChange,
  onClose,
  onKickOff,
}: QuickMatchSetupProps) {
  const [index, setIndex] = useState(() => Math.min(Math.max(initialIndex, 0), OPPONENTS.length - 1));
  const opponent = OPPONENTS[index];

  const cycle = (direction: number) =>
    setIndex((current) => (current + direction + OPPONENTS.length) % OPPONENTS.length);

  const randomise = () =>
    setIndex((current) => {
      let next = current;
      while (next === current) next = Math.floor(Math.random() * OPPONENTS.length);
      return next;
    });

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "ArrowLeft" || event.key === "ArrowRight") {
        event.preventDefault();
        cycle(event.key === "ArrowLeft" ? -1 : 1);
      }
      if (event.key === "Enter" && !(event.target as HTMLElement | null)?.closest("button")) {
        event.preventDefault();
        onKickOff(index);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [index, onKickOff]);

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <section
        className="modal setup-modal"
        role="dialog"
        aria-modal="true"
        aria-label="Quick match setup"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="modal-header">
          <div>
            <span className="eyebrow">01 / KICK-OFF SETUP</span>
            <h2>QUICK MATCH</h2>
          </div>
          <button className="modal-close push" onClick={onClose} aria-label="Close quick match setup">
            <X size={18} />
          </button>
        </div>

        <div className="setup-versus">
          <div className="setup-team">
            <span className="setup-crest" style={{ background: kitColor }}>{clubShort}</span>
            <strong>{clubName.toUpperCase()}</strong>
            <small>YOU · OVR {playerOvr}</small>
          </div>

          <div className="setup-vs">
            <span>VS</span>
            <small>PENALTY SHOOTOUT</small>
          </div>

          <div className="setup-team">
            <div className="setup-cycle">
              <button onClick={() => cycle(-1)} aria-label="Previous opponent"><ChevronLeft size={15} /></button>
              <span
                key={opponent.id}
                className="setup-crest outline"
                style={{ color: opponent.color, borderColor: opponent.color }}
              >
                {opponent.short}
              </span>
              <button onClick={() => cycle(1)} aria-label="Next opponent"><ChevronRight size={15} /></button>
            </div>
            <strong>{opponent.club.toUpperCase()}</strong>
            <small>OVR {opponent.rating}</small>
            <div className="setup-dots">
              {OPPONENTS.map((item, itemIndex) => (
                <button
                  key={item.id}
                  className={itemIndex === index ? "active" : ""}
                  onClick={() => setIndex(itemIndex)}
                  aria-label={`Select ${item.club}`}
                  aria-pressed={itemIndex === index}
                />
              ))}
            </div>
          </div>
        </div>

        <p className="setup-description">{opponent.description}</p>

        <div className="scout-grid setup-scout">
          <div><Shield size={15} /><span>KEEPER<strong>{opponent.keeper}</strong></span></div>
          <div><Target size={15} /><span>STRIKER<strong>{opponent.strikerStyle}</strong></span></div>
          <div><User size={15} /><span>CAPTAIN<strong>{opponent.captain}</strong></span></div>
          <div><Coins size={15} /><span>WIN REWARD<strong>{opponent.reward.toLocaleString("en-US")} coins</strong></span></div>
        </div>

        <div className="setup-difficulty">
          <div>
            <strong>Difficulty</strong>
            <small>{DIFFICULTY_COPY[difficulty]}</small>
          </div>
          <div className="segmented-control">
            {(["rookie", "pro", "legend"] as Difficulty[]).map((level) => (
              <button
                key={level}
                className={difficulty === level ? "selected" : ""}
                onClick={() => onDifficultyChange(level)}
              >
                {level.toUpperCase()}
              </button>
            ))}
          </div>
        </div>

        <div className="setup-footer">
          <button className="text-button" onClick={randomise}><Shuffle size={13} /> RANDOM OPPONENT</button>
          <div>
            <button className="secondary-action" onClick={onClose}>CANCEL</button>
            <button className="primary-action" autoFocus onClick={() => onKickOff(index)}><Play size={14} /> KICK OFF</button>
          </div>
        </div>
      </section>
    </div>
  );
}
