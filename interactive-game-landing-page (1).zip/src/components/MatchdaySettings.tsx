import { useEffect, useLayoutEffect, useRef, useState, type KeyboardEvent, type PointerEvent } from "react";
import {
  ArrowLeftRight,
  Building2,
  Check,
  ChevronLeft,
  ChevronRight,
  Clock3,
  Coins,
  Lock,
  MapPin,
  Shield,
  SlidersHorizontal,
} from "lucide-react";
import {
  FREE_STADIUM_IDS,
  MATCH_DURATIONS,
  OPPONENT_LEVELS,
  STADIUMS,
  getOpponentLevel,
  getStadium,
  type MatchdayPreferences,
  type StadiumId,
} from "../matchdaySettings";
import "./MatchdaySettings.css";

interface MatchdaySettingsProps {
  value: MatchdayPreferences;
  onChange: (preferences: MatchdayPreferences) => void;
  matchType: "friendly" | "penalty";
  coins: number;
  unlockedStadiums: readonly StadiumId[];
  /** Called when the player taps a stadium they do not own yet. */
  onRequestUnlock: (id: StadiumId) => void;
}

const money = (amount: number) => amount.toLocaleString("en-US");

export default function MatchdaySettings({ value, onChange, matchType, coins, unlockedStadiums, onRequestUnlock }: MatchdaySettingsProps) {
  const trackRef = useRef<HTMLDivElement>(null);
  const cardRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const dragRef = useRef<{ pointerId: number; startX: number; startScroll: number } | null>(null);
  const suppressClick = useRef(false);
  const initialIndex = useRef(STADIUMS.findIndex((stadium) => stadium.id === value.stadiumId));
  const [dragging, setDragging] = useState(false);
  const [canScroll, setCanScroll] = useState({ previous: false, next: true });

  const owns = (id: StadiumId) => unlockedStadiums.includes(id);
  const selectedIndex = STADIUMS.findIndex((stadium) => stadium.id === value.stadiumId);
  const selectedStadium = getStadium(value.stadiumId);
  const selectedLevel = getOpponentLevel(value.opponentDifficulty);
  const ownedCount = STADIUMS.filter((stadium) => owns(stadium.id)).length;

  const scrollBehavior = (): ScrollBehavior =>
    trackRef.current?.closest(".reduce-motion") || window.matchMedia("(prefers-reduced-motion: reduce)").matches
      ? "auto"
      : "smooth";

  const revealStadium = (index: number, behavior: ScrollBehavior = scrollBehavior()) => {
    const track = trackRef.current;
    const card = cardRefs.current[index];
    if (!track || !card) return;
    track.scrollTo({ left: card.offsetLeft - (track.clientWidth - card.offsetWidth) / 2, behavior });
  };

  /** Owned stadiums are selected right away; locked ones open the purchase dialog instead. */
  const chooseStadium = (index: number) => {
    const stadium = STADIUMS[index];
    if (!stadium) return;
    revealStadium(index);
    if (!owns(stadium.id)) {
      onRequestUnlock(stadium.id);
      return;
    }
    onChange({ ...value, stadiumId: stadium.id });
  };

  const browseStadiums = (direction: -1 | 1) => {
    const track = trackRef.current;
    if (!track) return;
    const stride = (cardRefs.current[0]?.offsetWidth ?? track.clientWidth * 0.46) + 12;
    track.scrollBy({ left: direction * stride, behavior: scrollBehavior() });
  };

  useLayoutEffect(() => {
    revealStadium(initialIndex.current, "auto");
  }, []);

  useEffect(() => {
    const track = trackRef.current;
    if (!track) return;
    const updateEdges = () => {
      const next = {
        previous: track.scrollLeft > 3,
        next: track.scrollLeft < track.scrollWidth - track.clientWidth - 3,
      };
      setCanScroll((previous) => previous.previous === next.previous && previous.next === next.next ? previous : next);
    };
    const onWheel = (event: WheelEvent) => {
      if (event.ctrlKey || Math.abs(event.deltaX) > Math.abs(event.deltaY)) return;
      const canMove = event.deltaY > 0
        ? track.scrollLeft < track.scrollWidth - track.clientWidth - 3
        : track.scrollLeft > 3;
      if (!canMove) return;
      event.preventDefault();
      track.scrollLeft += event.deltaY;
    };
    const observer = new ResizeObserver(updateEdges);
    observer.observe(track);
    track.addEventListener("scroll", updateEdges, { passive: true });
    track.addEventListener("wheel", onWheel, { passive: false });
    updateEdges();
    return () => {
      observer.disconnect();
      track.removeEventListener("scroll", updateEdges);
      track.removeEventListener("wheel", onWheel);
    };
  }, []);

  const onPointerDown = (event: PointerEvent<HTMLDivElement>) => {
    suppressClick.current = false;
    if (event.pointerType !== "mouse" || event.button !== 0) return;
    dragRef.current = { pointerId: event.pointerId, startX: event.clientX, startScroll: event.currentTarget.scrollLeft };
  };

  const onPointerMove = (event: PointerEvent<HTMLDivElement>) => {
    const drag = dragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) return;
    const distance = event.clientX - drag.startX;
    if (Math.abs(distance) < 6 && !suppressClick.current) return;
    suppressClick.current = true;
    setDragging(true);
    if (!event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.setPointerCapture(event.pointerId);
    event.preventDefault();
    event.currentTarget.scrollLeft = drag.startScroll - distance;
  };

  const endDrag = (event: PointerEvent<HTMLDivElement>) => {
    dragRef.current = null;
    setDragging(false);
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
    // The click that follows a drag is swallowed once. Clear the flag straight afterwards so a keyboard Enter still works.
    window.setTimeout(() => { suppressClick.current = false; }, 0);
  };

  const radioNavigation = (event: KeyboardEvent<HTMLElement>, index: number, count: number, select: (next: number) => void) => {
    let next = index;
    if (event.key === "ArrowRight" || event.key === "ArrowDown") next = (index + 1) % count;
    else if (event.key === "ArrowLeft" || event.key === "ArrowUp") next = (index + count - 1) % count;
    else if (event.key === "Home") next = 0;
    else if (event.key === "End") next = count - 1;
    else return;
    event.preventDefault();
    select(next);
  };

  // Arrow keys only move focus along the stadium rail, so browsing never spends coins by accident.
  // Enter or Space on a focused venue selects it, or opens the purchase dialog when it is locked.
  const moveStadiumFocus = (index: number) => {
    cardRefs.current[index]?.focus({ preventScroll: true });
    revealStadium(index);
  };

  return (
    <section className="mdv-settings" aria-label="Stadium and match settings">
      <header className="mdv-heading">
        <div>
          <span className="mdv-eyebrow">01 / MATCHDAY VENUE</span>
          <h2>CHOOSE YOUR GROUND.</h2>
        </div>
        <div className="mdv-browse">
          <span className="mdv-wallet" aria-label={`${money(coins)} coins`}><Coins size={13} /><b>{money(coins)}</b><small>COINS</small></span>
          <span className="mdv-swipe-hint"><ArrowLeftRight size={12} /> SWIPE TO EXPLORE</span>
          <span className="mdv-count"><b>{String(selectedIndex + 1).padStart(2, "0")}</b> / {String(STADIUMS.length).padStart(2, "0")}</span>
          <button type="button" className="mdv-arrow" aria-label="Previous stadiums" disabled={!canScroll.previous} onClick={() => browseStadiums(-1)}><ChevronLeft size={17} /></button>
          <button type="button" className="mdv-arrow" aria-label="Next stadiums" disabled={!canScroll.next} onClick={() => browseStadiums(1)}><ChevronRight size={17} /></button>
        </div>
      </header>

      <div
        className="mdv-stadium-track"
        ref={trackRef}
        role="radiogroup"
        aria-label="Choose a stadium"
        data-dragging={dragging || undefined}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={endDrag}
        onPointerCancel={endDrag}
        onLostPointerCapture={() => { dragRef.current = null; setDragging(false); }}
        onClickCapture={(event) => {
          if (suppressClick.current) {
            event.preventDefault();
            event.stopPropagation();
          }
        }}
      >
        {STADIUMS.map((stadium, index) => {
          const unlocked = owns(stadium.id);
          const isSelected = unlocked && stadium.id === value.stadiumId;
          const isStarter = (FREE_STADIUM_IDS as readonly string[]).includes(stadium.id);
          const shortfall = stadium.price - coins;
          const status = isStarter ? "free starter venue" : unlocked ? "unlocked" : `locked, ${money(stadium.price)} coins`;
          return (
            <button
              type="button"
              key={stadium.id}
              ref={(element) => { cardRefs.current[index] = element; }}
              className={`mdv-stadium-card ${isSelected ? "is-selected" : ""} ${unlocked ? "" : "is-locked"}`}
              data-stadium={stadium.id}
              role="radio"
              aria-checked={isSelected}
              aria-label={`${stadium.name}, ${stadium.city}, ${stadium.atmosphere}, ${status}`}
              tabIndex={isSelected ? 0 : -1}
              onClick={() => chooseStadium(index)}
              onKeyDown={(event) => radioNavigation(event, index, STADIUMS.length, moveStadiumFocus)}
            >
              <span className="mdv-stadium-media">
                <span className="mdv-stadium-image" role="img" aria-label={stadium.imageDescription} />
                {unlocked ? (
                  <span className={`mdv-tag ${isStarter ? "starter" : "owned"}`}>{isStarter ? "FREE STARTER" : <><Check size={10} /> UNLOCKED</>}</span>
                ) : (
                  <span className="mdv-lock-badge"><Lock size={14} /></span>
                )}
              </span>
              <span className="mdv-venue-content">
                <span className="mdv-venue-location"><MapPin size={11} /> {stadium.city}, {stadium.country}</span>
                <span className="mdv-venue-title">
                  <strong>{stadium.name}</strong>
                  <i className="mdv-venue-check" aria-hidden="true">{isSelected ? <Check size={15} /> : unlocked ? <PlusMark /> : <Lock size={12} />}</i>
                </span>
                <span className="mdv-venue-meta"><span>{stadium.atmosphere}</span><span>{stadium.capacity} seats</span></span>
              </span>
              {unlocked ? (
                <span className="mdv-venue-state">{isSelected ? "SELECTED VENUE" : "SELECT VENUE"}<ChevronRight size={11} /></span>
              ) : (
                <span className={`mdv-venue-state is-buy ${shortfall > 0 ? "is-short" : ""}`}>
                  <span>{shortfall > 0 ? `NEED ${money(shortfall)} MORE` : "UNLOCK VENUE"}</span>
                  <span className="mdv-price"><Coins size={11} />{money(stadium.price)}</span>
                </span>
              )}
            </button>
          );
        })}
      </div>

      <div className="mdv-carousel-footer">
        <p><Check size={12} /><span>Playing at <strong>{selectedStadium.name}</strong></span></p>
        <div className="mdv-footer-right">
          <span className="mdv-owned-count"><Lock size={10} /> {ownedCount} / {STADIUMS.length} UNLOCKED</span>
          <div className="mdv-pagination" aria-label="Stadium shortcuts">
            {STADIUMS.map((stadium, index) => {
              const unlocked = owns(stadium.id);
              return (
                <button
                  type="button"
                  key={stadium.id}
                  className={`${selectedIndex === index && unlocked ? "active" : ""} ${unlocked ? "" : "locked"}`}
                  aria-label={unlocked ? `Select ${stadium.name}` : `Unlock ${stadium.name} for ${money(stadium.price)} coins`}
                  aria-pressed={selectedIndex === index && unlocked}
                  onClick={() => chooseStadium(index)}
                />
              );
            })}
          </div>
        </div>
      </div>

      <div className="mdv-rules">
        <fieldset className="mdv-rule-group">
          <legend><Clock3 size={15} /> MATCH DURATION</legend>
          <p id="mdv-duration-help">Total match time, not per half.</p>
          <div className="mdv-duration-options" role="radiogroup" aria-label="Match duration" aria-describedby="mdv-duration-help">
            {MATCH_DURATIONS.map((duration, index) => (
              <button
                type="button"
                key={duration}
                role="radio"
                aria-label={`${duration} minutes`}
                aria-checked={value.durationMinutes === duration}
                tabIndex={value.durationMinutes === duration ? 0 : -1}
                className={value.durationMinutes === duration ? "selected" : ""}
                onClick={() => onChange({ ...value, durationMinutes: duration })}
                onKeyDown={(event) => radioNavigation(event, index, MATCH_DURATIONS.length, (next) => {
                  onChange({ ...value, durationMinutes: MATCH_DURATIONS[next] });
                  (event.currentTarget.parentElement?.children[next] as HTMLButtonElement | undefined)?.focus();
                })}
              >
                <strong>{duration}</strong><small>MIN</small>
              </button>
            ))}
          </div>
          <span className="mdv-rule-foot">{matchType === "penalty" ? "Saved for the match scene. Shootouts keep their five rounds." : "A quick fixture or the full matchday experience. Your call."}</span>
        </fieldset>

        <fieldset className="mdv-rule-group">
          <legend><Shield size={15} /> OPPONENT DIFFICULTY</legend>
          <p>Choose the challenge you want to face.</p>
          <div className="mdv-difficulty-options" role="radiogroup" aria-label="Opponent difficulty" aria-describedby="mdv-difficulty-help">
            {OPPONENT_LEVELS.map((level, index) => (
              <button
                type="button"
                key={level.id}
                role="radio"
                aria-checked={value.opponentDifficulty === level.id}
                aria-label={level.label}
                tabIndex={value.opponentDifficulty === level.id ? 0 : -1}
                className={value.opponentDifficulty === level.id ? "selected" : ""}
                onClick={() => onChange({ ...value, opponentDifficulty: level.id })}
                onKeyDown={(event) => radioNavigation(event, index, OPPONENT_LEVELS.length, (next) => {
                  onChange({ ...value, opponentDifficulty: OPPONENT_LEVELS[next].id });
                  (event.currentTarget.parentElement?.children[next] as HTMLButtonElement | undefined)?.focus();
                })}
              >
                <span className="mdv-level-bars" aria-hidden="true">{[1, 2, 3, 4].map((bar) => <i key={bar} className={bar <= level.rank ? "lit" : ""} />)}</span>
                <strong>{level.label}</strong>
              </button>
            ))}
          </div>
          <span className="mdv-rule-foot" id="mdv-difficulty-help" aria-live="polite">{selectedLevel.description}</span>
        </fieldset>
      </div>

      <footer className="mdv-preview-note"><SlidersHorizontal size={12} /><span>Concept venues for the UI preview. Your choices are included in the Unity match handoff.</span><Building2 size={13} /></footer>
    </section>
  );
}

function PlusMark() {
  return <span className="mdv-plus-mark" />;
}
