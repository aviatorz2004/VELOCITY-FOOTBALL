import { useEffect } from "react";
import VelocityLogo from "./VelocityLogo";

interface TitleScreenProps {
  onContinue: () => void;
}

export default function TitleScreen({ onContinue }: TitleScreenProps) {
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Enter" || event.code === "Space") {
        event.preventDefault();
        onContinue();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [onContinue]);

  return (
    <section
      className="title-screen"
      role="button"
      tabIndex={0}
      aria-label="Velocity Football. Tap to continue."
      onClick={onContinue}
      onKeyDown={(event) => {
        if (event.key === "Enter" || event.code === "Space") {
          event.preventDefault();
          onContinue();
        }
      }}
    >
      <div className="title-screen-glow" aria-hidden="true" />

      <div className="title-screen-brand">
        <VelocityLogo className="title-main-logo" height="clamp(58px, 13vw, 112px)" />
        <span className="title-tagline">OWN THE GAME.</span>
      </div>

      <div className="title-continue">
        <span className="title-continue-line" aria-hidden="true" />
        <span className="title-continue-copy">TAP TO CONTINUE</span>
        <span className="title-continue-line" aria-hidden="true" />
      </div>

      <small className="title-studio">MCGREGOR STUDIO</small>
    </section>
  );
}
