import { useEffect, useRef, useState, type CSSProperties } from "react";
import { ArrowLeft, Crosshair, RotateCcw, Shield, Target, Zap } from "lucide-react";
import Flag from "./Flag";
import {
  ZONE_NAMES,
  type Difficulty,
  type MatchMode,
  type Opponent,
} from "../gameData";

type Phase = "playerAim" | "playerShot" | "opponentAim" | "opponentShot" | "finished";
type Outcome = "goal" | "saved" | "miss";

interface MatchSettings {
  reducedMotion: boolean;
  cameraShake: boolean;
}

interface PenaltyMatchProps {
  opponent: Opponent;
  mode: MatchMode;
  difficulty: Difficulty;
  saveBoost: number;
  trail: boolean;
  kitColor: string;
  clubName?: string;
  clubShort?: string;
  homeFlag?: string;
  awayFlag?: string;
  settings: MatchSettings;
  onExit: () => void;
  onComplete: (result: { won: boolean; playerScore: number; opponentScore: number }) => void;
  playSound: (sound: "whistle" | "kick" | "goal" | "save") => void;
  stageLabel?: string;
  allowRematch?: boolean;
}

const MODE_LABELS: Record<MatchMode, string> = {
  quick: "QUICK MATCH",
  career: "CAREER MODE",
  event: "CHAMPIONS OF THE CITY",
  training: "TRAINING GROUND",
  online: "ONLINE MATCH",
  tournament: "VELOCITY CUP",
};

interface ShotVisual {
  zone: number;
  outcome: Outcome;
  side: "player" | "opponent";
  trail: boolean;
}

const cornerZones = [0, 2, 6, 8];
const centreZones = [1, 4, 7];
const randomFrom = (zones: number[]) => zones[Math.floor(Math.random() * zones.length)];
const randomZone = () => Math.floor(Math.random() * 9);

function mostFrequent(zones: number[]) {
  if (!zones.length) return randomZone();
  const counts = new Map<number, number>();
  zones.forEach((zone) => counts.set(zone, (counts.get(zone) ?? 0) + 1));
  return [...counts.entries()].sort((a, b) => b[1] - a[1])[0][0];
}

function leastFrequent(zones: number[]) {
  const counts = Array.from({ length: 9 }, (_, zone) => ({
    zone,
    count: zones.filter((item) => item === zone).length,
  }));
  const lowest = Math.min(...counts.map((item) => item.count));
  return randomFrom(counts.filter((item) => item.count === lowest).map((item) => item.zone));
}

function chooseKeeperZone(opponent: Opponent, previousZones: number[], difficulty: Difficulty) {
  const readChance = difficulty === "rookie" ? 0.34 : difficulty === "pro" ? 0.56 : 0.7;
  if (opponent.keeperStyle === "reader" && previousZones.length && Math.random() < readChance) {
    const favourite = mostFrequent(previousZones);
    return Math.random() < 0.75 ? favourite : [favourite, (favourite + 3) % 9][Math.floor(Math.random() * 2)];
  }
  if (opponent.keeperStyle === "acrobat" && Math.random() < 0.72) return randomFrom(cornerZones);
  if (opponent.keeperStyle === "wall" && Math.random() < 0.67) return randomFrom(centreZones);
  return randomZone();
}

function chooseStrikerZone(opponent: Opponent, previousDives: number[]) {
  if (opponent.strikerStyle === "placement" && Math.random() < 0.74) return randomFrom(cornerZones);
  if (opponent.strikerStyle === "power" && Math.random() < 0.62) return randomFrom(centreZones);
  if (opponent.strikerStyle === "deceiver" && Math.random() < 0.56) return leastFrequent(previousDives);
  return randomZone();
}

function zoneCoordinates(zone: number) {
  return { x: 25 + (zone % 3) * 25, y: 17 + Math.floor(zone / 3) * 13 };
}

export default function PenaltyMatch({
  opponent,
  mode,
  difficulty,
  saveBoost,
  trail,
  kitColor,
  clubName = "VELOCITY FC",
  clubShort = "VF",
  homeFlag,
  awayFlag,
  settings,
  onExit,
  onComplete,
  playSound,
  stageLabel = "DECISIVE MOMENT",
  allowRematch = true,
}: PenaltyMatchProps) {
  const [phase, setPhase] = useState<Phase>("playerAim");
  const [round, setRound] = useState(1);
  const [selectedZone, setSelectedZone] = useState(4);
  const [keeperZone, setKeeperZone] = useState(4);
  const [playerScore, setPlayerScore] = useState(0);
  const [opponentScore, setOpponentScore] = useState(0);
  const [playerResults, setPlayerResults] = useState<Outcome[]>([]);
  const [opponentResults, setOpponentResults] = useState<Outcome[]>([]);
  const [playerZones, setPlayerZones] = useState<number[]>([]);
  const [diveZones, setDiveZones] = useState<number[]>([]);
  const [visual, setVisual] = useState<ShotVisual | null>(null);
  const [message, setMessage] = useState("Choose your placement. Time the power, then shoot.");
  const [power, setPower] = useState(0.48);
  const powerRef = useRef(0.48);
  const directionRef = useRef(1);
  const timers = useRef<number[]>([]);
  const reported = useRef(false);

  const aiming = phase === "playerAim" || phase === "opponentAim";
  const isPlayerTurn = phase === "playerAim" || phase === "playerShot";

  const later = (callback: () => void, delay: number) => {
    const timer = window.setTimeout(callback, settings.reducedMotion ? Math.min(delay, 450) : delay);
    timers.current.push(timer);
  };

  useEffect(() => {
    return () => timers.current.forEach(window.clearTimeout);
  }, []);

  useEffect(() => {
    if (phase !== "playerAim") return;
    let frame = 0;
    let previous = performance.now();
    const tick = (time: number) => {
      const delta = Math.min((time - previous) / 1000, 0.04);
      previous = time;
      let next = powerRef.current + directionRef.current * delta * (difficulty === "legend" ? 1.05 : 0.78);
      if (next >= 1) {
        next = 1;
        directionRef.current = -1;
      } else if (next <= 0) {
        next = 0;
        directionRef.current = 1;
      }
      powerRef.current = next;
      setPower(next);
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [phase, difficulty]);

  useEffect(() => {
    if (phase === "finished" && !reported.current) {
      reported.current = true;
      onComplete({ won: playerScore > opponentScore, playerScore, opponentScore });
    }
  }, [phase]);

  const selectRelativeZone = (key: string) => {
    const row = Math.floor(selectedZone / 3);
    const column = selectedZone % 3;
    if (key === "ArrowLeft") setSelectedZone(row * 3 + (column + 2) % 3);
    if (key === "ArrowRight") setSelectedZone(row * 3 + (column + 1) % 3);
    if (key === "ArrowUp") setSelectedZone(((row + 2) % 3) * 3 + column);
    if (key === "ArrowDown") setSelectedZone(((row + 1) % 3) * 3 + column);
  };

  const shoot = () => {
    if (phase !== "playerAim") return;
    const shotPower = powerRef.current;
    const targetZone = selectedZone;
    const keeper = chooseKeeperZone(opponent, playerZones, difficulty);
    const wildShot =
      (shotPower < 0.25 && Math.random() < 0.7) ||
      (shotPower > 0.95 && Math.random() < 0.5);
    let outcome: Outcome = "goal";

    if (wildShot) {
      outcome = "miss";
    } else if (keeper === targetZone) {
      const saveChance = (difficulty === "rookie" ? 0.48 : difficulty === "pro" ? 0.64 : 0.76) * (1.05 - shotPower * 0.22);
      if (Math.random() < saveChance) outcome = "saved";
    } else if (
      opponent.keeperStyle === "acrobat" &&
      Math.abs((keeper % 3) - (targetZone % 3)) + Math.abs(Math.floor(keeper / 3) - Math.floor(targetZone / 3)) === 1 &&
      cornerZones.includes(targetZone) &&
      Math.random() < (difficulty === "legend" ? 0.17 : 0.09)
    ) {
      outcome = "saved";
    }

    setPhase("playerShot");
    setKeeperZone(keeper);
    setVisual({ zone: targetZone, outcome, side: "player", trail });
    setPlayerZones((zones) => [...zones, targetZone]);
    setPlayerResults((results) => [...results, outcome]);
    if (outcome === "goal") setPlayerScore((score) => score + 1);
    setMessage(outcome === "goal" ? "GOAL! Perfectly beyond the keeper." : outcome === "saved" ? "SAVED! The keeper read it." : "OFF TARGET! Control the power.");
    playSound("kick");
    later(() => playSound(outcome === "goal" ? "goal" : "save"), 220);
    later(() => {
      setVisual(null);
      setKeeperZone(4);
      setSelectedZone(4);
      setMessage(`${opponent.captain} steps up. Read the striker and choose your dive.`);
      setPhase("opponentAim");
    }, 1150);
  };

  const dive = () => {
    if (phase !== "opponentAim") return;
    const diveZone = selectedZone;
    const targetZone = chooseStrikerZone(opponent, diveZones);
    const missChance = difficulty === "rookie" ? 0.17 : difficulty === "pro" ? 0.1 : 0.055;
    let outcome: Outcome = Math.random() < missChance ? "miss" : "goal";
    if (outcome !== "miss" && diveZone === targetZone) {
      const saveChance = Math.min(0.88, 0.61 + saveBoost + (difficulty === "rookie" ? 0.08 : 0));
      if (Math.random() < saveChance) outcome = "saved";
    }

    const nextOpponentScore = opponentScore + (outcome === "goal" ? 1 : 0);
    setPhase("opponentShot");
    setKeeperZone(diveZone);
    setVisual({ zone: targetZone, outcome, side: "opponent", trail: false });
    setDiveZones((zones) => [...zones, diveZone]);
    setOpponentResults((results) => [...results, outcome]);
    setOpponentScore(nextOpponentScore);
    setMessage(outcome === "saved" ? "WHAT A SAVE! You kept it out." : outcome === "miss" ? "MISSED! The striker drags it wide." : "They score. Reset and go again.");
    playSound("kick");
    later(() => playSound(outcome === "saved" ? "save" : outcome === "goal" ? "goal" : "save"), 220);

    later(() => {
      const kicksLeft = Math.max(0, 5 - round);
      const decidedEarly = round < 5 && round >= 3 && (playerScore > nextOpponentScore + kicksLeft || nextOpponentScore > playerScore + kicksLeft);
      const decidedAfterFive = round >= 5 && playerScore !== nextOpponentScore;
      setVisual(null);
      setKeeperZone(4);
      setSelectedZone(4);
      if (decidedEarly || decidedAfterFive) {
        setMessage(playerScore > nextOpponentScore ? "Victory belongs to Velocity FC." : `${opponent.club} takes the shootout.`);
        setPhase("finished");
        playSound("whistle");
      } else {
        setRound((value) => value + 1);
        setMessage(round >= 5 ? "Sudden death. Choose your placement." : "Choose your placement. Time the power, then shoot.");
        setPhase("playerAim");
      }
    }, 1200);
  };

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        onExit();
        return;
      }
      if (!aiming) return;
      if (["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(event.key)) {
        event.preventDefault();
        selectRelativeZone(event.key);
      }
      if (/^[1-9]$/.test(event.key)) setSelectedZone(Number(event.key) - 1);
      if (event.code === "Space" || event.key === "Enter") {
        event.preventDefault();
        if (phase === "playerAim") shoot();
        if (phase === "opponentAim") dive();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [phase, selectedZone, round, playerScore, opponentScore, aiming]);

  const reset = () => {
    timers.current.forEach(window.clearTimeout);
    timers.current = [];
    reported.current = false;
    setPhase("playerAim");
    setRound(1);
    setSelectedZone(4);
    setKeeperZone(4);
    setPlayerScore(0);
    setOpponentScore(0);
    setPlayerResults([]);
    setOpponentResults([]);
    setPlayerZones([]);
    setDiveZones([]);
    setVisual(null);
    setMessage("Choose your placement. Time the power, then shoot.");
    powerRef.current = 0.48;
    setPower(0.48);
    directionRef.current = 1;
  };

  const target = zoneCoordinates(visual?.zone ?? selectedZone);
  const keeper = zoneCoordinates(keeperZone);
  const won = playerScore > opponentScore;
  const modeLabel = MODE_LABELS[mode];
  const resultTitle =
    mode === "training"
      ? "SESSION COMPLETE"
      : !won
        ? mode === "tournament" ? "KNOCKED OUT." : "SO CLOSE."
        : mode === "event"
          ? "CITY CONQUERED"
          : mode === "tournament"
            ? stageLabel === "FINAL" ? "CUP WINNERS" : "YOU'RE THROUGH"
            : mode === "online" ? "RANKED VICTORY" : "VICTORY IS YOURS";
  const resultCopy =
    mode === "training"
      ? `Training complete: ${playerScore} goals scored. No coins or XP were at stake.`
      : mode === "tournament"
        ? won
          ? stageLabel === "FINAL"
            ? `You beat ${opponent.club} to lift the Velocity Cup.`
            : `You knocked out ${opponent.club}. The bracket has been updated.`
          : `${opponent.club} knock you out of the Velocity Cup. Consolation rewards have been added.`
        : won
          ? `You beat ${opponent.club}. Rewards and progression have been added.`
          : `${opponent.club} wins this one. Your match rewards have still been added.`;

  return (
    <section className={`match-view ${visual && settings.cameraShake ? "match-shake" : ""}`} aria-label="Penalty shootout">
      <div className="match-topbar">
        <button className="icon-text-button" onClick={onExit}><ArrowLeft size={15} /> LEAVE MATCH</button>
        <div className="match-mode-label">{modeLabel} <span>/</span> {stageLabel}</div>
        <div className="difficulty-chip">{difficulty.toUpperCase()}</div>
      </div>

      <div className="scoreboard">
        <div className="score-team score-team-home">
          {homeFlag ? <Flag code={homeFlag} title={clubName} className="score-flag" /> : <span className="team-crest" style={{ background: kitColor }}>{clubShort}</span>}
          <div><strong>{clubName.toUpperCase()}</strong><small>YOU</small></div>
        </div>
        <div className="score-centre">
          <div className="score-numbers"><span>{playerScore}</span><i>—</i><span>{opponentScore}</span></div>
          <div className="round-label">{round > 5 ? "SUDDEN DEATH" : `ROUND ${Math.min(round, 5)} / 5`}</div>
        </div>
        <div className="score-team score-team-away">
          <div><strong>{opponent.club.toUpperCase()}</strong><small>{opponent.captain.toUpperCase()}</small></div>
          {awayFlag ? <Flag code={awayFlag} title={opponent.club} className="score-flag" /> : <span className="team-crest" style={{ background: opponent.color }}>{opponent.short}</span>}
        </div>
      </div>

      <div className="shootout-history" aria-label="Shootout history">
        <div><span>YOU</span>{Array.from({ length: Math.max(5, playerResults.length) }, (_, index) => <i key={index} className={playerResults[index] ? `kick-${playerResults[index]}` : ""}>{playerResults[index] === "goal" ? "G" : playerResults[index] === "saved" ? "S" : playerResults[index] === "miss" ? "M" : ""}</i>)}</div>
        <div><span>{opponent.short}</span>{Array.from({ length: Math.max(5, opponentResults.length) }, (_, index) => <i key={index} className={opponentResults[index] ? `kick-${opponentResults[index]}` : ""}>{opponentResults[index] === "goal" ? "G" : opponentResults[index] === "saved" ? "S" : opponentResults[index] === "miss" ? "M" : ""}</i>)}</div>
      </div>

      <div className="pitch-scene">
        <div className="stadium-lights" />
        <div className="goal-frame">
          <div className="goal-net" />
          <div className="zone-grid">
            {ZONE_NAMES.map((name, zone) => (
              <button
                key={name}
                className={`aim-zone ${selectedZone === zone && aiming ? "selected" : ""}`}
                onClick={() => aiming && setSelectedZone(zone)}
                disabled={!aiming}
                aria-label={`${phase === "opponentAim" ? "Dive to" : "Aim at"} ${name}`}
                aria-pressed={selectedZone === zone}
              >
                {selectedZone === zone && aiming && <Crosshair size={19} />}
              </button>
            ))}
          </div>
          <div
            className={`goalkeeper ${visual ? "diving" : ""}`}
            style={{ "--keeper-x": `${keeper.x}%`, "--keeper-y": `${keeper.y}%` } as CSSProperties}
          >
            <span className="keeper-head" /><span className="keeper-body" /><span className="keeper-arms" />
          </div>
          {visual && (
            <div
              key={`${visual.side}-${playerResults.length}-${opponentResults.length}`}
              className={`match-ball ball-moving ${visual.trail ? "has-trail" : ""} ${visual.outcome === "miss" ? "ball-missed" : ""}`}
              style={{ "--ball-x": `${target.x}%`, "--ball-y": `${target.y}%` } as CSSProperties}
            />
          )}
          {!visual && <div className="match-ball ball-ready" style={{ background: isPlayerTurn ? kitColor : "#f4f4ef" }} />}
        </div>
        <div className="penalty-spot" />
        <div className="striker" style={{ "--kit-color": isPlayerTurn ? kitColor : opponent.color } as CSSProperties}>
          <span className="striker-head" /><span className="striker-shirt">9</span><span className="striker-legs" />
        </div>
      </div>

      <div className="match-control-deck">
        <div className="match-message"><span className={message.includes("GOAL") || message.includes("SAVE") ? "lime-text" : ""}>{message}</span><small>{isPlayerTurn ? `${opponent.keeper}: ${opponent.keeperStyle.toUpperCase()}` : `STRIKER: ${opponent.strikerStyle.toUpperCase()}`}</small></div>
        {phase === "playerAim" && (
          <div className="power-wrap">
            <div className="power-label"><Zap size={13} /> SHOT POWER <span>{Math.round(power * 100)}%</span></div>
            <div className="power-track"><div className="power-sweetspot" /><div className="power-needle" style={{ left: `${power * 100}%` }} /></div>
          </div>
        )}
        {phase === "opponentAim" && <div className="keeper-tip"><Shield size={16} /> Correct zone + Pro Grip = best save chance</div>}
        {aiming ? (
          <button className="primary-action shoot-action" onClick={phase === "playerAim" ? shoot : dive}>
            {phase === "playerAim" ? <Target size={17} /> : <Shield size={17} />}
            {phase === "playerAim" ? "SHOOT" : "DIVE"}
            <kbd>SPACE</kbd>
          </button>
        ) : phase !== "finished" ? <div className="shot-status">BALL IN PLAY<span /></div> : null}
      </div>

      {phase === "finished" && (
        <div className="result-overlay">
          <div className="result-card">
            <span className="eyebrow">FULL TIME / {stageLabel}</span>
            <h2 className={won || mode === "training" ? "lime-text" : ""}>{resultTitle}</h2>
            <div className="result-score">{playerScore} <span>—</span> {opponentScore}</div>
            <p>{resultCopy}</p>
            <div className="result-actions">
              {allowRematch && <button className="secondary-action" onClick={reset}><RotateCcw size={15} /> REMATCH</button>}
              <button className="primary-action" onClick={onExit}>CONTINUE</button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
