import type { ReactNode } from "react";
import { ChevronLeft } from "lucide-react";

interface ScreenHeadingProps {
  eyebrow: string;
  title: string;
  subtitle?: string;
  index?: string;
  aside?: ReactNode;
  onBack: () => void;
}

export default function ScreenHeading({ eyebrow, title, subtitle, index, aside, onBack }: ScreenHeadingProps) {
  return (
    <>
      <button className="screen-back" onClick={onBack}>
        <ChevronLeft size={12} /> BACK
      </button>
      <div className="screen-heading">
        <div>
          <div className="eyebrow screen-eyebrow"><span />{eyebrow}</div>
          <div className="screen-title-row">
            <h1>{title}</h1>
            {subtitle && <p>{subtitle}</p>}
          </div>
        </div>
        {aside && <div className="screen-heading-aside">{aside}</div>}
        {index && <span className="screen-index"><i>/</i>{index}</span>}
      </div>
    </>
  );
}
