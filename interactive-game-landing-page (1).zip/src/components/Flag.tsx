import {
  AE, AL, AR, AT, AU, BA, BE, BG, BH, BR, CA, CH, CI, CL, CM, CN, CO, CR, CU, CZ, DE, DK, DZ, EC, EG, ES, FI, FJ, FR, GH, GR, HN, HR, HU, ID, IE, IN, IQ, IR, IS, IT, JM, JO, JP, KE, KR, KW, KZ, MA, ME, MK, MX, MY, NC, NG, NL, NO, NZ, OM, PA, PE, PG, PH, PL, PT, PY, QA, RO, RS, SA, SB, SE, SI, SK, SN, TH, TN, TO, TR, TT, TZ, UA, UG, US, UY, UZ, VE, VN, VU, WS, ZA,
} from "country-flag-icons/react/3x2";
import RegionFlag0 from "country-flag-icons/react/3x2/GB-ENG";
import RegionFlag1 from "country-flag-icons/react/3x2/GB-SCT";

// Offline SVG flags for every nation in Career Mode. No remote image requests.
const FLAGS = {
  AE, AL, AR, AT, AU, BA, BE, BG, BH, BR, CA, CH, CI, CL, CM, CN, CO, CR, CU, CZ, DE, DK, DZ, EC, EG, ES, FI, FJ, FR, GH, GR, HN, HR, HU, ID, IE, IN, IQ, IR, IS, IT, JM, JO, JP, KE, KR, KW, KZ, MA, ME, MK, MX, MY, NC, NG, NL, NO, NZ, OM, PA, PE, PG, PH, PL, PT, PY, QA, RO, RS, SA, SB, SE, SI, SK, SN, TH, TN, TO, TR, TT, TZ, UA, UG, US, UY, UZ, VE, VN, VU, WS, ZA,
  "GB-ENG": RegionFlag0,
  "GB-SCT": RegionFlag1,
};

interface FlagProps {
  code: string;
  title?: string;
  className?: string;
}

export default function Flag({ code, title, className = "" }: FlagProps) {
  const Component = FLAGS[code as keyof typeof FLAGS];
  if (!Component) return <span className={`flag flag-missing ${className}`}>{code}</span>;
  return <Component title={title ?? code} className={`flag ${className}`} />;
}
