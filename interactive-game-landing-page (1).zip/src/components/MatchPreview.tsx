import { useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import {
  ArrowLeft,
  ArrowLeftRight,
  Check,
  ChevronRight,
  Clock3,
  Crown,
  Info,
  LayoutGrid,
  ListOrdered,
  MapPin,
  Minus,
  Play,
  Plus,
  RotateCcw,
  Shield,
  Shirt,
  SlidersHorizontal,
  Sparkles,
  Users,
  X,
} from "lucide-react";
import Flag from "./Flag";
import MatchdaySettings from "./MatchdaySettings";
import StadiumUnlockDialog from "./StadiumUnlockDialog";
import { CUSTOM_LIMITS, FORMATIONS, REGIONS, formationName, type Nation } from "../careerData";
import {
  ensureUnlockedStadium,
  getOpponentLevel,
  getStadium,
  STADIUMS,
  type StadiumId,
  loadMatchdayPreferences,
  saveMatchdayPreferences,
  type MatchdayPreferences,
} from "../matchdaySettings";
import {
  autoPickXI,
  generateSquad,
  groupLabel,
  regionOfNation,
  slotsForFormation,
  type Player,
  type PositionGroup,
} from "../squadData";

export interface PreviewFixture {
  mode: "quick" | "career";
  type: "friendly" | "penalty";
  home: Nation;
  away: Nation;
  homeFormation: number[];
  awayFormation: number[];
}

export interface MatchdayLineup {
  formation: number[];
  startingXI: Player[];
  bench: Player[];
  captainId: string;
  matchSettings: MatchdayPreferences;
}

interface MatchPreviewProps {
  fixture: PreviewFixture;
  /** The player's current coin balance, used for buying stadiums. */
  coins: number;
  /** Stadium ids the player owns. */
  unlockedStadiums: readonly StadiumId[];
  /** Buys a stadium with coins. Returns true when the stadium is owned afterwards. */
  onUnlockStadium: (id: StadiumId) => boolean;
  onBack: () => void;
  onStart: (lineup: MatchdayLineup) => void;
}

type Tab = "lineup" | "squad" | "opponent" | "settings";

const GROUP_ORDER: PositionGroup[] = ["GK", "DEF", "MID", "FWD"];

function FormBars({ form }: { form: number }) {
  return (
    <span className="form-bars" aria-label={`Form ${form} of 5`}>
      {[1, 2, 3, 4, 5].map((n) => <i key={n} className={n <= form ? "on" : ""} />)}
    </span>
  );
}

function ratingClass(rating: number) {
  if (rating >= 85) return "elite";
  if (rating >= 76) return "strong";
  return "";
}

export default function MatchPreview({ fixture, coins, unlockedStadiums, onUnlockStadium, onBack, onStart }: MatchPreviewProps) {
  const { home, away, mode, type } = fixture;
  const squad = useMemo(() => generateSquad(home), [home]);
  const awaySquad = useMemo(() => generateSquad(away), [away]);
  const homeRegion = REGIONS.find((r) => r.id === regionOfNation(home.code))?.name ?? "";
  const awayRegion = REGIONS.find((r) => r.id === regionOfNation(away.code))?.name ?? "";

  const [tab, setTab] = useState<Tab>("lineup");
  const [formation, setFormation] = useState<number[]>(fixture.homeFormation);
  const [xiIds, setXiIds] = useState<string[]>(() => autoPickXI(squad, fixture.homeFormation));
  const [captainId, setCaptainId] = useState<string>(() => autoPickXI(squad, fixture.homeFormation)[0] ?? "");
  const [selected, setSelected] = useState<string | null>(null);
  const [subsMade, setSubsMade] = useState(0);
  const [toast, setToast] = useState<string | null>(null);
  // A remembered stadium the player does not own (for example from before venues were locked) falls back to a free one.
  const [matchSettings, setMatchSettings] = useState<MatchdayPreferences>(() =>
    ensureUnlockedStadium(loadMatchdayPreferences(), unlockedStadiums),
  );
  const [unlockTarget, setUnlockTarget] = useState<StadiumId | null>(null);
  const unlockTrigger = useRef<HTMLElement | null>(null);
  const stadium = getStadium(matchSettings.stadiumId);
  const opponentLevel = getOpponentLevel(matchSettings.opponentDifficulty);
  const stadiumOwned = unlockedStadiums.includes(matchSettings.stadiumId);
  const unlockStadiumData = unlockTarget ? STADIUMS.find((item) => item.id === unlockTarget) : undefined;

  const requestUnlock = (id: StadiumId) => {
    unlockTrigger.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    setUnlockTarget(id);
  };

  const closeUnlock = () => {
    setUnlockTarget(null);
    const trigger = unlockTrigger.current;
    // Give the dialog a frame to unmount, then return keyboard focus to where the player was.
    window.requestAnimationFrame(() => { if (trigger?.isConnected) trigger.focus({ preventScroll: true }); });
  };

  const confirmUnlock = () => {
    if (!unlockStadiumData) return;
    const bought = unlockStadiumData;
    if (!onUnlockStadium(bought.id)) return;
    setMatchSettings((current) => ({ ...current, stadiumId: bought.id }));
    setToast(`${bought.name} unlocked · −${bought.price.toLocaleString("en-US")} coins`);
    closeUnlock();
  };

  useEffect(() => {
    saveMatchdayPreferences(matchSettings);
  }, [matchSettings]);

  const byId = useMemo(() => new Map(squad.map((p) => [p.id, p])), [squad]);
  const startingXI = xiIds.map((id) => byId.get(id)).filter((p): p is Player => Boolean(p));
  const bench = squad.filter((p) => !xiIds.includes(p.id));
  const slots = slotsForFormation(formation);
  const xiRating = startingXI.length ? Math.round(startingXI.reduce((sum, p) => sum + p.rating, 0) / startingXI.length) : 0;
  const captain = byId.get(captainId);

  useEffect(() => {
    if (!toast) return;
    const t = window.setTimeout(() => setToast(null), 2200);
    return () => window.clearTimeout(t);
  }, [toast]);

  useEffect(() => {
    if (captain && !xiIds.includes(captain.id)) setCaptainId(xiIds[0] ?? "");
  }, [xiIds, captain]);

  const flash = (message: string) => setToast(message);

  const applyFormation = (lines: number[]) => {
    setFormation(lines);
    setXiIds(autoPickXI(squad, lines));
    setSelected(null);
    flash(`Formation set to ${formationName(lines)} · best XI re-picked`);
  };

  const adjustLine = (index: 0 | 1 | 2, delta: 1 | -1) => {
    const limits = [CUSTOM_LIMITS.defenders, CUSTOM_LIMITS.midfielders, CUSTOM_LIMITS.forwards];
    const base: [number, number, number] =
      formation.length === 3
        ? [formation[0], formation[1], formation[2]]
        : [formation[0], 10 - formation[0] - formation[formation.length - 1], formation[formation.length - 1]];
    const next = [...base] as [number, number, number];
    const target = next[index] + delta;
    if (target < limits[index][0] || target > limits[index][1]) return;
    const partner = ([0, 1, 2] as const)
      .filter((i) => i !== index)
      .filter((i) => (delta > 0 ? next[i] - 1 >= limits[i][0] : next[i] + 1 <= limits[i][1]))
      .sort((a, b) => (delta > 0 ? next[b] - next[a] : next[a] - next[b]) || (a === 1 ? -1 : 1))[0];
    if (partner === undefined) return;
    next[index] = target;
    next[partner] -= delta;
    applyFormation(next);
  };

  /** Tap one player then another: XI↔bench = substitution, XI↔XI = swap positions. */
  const tapPlayer = (id: string) => {
    if (!selected) {
      setSelected(id);
      return;
    }
    if (selected === id) {
      setSelected(null);
      return;
    }
    const aIn = xiIds.includes(selected);
    const bIn = xiIds.includes(id);
    if (aIn && bIn) {
      setXiIds((ids) => {
        const next = [...ids];
        const i = next.indexOf(selected);
        const j = next.indexOf(id);
        [next[i], next[j]] = [next[j], next[i]];
        return next;
      });
      flash("Positions swapped");
    } else if (aIn !== bIn) {
      const out = aIn ? selected : id;
      const inc = aIn ? id : selected;
      const outP = byId.get(out);
      const inP = byId.get(inc);
      if (outP?.position === "GK" && inP?.position !== "GK") {
        flash("Only a goalkeeper can replace the goalkeeper");
        setSelected(null);
        return;
      }
      if (outP?.position !== "GK" && inP?.position === "GK") {
        flash("A goalkeeper can only replace the goalkeeper");
        setSelected(null);
        return;
      }
      setXiIds((ids) => ids.map((x) => (x === out ? inc : x)));
      setSubsMade((n) => n + 1);
      flash(`${inP?.shortName} ON · ${outP?.shortName} OFF`);
    }
    setSelected(null);
  };

  const resetLineup = () => {
    setXiIds(autoPickXI(squad, formation));
    setSubsMade(0);
    setSelected(null);
    flash("Best XI restored");
  };

  const pitchSlots = useMemo(() => {
    const top = 14;
    const bottom = 74;
    const lineCount = formation.length;
    const gap = lineCount > 1 ? (bottom - top) / (lineCount - 1) : 0;
    const out: { x: number; y: number; player?: Player; slot: string }[] = [];
    let cursor = 1;
    formation.forEach((count, lineIndex) => {
      for (let i = 0; i < count; i += 1) {
        out.push({
          x: ((i + 1) / (count + 1)) * 100,
          y: bottom - lineIndex * gap,
          player: startingXI[cursor],
          slot: slots[cursor - 1] ?? "",
        });
        cursor += 1;
      }
    });
    return out;
  }, [formation, startingXI, slots]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        if (unlockTarget) closeUnlock();
        else if (selected) setSelected(null);
        else onBack();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [selected, onBack, unlockTarget]);

  const gk = startingXI[0];

  const renderPlayerRow = (player: Player, inXI: boolean, index?: number) => {
    const isSelected = selected === player.id;
    const isCaptain = captainId === player.id;
    return (
      <button
        key={player.id}
        className={`squad-row ${isSelected ? "is-selected" : ""} ${inXI ? "in-xi" : "on-bench"} ${selected && !isSelected ? "can-target" : ""}`}
        onClick={() => tapPlayer(player.id)}
        aria-pressed={isSelected}
      >
        <span className="squad-number">{player.number}</span>
        <span className={`squad-pos pos-${player.group.toLowerCase()}`}>{inXI && index !== undefined && index > 0 ? slots[index - 1] : player.position}</span>
        <span className="squad-name">
          <strong>{player.name}{isCaptain && <Crown size={11} className="cap-icon" />}</strong>
          <small>{player.age} yrs · {player.foot === "L" ? "Left" : "Right"} foot · {player.caps} caps</small>
        </span>
        <FormBars form={player.form} />
        <span className="squad-fitness"><i><b style={{ width: `${player.fitness}%` }} /></i><small>{player.fitness}%</small></span>
        <span className={`squad-rating ${ratingClass(player.rating)}`}>{player.rating}</span>
      </button>
    );
  };

  return (
    <section className="matchday-screen" aria-label="Matchday preview">
      <div className="matchday-topbar">
        <button className="back-to-menu-btn" onClick={onBack}><ArrowLeft size={14} /> BACK TO SETUP</button>
        <span className="preview-label">{mode === "quick" ? "QUICK MATCH" : "CAREER MODE"} · {type === "friendly" ? "INTERNATIONAL FRIENDLY" : "PENALTY SHOOTOUT"} · MATCHDAY</span>
        <span className="matchday-kickoff-chip"><Sparkles size={12} /> KICK-OFF READY</span>
      </div>

      <div className="matchday-header">
        <div className="md-team">
          <Flag code={home.code} title={home.name} />
          <div>
            <small>TEAM A · YOU · {homeRegion}</small>
            <strong>{home.name.toUpperCase()}</strong>
            <span>{formationName(formation)} · XI OVR {xiRating}</span>
          </div>
        </div>
        <div className="md-versus">
          <span>VS</span>
          <small>{type === "friendly" ? `${matchSettings.durationMinutes} MIN` : "5 ROUNDS"}</small>
        </div>
        <div className="md-team md-away">
          <div>
            <small>TEAM B · OPPONENT · {awayRegion}</small>
            <strong>{away.name.toUpperCase()}</strong>
            <span>{formationName(fixture.awayFormation)} · OVR {away.rating}</span>
          </div>
          <Flag code={away.code} title={away.name} />
        </div>
      </div>

      <div className="matchday-tabs" role="tablist" aria-label="Matchday preview sections">
        {([
          { id: "lineup", label: "LINEUP & FORMATION", icon: LayoutGrid },
          { id: "squad", label: "FULL SQUAD", icon: Users },
          { id: "opponent", label: "OPPONENT XI", icon: Shirt },
          { id: "settings", label: "MATCH SETTINGS", icon: SlidersHorizontal },
        ] as { id: Tab; label: string; icon: typeof Users }[]).map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              type="button"
              role="tab"
              id={`matchday-tab-${item.id}`}
              aria-selected={tab === item.id}
              aria-controls="matchday-panel"
              tabIndex={tab === item.id ? 0 : -1}
              className={tab === item.id ? "selected" : ""}
              onClick={() => { setTab(item.id); setSelected(null); }}
              onKeyDown={(event) => {
                const tabs = Array.from(event.currentTarget.parentElement?.querySelectorAll<HTMLButtonElement>('[role="tab"]') ?? []);
                let index = tabs.indexOf(event.currentTarget);
                if (event.key === "ArrowRight") index = (index + 1) % tabs.length;
                else if (event.key === "ArrowLeft") index = (index + tabs.length - 1) % tabs.length;
                else if (event.key === "Home") index = 0;
                else if (event.key === "End") index = tabs.length - 1;
                else return;
                event.preventDefault();
                tabs[index]?.focus();
                tabs[index]?.click();
              }}
            >
              <Icon size={13} /> {item.label}{item.id === "settings" && <i className="md-settings-tab-dot" aria-hidden="true" />}
            </button>
          );
        })}
        <div className="matchday-tab-meta">
          <span><ArrowLeftRight size={12} /> SUBS MADE <b>{subsMade}</b></span>
          <span><Crown size={12} /> CAPTAIN <b>{captain?.shortName ?? "—"}</b></span>
        </div>
      </div>

      <div className="matchday-body" role="tabpanel" id="matchday-panel" aria-labelledby={`matchday-tab-${tab}`}>
        {tab === "lineup" && (
          <div className="lineup-layout">
            <div className="lineup-pitch-wrap">
              <div className="lineup-pitch">
                <span className="pitch-line pitch-halfway" />
                <span className="pitch-line pitch-circle" />
                <span className="pitch-line pitch-box" />
                <span className="pitch-line pitch-box pitch-box-top" />
                {gk && (
                  <button
                    className={`pitch-chip gk ${selected === gk.id ? "is-selected" : ""}`}
                    style={{ left: "50%", top: "90%" } as CSSProperties}
                    onClick={() => tapPlayer(gk.id)}
                  >
                    <i style={{ background: "#ffcf3f", color: "#1b1606" }}>{gk.number}</i>
                    <span>{gk.shortName}{captainId === gk.id && <Crown size={9} />}</span>
                    <small>GK · {gk.rating}</small>
                  </button>
                )}
                {pitchSlots.map((slot, index) =>
                  slot.player ? (
                    <button
                      key={slot.player.id}
                      className={`pitch-chip ${selected === slot.player.id ? "is-selected" : ""} ${selected && selected !== slot.player.id ? "can-target" : ""}`}
                      style={{ left: `${slot.x}%`, top: `${slot.y}%`, "--i": index } as CSSProperties}
                      onClick={() => tapPlayer(slot.player!.id)}
                    >
                      <i style={{ background: home.kit }}>{slot.player.number}</i>
                      <span>{slot.player.shortName}{captainId === slot.player.id && <Crown size={9} />}</span>
                      <small>{slot.slot} · {slot.player.rating}</small>
                    </button>
                  ) : null,
                )}
              </div>
              <div className="lineup-hint">
                {selected ? (
                  <><ArrowLeftRight size={13} /> Now tap another player to swap or substitute · <button className="text-button" onClick={() => setSelected(null)}><X size={11} /> CANCEL</button></>
                ) : (
                  <><Info size={13} /> Tap a player on the pitch or bench, then tap another to make a substitution or swap positions.</>
                )}
              </div>
            </div>

            <div className="lineup-side">
              <div className="lineup-panel">
                <div className="panel-title"><span><LayoutGrid size={14} /> FORMATION</span><b>{formationName(formation)}</b></div>
                <div className="formation-presets compact">
                  {FORMATIONS.map((f) => (
                    <button key={f.id} className={formationName(formation) === f.name ? "selected" : ""} onClick={() => applyFormation(f.lines)} title={f.style}>{f.name}</button>
                  ))}
                </div>
                <div className="custom-builder compact active">
                  {(["DEF", "MID", "FWD"] as const).map((label, index) => {
                    const value = index === 0 ? formation[0] : index === 2 ? formation[formation.length - 1] : 10 - formation[0] - formation[formation.length - 1];
                    return (
                      <div className="custom-row" key={label}>
                        <span>{label}</span>
                        <div>
                          <button onClick={() => adjustLine(index as 0 | 1 | 2, -1)} aria-label={`Fewer ${label}`}><Minus size={12} /></button>
                          <b>{value}</b>
                          <button onClick={() => adjustLine(index as 0 | 1 | 2, 1)} aria-label={`More ${label}`}><Plus size={12} /></button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="lineup-panel bench-panel">
                <div className="panel-title"><span><ListOrdered size={14} /> BENCH · {bench.length}</span><button className="text-button" onClick={resetLineup}><RotateCcw size={12} /> BEST XI</button></div>
                <div className="bench-list">
                  {bench.map((player) => (
                    <button
                      key={player.id}
                      className={`bench-row ${selected === player.id ? "is-selected" : ""} ${selected && selected !== player.id ? "can-target" : ""}`}
                      onClick={() => tapPlayer(player.id)}
                    >
                      <span className="squad-number">{player.number}</span>
                      <span className={`squad-pos pos-${player.group.toLowerCase()}`}>{player.position}</span>
                      <span className="bench-name">{player.shortName}</span>
                      <span className={`squad-rating ${ratingClass(player.rating)}`}>{player.rating}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {tab === "squad" && (
          <div className="squad-layout">
            <div className="squad-toolbar">
              <span><Users size={13} /> {squad.length} PLAYERS · <b>{startingXI.length}</b> STARTING · <b>{bench.length}</b> BENCH</span>
              <span className="squad-legend"><i className="in" /> Starting XI <i className="out" /> Bench · Tap a starter, then tap <Crown size={11} /> to set captain</span>
            </div>
            {GROUP_ORDER.map((group) => {
              const players = squad.filter((p) => p.group === group).sort((a, b) => Number(xiIds.includes(b.id)) - Number(xiIds.includes(a.id)) || b.rating - a.rating);
              return (
                <div className="squad-group" key={group}>
                  <div className="squad-group-head"><span>{groupLabel[group]}</span><small>{players.filter((p) => xiIds.includes(p.id)).length} starting</small></div>
                  <div className="squad-table">
                    {players.map((player) => {
                      const inXI = xiIds.includes(player.id);
                      return (
                        <div className="squad-row-wrap" key={player.id}>
                          {renderPlayerRow(player, inXI, inXI ? xiIds.indexOf(player.id) : undefined)}
                          {inXI && (
                            <button
                              className={`captain-btn ${captainId === player.id ? "is-captain" : ""}`}
                              onClick={() => { setCaptainId(player.id); flash(`${player.shortName} is now captain`); }}
                              aria-label={`Make ${player.name} captain`}
                              title="Set captain"
                            >
                              <Crown size={13} />
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {tab === "opponent" && (
          <div className="opponent-layout">
            <div className="opponent-card">
              <Flag code={away.code} title={away.name} />
              <div>
                <small>{awayRegion} · OVR {away.rating}</small>
                <strong>{away.name.toUpperCase()}</strong>
                <span>Lines up in <b>{formationName(fixture.awayFormation)}</b> · {away.keeperStyle} keeper · {away.strikerStyle} strikers</span>
              </div>
            </div>
            <div className="squad-table opponent-table">
              {autoPickXI(awaySquad, fixture.awayFormation).map((id, index) => {
                const player = awaySquad.find((p) => p.id === id);
                if (!player) return null;
                const oppSlots = slotsForFormation(fixture.awayFormation);
                return (
                  <div className="squad-row static" key={player.id}>
                    <span className="squad-number">{player.number}</span>
                    <span className={`squad-pos pos-${player.group.toLowerCase()}`}>{index === 0 ? "GK" : oppSlots[index - 1]}</span>
                    <span className="squad-name"><strong>{player.name}</strong><small>{player.age} yrs · {player.caps} caps · {player.goals} goals</small></span>
                    <FormBars form={player.form} />
                    <span className={`squad-rating ${ratingClass(player.rating)}`}>{player.rating}</span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {tab === "settings" && (
          <MatchdaySettings
            value={matchSettings}
            onChange={setMatchSettings}
            matchType={type}
            coins={coins}
            unlockedStadiums={unlockedStadiums}
            onRequestUnlock={requestUnlock}
          />
        )}
      </div>

      {toast && <div className="matchday-toast"><Check size={13} /> {toast}</div>}

      {unlockStadiumData && (
        <StadiumUnlockDialog stadium={unlockStadiumData} coins={coins} onConfirm={confirmUnlock} onCancel={closeUnlock} />
      )}

      <div className="matchday-bottom">
        <div className="md-footer-summary">
          <div className="md-summary">
            <span><Shirt size={12} /> {formationName(formation)}</span>
            <span><Users size={12} /> XI OVR {xiRating}</span>
            <span><Crown size={12} /> {captain?.shortName ?? "No captain"}</span>
            <span><ArrowLeftRight size={12} /> {subsMade} SUBS</span>
          </div>
          <button
            type="button"
            className="md-settings-shortcut"
            aria-label="Edit stadium, match duration and opponent difficulty"
            onClick={() => { setTab("settings"); setSelected(null); }}
          >
            <MapPin size={11} /> {stadium.name}<i>/</i><Clock3 size={11} /> {matchSettings.durationMinutes} MIN<i>/</i><Shield size={11} /> {opponentLevel.label.toUpperCase()}<ChevronRight size={12} />
          </button>
        </div>
        <button
          className="primary-action matchday-start"
          onClick={() => onStart({ formation, startingXI, bench, captainId, matchSettings })}
          disabled={startingXI.length !== 11 || !stadiumOwned}
        >
          <Play size={15} /> START MATCH <ChevronRight size={14} />
        </button>
      </div>
    </section>
  );
}
