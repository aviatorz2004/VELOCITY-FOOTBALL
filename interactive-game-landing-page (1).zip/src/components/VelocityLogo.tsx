import type { CSSProperties } from "react";

interface VelocityLogoProps {
  /** Height of the three-stripe mark in px, or any CSS length. Everything else scales from it. */
  height?: number | string;
  className?: string;
  /** Hide the "FOOTBALL" line for very small placements. */
  compact?: boolean;
}

/**
 * Velocity Football wordmark:
 * three ascending lime slashes, VELOCITY in white, FOOTBALL letter-spaced in lime.
 * Built with type + CSS so it stays crisp at every size and needs no image request.
 */
export default function VelocityLogo({ height = 28, className = "", compact = false }: VelocityLogoProps) {
  const size = typeof height === "number" ? `${height}px` : height;

  return (
    <span
      className={`velocity-logo ${compact ? "is-compact" : ""} ${className}`}
      style={{ "--logo-h": size } as CSSProperties}
      role="img"
      aria-label="Velocity Football"
    >
      <span className="velocity-logo-mark" aria-hidden="true">
        <i />
        <i />
        <i />
      </span>
      <span className="velocity-logo-type" aria-hidden="true">
        <strong>VELOCITY</strong>
        {!compact && <small>FOOTBALL</small>}
      </span>
    </span>
  );
}
