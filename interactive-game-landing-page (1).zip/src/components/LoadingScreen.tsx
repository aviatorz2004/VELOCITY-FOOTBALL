import { useEffect, useRef, useState, type CSSProperties } from "react";
import { Check, MapPin } from "lucide-react";
import VelocityLogo from "./VelocityLogo";
import "./LoadingScreen.css";

interface LoadingScreenProps {
  onComplete: () => void;
  durationMs?: number;
}

/** Each stage owns one photograph and one job, four seconds apiece across the 20 second build-up. */
const STAGES = [
  {
    id: "arena",
    venue: "Match Arena",
    location: "Pre-match build up",
    job: "Stadium & lights",
    shortJob: "Stadium",
    status: "Lighting the stadium...",
    tip: "Every great match starts long before the first whistle.",
  },
  {
    id: "training",
    venue: "Training Ground",
    location: "Squad call-ups",
    job: "National squads",
    shortJob: "Squads",
    status: "Calling up the squads...",
    tip: "Ninety-three nations, nine confederations, one ball.",
  },
  {
    id: "knockout",
    venue: "Knockout Nights",
    location: "Cup fixtures",
    job: "Formations & tactics",
    shortJob: "Tactics",
    status: "Setting the formations...",
    tip: "Pick a shape, or build your own from the back line up.",
  },
  {
    id: "arena-night",
    venue: "Floodlit Nights",
    location: "Under the lights",
    job: "Crowd & audio",
    shortJob: "Atmosphere",
    status: "Filling the stands...",
    tip: "Away days hit different when the floodlights come on.",
  },
  {
    id: "champions",
    venue: "The Final Whistle",
    location: "Kick-off ready",
    job: "Pitch inspection",
    shortJob: "Pitch",
    status: "Rolling out the pitch...",
    tip: "Everything is ready. The first whistle is yours.",
  },
] as const;

export default function LoadingScreen({ onComplete, durationMs = 20000 }: LoadingScreenProps) {
  const [elapsed, setElapsed] = useState(0);
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;
  const duration = Number.isFinite(durationMs) ? Math.max(1, durationMs) : 20000;

  useEffect(() => {
    const startedAt = performance.now();
    let completed = false;
    setElapsed(0);

    // Wall-clock elapsed time keeps the 20 second build-up honest if the tab loses focus.
    const update = () => {
      if (completed) return;
      const current = Math.min(duration, performance.now() - startedAt);
      setElapsed(current);
      if (current >= duration) {
        completed = true;
        window.clearInterval(interval);
        onCompleteRef.current();
      }
    };

    const interval = window.setInterval(update, 100);
    const finish = window.setTimeout(update, duration);
    document.addEventListener("visibilitychange", update);
    return () => {
      completed = true;
      window.clearInterval(interval);
      window.clearTimeout(finish);
      document.removeEventListener("visibilitychange", update);
    };
  }, [duration]);

  const ratio = Math.min(1, elapsed / duration);
  const progress = Math.floor(ratio * 100);
  const activeStage = Math.min(STAGES.length - 1, Math.floor(ratio * STAGES.length));
  const stage = STAGES[activeStage];
  const done = ratio >= 1;

  return (
    <section className="loading-screen" aria-label="Loading screen" aria-busy="true">
      <div className="loading-bg-stack" aria-hidden="true">
        {STAGES.map((item, index) => (
          <div
            key={item.id}
            data-slide={item.id}
            className={`loading-bg-slide ${index === activeStage ? "is-active" : ""}`}
          />
        ))}
      </div>
      <div className="loading-scrim" aria-hidden="true" />

      <div className="loading-shell">
        {/* Horizontal Top Bar */}
        <header className="loading-topbar">
          <div className="loading-brand-group">
            <VelocityLogo height={28} />
            <span className="loading-topbar-sep" aria-hidden="true" />
            <span className="loading-tag">SEASON 01</span>
            <span className="loading-tag is-quiet">MATCHDAY BUILD 1.1</span>
          </div>

          <div className="loading-meta-group">
            <span className="loading-studio">MCGREGOR STUDIO</span>
            <div className="loading-stage-dots" aria-hidden="true">
              {STAGES.map((item, index) => (
                <span key={item.id} className={index === activeStage ? "is-active" : index < activeStage ? "is-done" : ""} />
              ))}
            </div>
          </div>
        </header>

        {/* Open Widescreen Showcase + Horizontal Venue Strip */}
        <div className="loading-showcase">
          <div className="loading-venue-banner" key={stage.id}>
            <div className="loading-caption">
              <div className="loading-caption-meta">
                <span className="loading-caption-place">
                  <MapPin size={12} aria-hidden="true" />
                  {stage.location}
                </span>
              </div>
              <strong className="loading-venue-title">{stage.venue}</strong>
              <p className="loading-tip">{stage.tip}</p>
            </div>

            <div className="loading-stats-row" aria-label="World overview">
              <div><b>93</b><span>NATIONS</span></div>
              <div><b>09</b><span>REGIONS</span></div>
              <div><b>01</b><span>TROPHY</span></div>
            </div>
          </div>
        </div>

        {/* Full-Width Horizontal Bottom Loading Dock */}
        <footer className="loading-dock">
          <div
            className="loading-progress"
            role="progressbar"
            aria-label="Loading Velocity Football"
            aria-valuemin={0}
            aria-valuemax={100}
            aria-valuenow={progress}
            aria-valuetext={`${progress}% complete`}
          >
            <span className="loading-progress-fill" style={{ "--p": ratio } as CSSProperties} />
          </div>

          <div className="loading-dock-inner">
            <div className="loading-readout">
              <span className="loading-spinner-box" aria-hidden="true">
                <span className="loading-spinner-track" />
                <span className="loading-spinner-comet">
                  <span className="loading-spinner-arc" />
                  <span className="loading-spinner-glow" />
                  <span className="loading-spinner-head" />
                </span>
              </span>
              <span className="loading-percentage" aria-hidden="true">
                {progress}<small>%</small>
              </span>
              <div className="loading-status-copy">
                <p className="loading-substatus" role="status" aria-live="polite" aria-atomic="true">
                  {done ? "Welcome to Velocity Football." : stage.status}
                </p>
              </div>
            </div>

            <ol className="loading-steps" aria-label="Matchday preparation stages">
              {STAGES.map((item, index) => {
                const isDone = done || index < activeStage;
                const isActive = !done && index === activeStage;
                return (
                  <li key={item.id} className={isDone ? "is-done" : isActive ? "is-active" : ""}>
                    <div className="loading-step-top">
                      <span className="loading-step-mark" aria-hidden="true">
                        {isDone ? <Check size={10} strokeWidth={3} /> : String(index + 1).padStart(2, "0")}
                      </span>
                      <span className="loading-step-state">{isDone ? "READY" : isActive ? "LOADING" : "WAIT"}</span>
                    </div>
                    <span className="loading-step-label" data-short={item.shortJob}>{item.job}</span>
                  </li>
                );
              })}
            </ol>
          </div>
        </footer>
      </div>
    </section>
  );
}
