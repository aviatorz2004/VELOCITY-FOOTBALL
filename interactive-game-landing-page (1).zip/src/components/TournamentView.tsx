import { Coins, Medal, Play, Shuffle, Trophy } from "lucide-react";
import ScreenHeading from "./ScreenHeading";
import type { Opponent } from "../gameData";
import {
  PLAYER_TEAM_ID,
  TOURNAMENT_ROUNDS,
  findOpponent,
  playerOpponentId,
  roundTeams,
  type TournamentState,
} from "../tournament";

interface TournamentViewProps {
  tournament: TournamentState;
  kitColor: string;
  playerOvr: number;
  playerClub?: string;
  playerShort?: string;
  onPlay: (opponent: Opponent) => void;
  onNewDraw: () => void;
  onBack: () => void;
}

const ROUND_LABELS = ["QUARTER-FINALS", "SEMI-FINALS", "FINAL"];
const money = (value: number) => value.toLocaleString("en-US");

export default function TournamentView({ tournament, kitColor, playerOvr, playerClub = "VELOCITY FC", playerShort = "VF", onPlay, onNewDraw, onBack }: TournamentViewProps) {
  const team = (id: string) => {
    if (id === PLAYER_TEAM_ID) return { name: playerClub, short: playerShort, color: kitColor };
    const opponent = findOpponent(id);
    return { name: opponent.club, short: opponent.short, color: opponent.color };
  };

  const opponentId = playerOpponentId(tournament);
  const opponent = opponentId ? findOpponent(opponentId) : null;
  const round = Math.min(tournament.round, 2);
  const champion = tournament.round >= 3 ? tournament.winners[2]?.[0] ?? null : null;
  const canRedraw = tournament.round === 0 || tournament.round >= 3;
  const exitRound = tournament.winners.findIndex(
    (winners, index) => roundTeams(tournament, index).includes(PLAYER_TEAM_ID) && !winners.includes(PLAYER_TEAM_ID),
  );

  return (
    <section className="tournament-screen" aria-label="Velocity Cup tournament">
      <ScreenHeading
        eyebrow="VELOCITY CUP"
        title="TOURNAMENT"
        subtitle="Eight clubs. One trophy."
        index="04"
        onBack={onBack}
      />

      <div className="tournament-layout">
        <aside className="cup-panel">
          {opponent ? (
            <>
              <div className="cup-panel-top">
                <span className="eyebrow">NEXT TIE</span>
                <span className="rating-chip">{TOURNAMENT_ROUNDS[round].name.toUpperCase()}</span>
              </div>
              <div className="cup-versus">
                <div>
                  <span className="large-crest" style={{ background: kitColor }}>{playerShort}</span>
                  <strong>{playerClub.toUpperCase()}</strong>
                  <small>OVR {playerOvr}</small>
                </div>
                <span>VS</span>
                <div>
                  <span className="large-crest opponent" style={{ borderColor: opponent.color, color: opponent.color }}>
                    {opponent.short}
                  </span>
                  <strong>{opponent.club.toUpperCase()}</strong>
                  <small>OVR {opponent.rating}</small>
                </div>
              </div>
              <p>{opponent.description}</p>
              <div className="cup-reward">
                <Coins size={14} /> ROUND REWARD <strong>+{money(TOURNAMENT_ROUNDS[round].reward)} COINS</strong>
              </div>
              <button className="primary-action cup-play" onClick={() => onPlay(opponent)}>
                <Play size={15} /> PLAY {TOURNAMENT_ROUNDS[round].name.toUpperCase()}
              </button>
            </>
          ) : champion === PLAYER_TEAM_ID ? (
            <>
              <div className="cup-result">
                <span className="cup-result-icon"><Trophy size={26} /></span>
                <span className="eyebrow">VELOCITY CUP WINNERS</span>
                <h3>CHAMPIONS!</h3>
                <p>You lifted the Velocity Cup. Make a new draw to defend your title.</p>
              </div>
              <button className="primary-action cup-play" onClick={onNewDraw}><Shuffle size={15} /> DEFEND THE TITLE</button>
            </>
          ) : (
            <>
              <div className="cup-result">
                <span className="cup-result-icon muted"><Medal size={26} /></span>
                <span className="eyebrow">
                  {exitRound === 2 ? "RUNNER-UP" : `OUT IN THE ${TOURNAMENT_ROUNDS[Math.max(0, exitRound)].name.toUpperCase()}`}
                </span>
                <h3>{exitRound === 2 ? "SO CLOSE." : "KNOCKED OUT."}</h3>
                <p>
                  {champion ? `${team(champion).name} lifted the cup.` : "The cup continues without you."} Make a new draw
                  and go again.
                </p>
              </div>
              <button className="primary-action cup-play" onClick={onNewDraw}><Shuffle size={15} /> NEW DRAW</button>
            </>
          )}

          <div className="cup-panel-foot">
            <span><Trophy size={13} /> CUP TITLES <strong>{tournament.titles}</strong></span>
            <button
              className="text-button"
              onClick={onNewDraw}
              disabled={!canRedraw}
              title={canRedraw ? "Shuffle the bracket" : "Finish the current cup run first"}
            >
              <Shuffle size={13} /> NEW DRAW
            </button>
          </div>
        </aside>

        <div className="bracket" aria-label="Tournament bracket">
          {ROUND_LABELS.map((label, roundIndex) => {
            const teams = roundTeams(tournament, roundIndex);
            return (
              <div className="bracket-round" key={label}>
                <span className="bracket-label">{label}</span>
                <div className="bracket-matches">
                  {Array.from({ length: 4 >> roundIndex }, (_, matchIndex) => {
                    const home = teams[matchIndex * 2];
                    const away = teams[matchIndex * 2 + 1];
                    const winner = tournament.winners[roundIndex]?.[matchIndex];
                    const [homeGoals, awayGoals] = (tournament.scores[roundIndex]?.[matchIndex] ?? "").split("-");
                    const hasPlayer = home === PLAYER_TEAM_ID || away === PLAYER_TEAM_ID;
                    const isCurrent = hasPlayer && roundIndex === tournament.round && !tournament.eliminated;
                    return (
                      <div
                        key={matchIndex}
                        className={`bracket-match ${hasPlayer ? "is-player" : ""} ${isCurrent ? "is-current" : ""}`}
                      >
                        {[
                          { id: home, goals: homeGoals },
                          { id: away, goals: awayGoals },
                        ].map((slot, slotIndex) => {
                          if (!slot.id) {
                            return (
                              <div key={slotIndex} className="bracket-team tbd">
                                <span className="bracket-crest empty" />
                                <span className="bracket-name">TBD</span>
                              </div>
                            );
                          }
                          const info = team(slot.id);
                          const state = winner ? (winner === slot.id ? "won" : "lost") : "";
                          return (
                            <div
                              key={slotIndex}
                              className={`bracket-team ${state} ${slot.id === PLAYER_TEAM_ID ? "player" : ""}`}
                            >
                              <span className="bracket-crest" style={{ background: info.color }}>{info.short}</span>
                              <span className="bracket-name">{info.name}</span>
                              <b>{slot.goals ?? ""}</b>
                            </div>
                          );
                        })}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}

          <div className="bracket-round">
            <span className="bracket-label">CHAMPION</span>
            <div className="bracket-matches">
              <div className={`champion-card ${champion ? "decided" : ""}`}>
                <Trophy size={26} />
                <strong>{champion ? team(champion).name.toUpperCase() : "TO BE DECIDED"}</strong>
                <small>VELOCITY CUP</small>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
