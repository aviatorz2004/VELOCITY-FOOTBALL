import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ArrowLeftRight,
  Check,
  ChevronLeft,
  Eye,
  Minus,
  Plus,
  RefreshCw,
} from "lucide-react";
import Flag from "./Flag";
import ScreenHeading from "./ScreenHeading";
import {
  CUSTOM_LIMITS,
  FORMATIONS,
  REGIONS,
  formationName,
  formationProfile,
  randomFormation,
  type Nation,
} from "../careerData";
import { autoPickXI, generateSquad, type Player } from "../squadData";

export interface QuickFixture {
  home: Nation;
  away: Nation;
  homeFormation: number[];
  awayFormation: number[];
}

interface QuickFormationSetupProps {
  onBack: () => void;
  onStart: (fixture: QuickFixture) => void;
}

const ALL_NATIONS = REGIONS.flatMap((region) => region.nations.map((nation) => ({ ...nation, regionName: region.name })));

const lastName = (name: string) => name.split(" ").slice(-1)[0].toUpperCase();

function FormationPitch({ lines, color, label, players }: { lines: number[]; color: string; label: string; players?: Player[] }) {
  const top = 16;
  const bottom = 72;
  const gap = lines.length > 1 ? (bottom - top) / (lines.length - 1) : 0;
  const outfield = players ? players.slice(1) : [];
  let cursor = 0;
  return (
    <div className="formation-pitch" aria-label={`${label} formation ${formationName(lines)}`}>
      <span className="pitch-line pitch-halfway" />
      <span className="pitch-line pitch-circle" />
      <span className="pitch-line pitch-box" />
      <span className="pitch-line pitch-box pitch-box-top" />
      <span className="pitch-player pitch-gk" style={{ left: "50%", top: "88%" }}>
        {players?.[0] && <span className="pitch-player-name">{lastName(players[0].name)}</span>}1
      </span>
      {lines.map((count, lineIndex) =>
        Array.from({ length: count }, (_, playerIndex) => {
          const player = outfield[cursor];
          cursor += 1;
          return (
            <span
              key={`${lineIndex}-${playerIndex}`}
              className="pitch-player"
              style={{
                left: `${((playerIndex + 1) / (count + 1)) * 100}%`,
                top: `${bottom - lineIndex * gap}%`,
                background: color,
              }}
            >
              {player && <span className="pitch-player-name">{lastName(player.name)}</span>}
            </span>
          );
        }),
      )}
    </div>
  );
}

function randomNation(except?: string) {
  const pool = ALL_NATIONS.filter((item) => item.code !== except);
  return pool[Math.floor(Math.random() * pool.length)];
}

export default function QuickFormationSetup({ onBack, onStart }: QuickFormationSetupProps) {
  const [home, setHome] = useState(() => randomNation());
  const [away, setAway] = useState(() => randomNation(home.code));
  const [formationId, setFormationId] = useState("433");
  const [customLines, setCustomLines] = useState<[number, number, number]>([4, 3, 3]);
  const [awayFormation, setAwayFormation] = useState(() => randomFormation());

  const homeLines = formationId === "custom" ? customLines : FORMATIONS.find((f) => f.id === formationId)?.lines ?? [4, 3, 3];
  const profile = formationProfile(homeLines);
  const homeSquad = useMemo(() => generateSquad(home), [home]);
  const homeXI = useMemo(
    () =>
      autoPickXI(homeSquad, homeLines)
        .map((id) => homeSquad.find((player) => player.id === id))
        .filter((player): player is Player => Boolean(player)),
    [homeSquad, homeLines],
  );

  const redrawTeams = useCallback(() => {
    const nextHome = randomNation();
    setHome(nextHome);
    setAway(randomNation(nextHome.code));
    setAwayFormation(randomFormation());
  }, []);

  const swapTeams = () => {
    setHome(away);
    setAway(home);
  };

  const adjustLine = (index: 0 | 1 | 2, delta: 1 | -1) => {
    const limits = [CUSTOM_LIMITS.defenders, CUSTOM_LIMITS.midfielders, CUSTOM_LIMITS.forwards];
    setCustomLines((current) => {
      const next = [...current] as [number, number, number];
      const target = next[index] + delta;
      if (target < limits[index][0] || target > limits[index][1]) return current;
      const candidates = ([0, 1, 2] as const)
        .filter((i) => i !== index)
        .filter((i) => (delta > 0 ? next[i] - 1 >= limits[i][0] : next[i] + 1 <= limits[i][1]))
        .sort((a, b) => (delta > 0 ? next[b] - next[a] : next[a] - next[b]) || (a === 1 ? -1 : 1));
      const partner = candidates[0];
      if (partner === undefined) return current;
      next[index] = target;
      next[partner] -= delta;
      return next;
    });
    setFormationId("custom");
  };

  const start = () => {
    onStart({ home, away, homeFormation: [...homeLines], awayFormation: [...awayFormation.lines] });
  };

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Enter" && !(event.target as HTMLElement | null)?.closest("button, input, select")) {
        event.preventDefault();
        start();
      }
    };
    window.addEventListener("keydown", onKeyDown, true);
    return () => window.removeEventListener("keydown", onKeyDown, true);
  });

  return (
    <section className="career-setup quick-setup" aria-label="Quick match formation setup">
      <ScreenHeading
        eyebrow="QUICK MATCH / AUTO DRAW"
        title="MATCH SETUP"
        subtitle="Random national teams. Choose the shape, keep the pace."
        index="01"
        onBack={onBack}
      />
      <ol className="setup-stepper quick-stepper">
        {["RANDOM TEAMS", "FORMATION", "START"].map((label, index) => (
          <li key={label} className={`${index === 2 ? "current" : "done"}`}>
            <button disabled type="button">
              <span>{index < 2 ? <Check size={11} /> : `0${index + 1}`}</span>
              {label}
            </button>
          </li>
        ))}
      </ol>

      <div className="setup-body">
        <div className="quick-setup-layout">
          <div className="quick-left">
            <div className="team-slot filled active">
              <span className="team-slot-label">TEAM A · YOU</span>
              <span className="team-slot-nation">
                <Flag code={home.code} title={home.name} />
                <span><strong>{home.name.toUpperCase()}</strong><small>{home.regionName} · OVR {home.rating}</small></span>
              </span>
            </div>
            <div className="team-slot filled">
              <span className="team-slot-label">TEAM B · OPPONENT</span>
              <span className="team-slot-nation">
                <Flag code={away.code} title={away.name} />
                <span><strong>{away.name.toUpperCase()}</strong><small>{away.regionName} · {formationName(awayFormation.lines)}</small></span>
              </span>
            </div>
            <div className="quick-tools">
              <button className="secondary-action" onClick={redrawTeams}><RefreshCw size={13} /> REDRAW TEAMS</button>
              <button className="secondary-action" onClick={swapTeams}><ArrowLeftRight size={13} /> SWAP SIDES</button>
            </div>
            <span className="formation-label">PRESET FORMATIONS</span>
            <div className="formation-presets">
              {FORMATIONS.map((formation) => (
                <button
                  key={formation.id}
                  className={formationId === formation.id ? "selected" : ""}
                  onClick={() => setFormationId(formation.id)}
                  title={formation.style}
                >
                  {formation.name}
                </button>
              ))}
            </div>

            <span className="formation-label">
              CUSTOM SHAPE <small>Unataka formation yako mwenyewe? Panga hapa</small>
            </span>
            <div className={`custom-builder ${formationId === "custom" ? "active" : ""}`}>
              {(["DEFENDERS", "MIDFIELDERS", "FORWARDS"] as const).map((label, index) => (
                <div className="custom-row" key={label}>
                  <span>{label}</span>
                  <div>
                    <button onClick={() => adjustLine(index as 0 | 1 | 2, -1)} aria-label={`Fewer ${label.toLowerCase()}`}><Minus size={13} /></button>
                    <b>{customLines[index]}</b>
                    <button onClick={() => adjustLine(index as 0 | 1 | 2, 1)} aria-label={`More ${label.toLowerCase()}`}><Plus size={13} /></button>
                  </div>
                </div>
              ))}
              <button className="custom-use" onClick={() => setFormationId("custom")}>
                {formationId === "custom" ? <><Check size={13} /> USING {formationName(customLines)}</> : <>USE {formationName(customLines)}</>}
              </button>
            </div>
            <div className="formation-bars">
              {[
                { label: "ATTACK", value: profile.attack },
                { label: "DEFENCE", value: profile.defence },
                { label: "CONTROL", value: profile.control },
              ].map((bar) => (
                <div key={bar.label}>
                  <span>{bar.label}</span>
                  <i><b style={{ width: `${Math.min(100, bar.value * 62)}%` }} /></i>
                </div>
              ))}
            </div>
          </div>

          <div className="formation-right">
            <div className="formation-pitch-head">
              <span><Flag code={home.code} title={home.name} /> {formationName(homeLines)}</span>
              <small>{formationId === "custom" ? "Your custom shape" : FORMATIONS.find((f) => f.id === formationId)?.style}</small>
            </div>
            <FormationPitch lines={homeLines} color={home.kit} label={home.name} players={homeXI} />
            <div className="opponent-shape">
              <Flag code={away.code} title={away.name} /> {away.name} will line up in <b>{awayFormation.name}</b>
            </div>
          </div>
        </div>
      </div>

      <div className="setup-footer-bar">
        <button className="back-to-menu-btn" onClick={onBack}><ChevronLeft size={13} /> BACK TO GAME MODES</button>
        <div className="setup-summary">
          <span>{home.short} vs {away.short}</span>
          <span>FORMATION {formationName(homeLines)}</span>
        </div>
        <button className="apply-changes-btn" onClick={start}>
          <Eye size={14} /> START MATCH
        </button>
      </div>
    </section>
  );
}
