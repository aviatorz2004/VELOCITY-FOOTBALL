import { useEffect, useMemo, useState, type CSSProperties } from "react";
import {
  ArrowLeftRight,
  Check,
  ChevronLeft,
  ChevronRight,
  Clock3,
  Eye,
  Globe2,
  Info,
  Minus,
  Plus,
  Shuffle,
  Target,
} from "lucide-react";
import Flag from "./Flag";
import ScreenHeading from "./ScreenHeading";
import {
  CUSTOM_LIMITS,
  FORMATIONS,
  REGIONS,
  formationName,
  formationProfile,
  randomFormation,
  type CareerMatchType,
  type Nation,
  type RegionId,
} from "../careerData";
import { autoPickXI, generateSquad, type Player } from "../squadData";

export interface CareerFixture {
  type: CareerMatchType;
  home: Nation;
  away: Nation;
  homeRegion: RegionId;
  awayRegion: RegionId;
  homeFormation: number[];
  awayFormation: number[];
}

interface CareerSetupProps {
  onBack: () => void;
  onStart: (fixture: CareerFixture) => void;
}

const STEPS = ["MATCH TYPE", "REGION", "TEAMS", "FORMATION"];

const lastName = (name: string) => name.split(" ").slice(-1)[0].toUpperCase();

function FormationPitch({ lines, color, label, players }: { lines: number[]; color: string; label: string; players?: Player[] }) {
  const top = 16;
  const bottom = 72;
  const gap = lines.length > 1 ? (bottom - top) / (lines.length - 1) : 0;
  const outfield = players ? players.slice(1) : [];
  let cursor = 0;
  return (
    <div className="formation-pitch" aria-label={`${label} formation ${formationName(lines)}`}>
      <span className="pitch-line pitch-halfway" />
      <span className="pitch-line pitch-circle" />
      <span className="pitch-line pitch-box" />
      <span className="pitch-line pitch-box pitch-box-top" />
      <span className="pitch-player pitch-gk" style={{ left: "50%", top: "88%" }}>
        {players?.[0] && <span className="pitch-player-name">{lastName(players[0].name)}</span>}1
      </span>
      {lines.map((count, lineIndex) =>
        Array.from({ length: count }, (_, playerIndex) => {
          const player = outfield[cursor];
          cursor += 1;
          return (
            <span
              key={`${lineIndex}-${playerIndex}`}
              className="pitch-player"
              style={{
                left: `${((playerIndex + 1) / (count + 1)) * 100}%`,
                top: `${bottom - lineIndex * gap}%`,
                background: color,
              }}
            >
              {player && <span className="pitch-player-name">{lastName(player.name)}</span>}
            </span>
          );
        }),
      )}
    </div>
  );
}

export default function CareerSetup({ onBack, onStart }: CareerSetupProps) {
  const [step, setStep] = useState(0);
  const [type, setType] = useState<CareerMatchType | null>(null);
  const [regionId, setRegionId] = useState<RegionId | null>(null);
  const [home, setHome] = useState<Nation | null>(null);
  const [away, setAway] = useState<Nation | null>(null);
  const [slot, setSlot] = useState<"home" | "away">("home");
  const [homeRegion, setHomeRegion] = useState<RegionId>("africa");
  const [awayRegion, setAwayRegion] = useState<RegionId>("europe1");
  const [formationId, setFormationId] = useState("433");
  const [customLines, setCustomLines] = useState<[number, number, number]>([4, 3, 3]);
  const [awayFormation] = useState(() => randomFormation());

  const homeLines = formationId === "custom" ? customLines : FORMATIONS.find((f) => f.id === formationId)?.lines ?? [4, 3, 3];
  const profile = formationProfile(homeLines);
  const homeSquad = useMemo(() => (home ? generateSquad(home) : []), [home]);
  const homeXI = useMemo(
    () =>
      home
        ? autoPickXI(homeSquad, homeLines)
            .map((id) => homeSquad.find((player) => player.id === id))
            .filter((player): player is Player => Boolean(player))
        : [],
    [homeSquad, homeLines, home],
  );
  const activeRegionId = slot === "home" ? homeRegion : awayRegion;
  const activeRegion = REGIONS.find((item) => item.id === activeRegionId) ?? REGIONS[0];
  const canContinue = [type !== null, regionId !== null, home !== null && away !== null, true][step];

  const selectRegion = (id: RegionId) => {
    setRegionId(id);
    setHomeRegion(id);
    setAwayRegion(id);
    setHome(null);
    setAway(null);
    setSlot("home");
  };

  const switchSlotRegion = (id: RegionId) => {
    if (slot === "home") setHomeRegion(id);
    else setAwayRegion(id);
  };

  const pickNation = (nation: Nation) => {
    if (slot === "home") {
      setHome(nation);
      if (away?.code !== nation.code) setSlot("away");
    } else {
      if (home?.code === nation.code) {
        setSlot("home");
        return;
      }
      setAway(nation);
    }
  };

  const randomTeams = () => {
    const poolA = REGIONS.find((r) => r.id === homeRegion)?.nations ?? [];
    const poolB = REGIONS.find((r) => r.id === awayRegion)?.nations ?? [];
    const pickA = poolA[Math.floor(Math.random() * poolA.length)];
    const choicesB = poolB.filter((nation) => nation.code !== pickA?.code);
    const pickB = choicesB[Math.floor(Math.random() * choicesB.length)];
    if (pickA) setHome(pickA);
    if (pickB) setAway(pickB);
  };

  const adjustLine = (index: 0 | 1 | 2, delta: 1 | -1) => {
    const limits = [CUSTOM_LIMITS.defenders, CUSTOM_LIMITS.midfielders, CUSTOM_LIMITS.forwards];
    setCustomLines((current) => {
      const next = [...current] as [number, number, number];
      const target = next[index] + delta;
      if (target < limits[index][0] || target > limits[index][1]) return current;
      const candidates = ([0, 1, 2] as const)
        .filter((i) => i !== index)
        .filter((i) => (delta > 0 ? next[i] - 1 >= limits[i][0] : next[i] + 1 <= limits[i][1]))
        .sort((a, b) => (delta > 0 ? next[b] - next[a] : next[a] - next[b]) || (a === 1 ? -1 : 1));
      const partner = candidates[0];
      if (partner === undefined) return current;
      next[index] = target;
      next[partner] -= delta;
      return next;
    });
    setFormationId("custom");
  };

  const next = () => {
    if (!canContinue) return;
    if (step < 3) {
      setStep(step + 1);
      return;
    }
    if (type && home && away) {
      onStart({
        type,
        home,
        away,
        homeRegion,
        awayRegion,
        homeFormation: [...homeLines],
        awayFormation: awayFormation.lines,
      });
    }
  };

  const back = () => (step === 0 ? onBack() : setStep(step - 1));

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape" && step > 0) {
        event.preventDefault();
        event.stopPropagation();
        setStep((value) => value - 1);
      }
      if (event.key === "Enter" && !(event.target as HTMLElement | null)?.closest("button, input, select")) {
        event.preventDefault();
        next();
      }
    };
    window.addEventListener("keydown", onKeyDown, true);
    return () => window.removeEventListener("keydown", onKeyDown, true);
  });

  return (
    <section className="career-setup" aria-label="Career mode setup">
      <ScreenHeading
        eyebrow="CAREER MODE / UI DESIGN"
        title="MATCH SETUP"
        subtitle="Build your fixture, step by step."
        index={`0${step + 1}`}
        onBack={back}
      />

      <ol className="setup-stepper">
        {STEPS.map((label, index) => (
          <li key={label} className={`${index === step ? "current" : ""} ${index < step ? "done" : ""}`}>
            <button disabled={index > step} onClick={() => setStep(index)}>
              <span>{index < step ? <Check size={11} /> : `0${index + 1}`}</span>
              {label}
            </button>
          </li>
        ))}
      </ol>

      <div className="setup-body" key={step}>
        {step === 0 && (
          <div className="type-grid">
            {([
              {
                id: "friendly" as const,
                title: "FRIENDLY",
                icon: Clock3,
                copy: "Design a full international friendly with your own teams, formations and matchday presentation.",
                tag: "90 MIN · MATCH PREVIEW",
              },
              {
                id: "penalty" as const,
                title: "PENALTY",
                icon: Target,
                copy: "Design the shootout screen. Five rounds, national flags and your chosen team identity.",
                tag: "SHOOTOUT · PREVIEW",
              },
            ]).map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  className={`type-card ${type === item.id ? "selected" : ""}`}
                  onClick={() => {
                    setType(item.id);
                    setStep(1);
                  }}
                >
                  <span className="type-card-icon"><Icon size={26} /></span>
                  <span className="type-card-tag">{item.tag}</span>
                  <strong>{item.title}</strong>
                  <p>{item.copy}</p>
                  <span className="type-card-cta">SELECT <ChevronRight size={14} /></span>
                </button>
              );
            })}
          </div>
        )}

        {step === 1 && (
          <div className="region-grid">
            {REGIONS.map((item) => (
              <button
                key={item.id}
                className={`region-card ${regionId === item.id ? "selected" : ""}`}
                onClick={() => {
                  selectRegion(item.id);
                  setStep(2);
                }}
              >
                <span className="region-card-top">
                  <Globe2 size={16} />
                  <small>{item.nationCount} NATIONS</small>
                </span>
                <strong>{item.name}</strong>
                <p>{item.subtitle}</p>
                <span className="region-flags">
                  {item.nations.slice(0, 5).map((nation) => (
                    <Flag key={nation.code} code={nation.code} title={nation.name} />
                  ))}
                  <em>+{item.nations.length - 5}</em>
                </span>
              </button>
            ))}
          </div>
        )}

        {step === 2 && (
          <div className="teams-step">
            <div className="cross-region-note">
              <Info size={14} />
              <span>Each team has its own region selector — you can match Africa against Europe, Europe against the Americas, or any other combination.</span>
            </div>

            <div className="team-slots">
              {(["home", "away"] as const).map((side) => {
                const nation = side === "home" ? home : away;
                return (
                  <button
                    key={side}
                    className={`team-slot ${slot === side ? "active" : ""} ${nation ? "filled" : ""}`}
                    onClick={() => setSlot(side)}
                  >
                    <span className="team-slot-label">{side === "home" ? "TEAM A · YOU" : "TEAM B · OPPONENT"}</span>
                    {nation ? (
                      <span className="team-slot-nation">
                        <Flag code={nation.code} title={nation.name} />
                        <span>
                          <strong>{nation.name.toUpperCase()}</strong>
                          <small>{REGIONS.find((r) => r.id === (side === "home" ? homeRegion : awayRegion))?.name} · OVR {nation.rating}</small>
                        </span>
                      </span>
                    ) : (
                      <span className="team-slot-empty">{slot === side ? "Choose a nation below" : "Tap to choose"}</span>
                    )}
                  </button>
                );
              })}
              <div className="team-slot-tools">
                <button onClick={() => { setHome(away); setAway(home); setHomeRegion(awayRegion); setAwayRegion(homeRegion); }} aria-label="Swap teams"><ArrowLeftRight size={14} /></button>
                <button onClick={randomTeams} aria-label="Random teams"><Shuffle size={14} /></button>
              </div>
            </div>

            <div className="team-region-row">
              <span className="nation-hint">
                Selecting <b>{slot === "home" ? "TEAM A" : "TEAM B"}</b> region
              </span>
              <div className="team-region-tabs">
                {REGIONS.map((item) => (
                  <button
                    key={item.id}
                    className={activeRegionId === item.id ? "selected" : ""}
                    onClick={() => switchSlotRegion(item.id)}
                  >
                    {item.name}
                    <small>{item.nationCount}</small>
                  </button>
                ))}
              </div>
            </div>

            <div className="nation-grid">
              {activeRegion.nations.map((nation, index) => {
                const isHome = home?.code === nation.code;
                const isAway = away?.code === nation.code;
                return (
                  <button
                    key={nation.code}
                    className={`nation-card ${isHome ? "is-home" : ""} ${isAway ? "is-away" : ""}`}
                    style={{ "--i": index } as CSSProperties}
                    onClick={() => pickNation(nation)}
                    aria-pressed={isHome || isAway}
                  >
                    <Flag code={nation.code} title={nation.name} className="nation-flag" />
                    <span className="nation-meta">
                      <strong>{nation.name}</strong>
                      <small>{nation.short} · OVR {nation.rating}</small>
                    </span>
                    {(isHome || isAway) && <span className="nation-badge">{isHome ? "A" : "B"}</span>}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {step === 3 && home && away && (
          <div className="formation-step">
            <div className="formation-left">
              <div className="fixture-strip">
                <span><Flag code={home.code} title={home.name} /> {home.name.toUpperCase()}</span>
                <em>VS</em>
                <span>{away.name.toUpperCase()} <Flag code={away.code} title={away.name} /></span>
              </div>

              <span className="formation-label">PRESET FORMATIONS</span>
              <div className="formation-presets">
                {FORMATIONS.map((formation) => (
                  <button
                    key={formation.id}
                    className={formationId === formation.id ? "selected" : ""}
                    onClick={() => setFormationId(formation.id)}
                    title={formation.style}
                  >
                    {formation.name}
                  </button>
                ))}
              </div>

              <span className="formation-label">
                CUSTOM SHAPE <small>Arrange your own — always 10 outfield players + goalkeeper</small>
              </span>
              <div className={`custom-builder ${formationId === "custom" ? "active" : ""}`}>
                {(["DEFENDERS", "MIDFIELDERS", "FORWARDS"] as const).map((label, index) => (
                  <div className="custom-row" key={label}>
                    <span>{label}</span>
                    <div>
                      <button onClick={() => adjustLine(index as 0 | 1 | 2, -1)} aria-label={`Fewer ${label.toLowerCase()}`}><Minus size={13} /></button>
                      <b>{customLines[index]}</b>
                      <button onClick={() => adjustLine(index as 0 | 1 | 2, 1)} aria-label={`More ${label.toLowerCase()}`}><Plus size={13} /></button>
                    </div>
                  </div>
                ))}
                <button className="custom-use" onClick={() => setFormationId("custom")}>
                  {formationId === "custom" ? <><Check size={13} /> USING {formationName(customLines)}</> : <>USE {formationName(customLines)}</>}
                </button>
              </div>

              <div className="formation-bars">
                {[
                  { label: "ATTACK", value: profile.attack },
                  { label: "DEFENCE", value: profile.defence },
                  { label: "CONTROL", value: profile.control },
                ].map((bar) => (
                  <div key={bar.label}>
                    <span>{bar.label}</span>
                    <i><b style={{ width: `${Math.min(100, bar.value * 62)}%` }} /></i>
                  </div>
                ))}
              </div>
            </div>

            <div className="formation-right">
              <div className="formation-pitch-head">
                <span><Flag code={home.code} title={home.name} /> {formationName(homeLines)}</span>
                <small>{formationId === "custom" ? "Your custom shape" : FORMATIONS.find((f) => f.id === formationId)?.style}</small>
              </div>
              <FormationPitch lines={homeLines} color={home.kit} label={home.name} players={homeXI} />
              <div className="opponent-shape">
                <Flag code={away.code} title={away.name} /> {away.name} will line up in <b>{awayFormation.name}</b>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="setup-footer-bar">
        <button className="back-to-menu-btn" onClick={back}>
          <ChevronLeft size={13} /> {step === 0 ? "BACK TO GAME MODES" : "PREVIOUS STEP"}
        </button>
        <div className="setup-summary">
          {type && <span>{type === "friendly" ? "FRIENDLY" : "PENALTY"}</span>}
          {home && away && <span>{home.short} vs {away.short}</span>}
          {home && away && <span>FORMATION {formationName(homeLines)}</span>}
        </div>
        <button className="apply-changes-btn" disabled={!canContinue} onClick={next}>
          {step === 3 ? <><Eye size={14} /> PREVIEW MATCH</> : <>CONTINUE <ChevronRight size={14} /></>}
        </button>
      </div>
    </section>
  );
}
