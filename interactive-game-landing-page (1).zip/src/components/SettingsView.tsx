import { useState, useEffect, useRef } from "react";
import {
  Volume2,
  LayoutGrid,
  Camera,
  Play,
  Settings as SettingsIcon,
  Globe,
  User,
  Info,
  Check,
  RotateCcw,
  ChevronRight,
  ChevronDown,
  ChevronLeft,
  Maximize,
  AlertTriangle,
} from "lucide-react";
import type { Difficulty } from "../gameData";

export interface GameSettings {
  // Audio
  masterVolume: number;
  musicVolume: number;
  commentaryVolume: number;
  crowdVolume: number;
  sfxVolume: number;
  menuSound: boolean;
  commentaryEnabled: boolean;
  audioOutput: string;
  muted: boolean;

  // Controls
  controllerPreset: string;
  vibration: boolean;
  assistedShooting: boolean;
  shotPowerSensitivity: number;
  autoKeeperAssist: number;
  keyboardHotkeys: boolean;

  // Camera
  cameraAngle: string;
  cameraHeight: number;
  cameraZoom: number;
  cameraShake: boolean;
  proKeeperView: boolean;

  // Gameplay
  difficulty: Difficulty;
  gameSpeed: string;
  shotMeterSpeed: number;
  suddenDeath: boolean;
  scoutingTips: boolean;

  // Graphics
  quality: "high" | "balanced" | "performance";
  stadiumLighting: number;
  motionBlur: boolean;
  pitchDetail: boolean;

  // Language
  language: string;
  commentaryLanguage: string;
  subtitles: boolean;
  stadiumAnnouncer: boolean;

  // Accessibility
  reducedMotion: boolean;
  highContrast: boolean;
  largeHud: boolean;
  colorblindFilter: string;
  singleButtonKick: boolean;

  // Account
  cloudSync: boolean;
  crossplay: boolean;
  telemetry: boolean;
}

export const DEFAULT_SETTINGS: GameSettings = {
  // Audio (matches screenshot numbers exactly)
  masterVolume: 88,
  musicVolume: 64,
  commentaryVolume: 78,
  crowdVolume: 86,
  sfxVolume: 82,
  menuSound: true,
  commentaryEnabled: true,
  audioOutput: "STEREO HEADPHONES",
  muted: false,

  // Controls
  controllerPreset: "CLASSIC SHOOTER",
  vibration: true,
  assistedShooting: true,
  shotPowerSensitivity: 75,
  autoKeeperAssist: 50,
  keyboardHotkeys: true,

  // Camera
  cameraAngle: "BROADCAST TELE",
  cameraHeight: 60,
  cameraZoom: 45,
  cameraShake: true,
  proKeeperView: false,

  // Gameplay
  difficulty: "pro",
  gameSpeed: "NORMAL (60 FPS)",
  shotMeterSpeed: 70,
  suddenDeath: true,
  scoutingTips: true,

  // Graphics
  quality: "high",
  stadiumLighting: 85,
  motionBlur: false,
  pitchDetail: true,

  // Language
  language: "ENGLISH (US)",
  commentaryLanguage: "ENGLISH (UK)",
  subtitles: true,
  stadiumAnnouncer: true,

  // Accessibility
  reducedMotion: false,
  highContrast: false,
  largeHud: false,
  colorblindFilter: "NONE",
  singleButtonKick: false,

  // Account
  cloudSync: true,
  crossplay: true,
  telemetry: true,
};

interface SettingsCategory {
  id: string;
  number: string;
  title: string;
  icon: typeof Volume2;
  eyebrow: string;
  subtitle: string;
}

const CATEGORIES: SettingsCategory[] = [
  {
    id: "audio",
    number: "01",
    title: "AUDIO",
    icon: Volume2,
    eyebrow: "MATCHDAY ATMOSPHERE",
    subtitle: "Shape every chant, call and collision",
  },
  {
    id: "controls",
    number: "02",
    title: "CONTROLS",
    icon: LayoutGrid,
    eyebrow: "INPUT & CONFIGURATION",
    subtitle: "Configure controller presets, shot sensitivity and vibration feedback",
  },
  {
    id: "camera",
    number: "03",
    title: "CAMERA",
    icon: Camera,
    eyebrow: "BROADCAST PERSPECTIVE",
    subtitle: "Tune broadcast camera height, stadium zoom and impact effects",
  },
  {
    id: "gameplay",
    number: "04",
    title: "GAMEPLAY",
    icon: Play,
    eyebrow: "MATCH SIMULATION",
    subtitle: "Fine-tune match pace, keeper AI reaction curves and shootout rules",
  },
  {
    id: "graphics",
    number: "05",
    title: "GRAPHICS",
    icon: SettingsIcon,
    eyebrow: "VISUAL PERFORMANCE",
    subtitle: "Balance frame rate, post-processing and stadium illumination",
  },
  {
    id: "language",
    number: "06",
    title: "LANGUAGE",
    icon: Globe,
    eyebrow: "LOCALIZATION & REGION",
    subtitle: "Select in-game text language and commentary voices",
  },
  {
    id: "accessibility",
    number: "07",
    title: "ACCESSIBILITY",
    icon: User,
    eyebrow: "INCLUSIVE PLAY",
    subtitle: "Assistance features, contrast modes and motor aids",
  },
  {
    id: "account",
    number: "08",
    title: "ACCOUNT",
    icon: Info,
    eyebrow: "PROFILE & DATA",
    subtitle: "Manage player identity, local data sync and privacy permissions",
  },
];

interface SettingsViewProps {
  settings: GameSettings;
  playerName?: string;
  playerInitials?: string;
  accountId?: string;
  onApply: (settings: GameSettings) => void;
  onResetDefaults: () => void;
  onBack: () => void;
  onHome: () => void;
  onClearSave?: () => void;
  onToggleFullscreen?: () => void;
  playSound?: (sound: "click" | "whistle" | "kick" | "goal" | "save") => void;
}

export default function SettingsView({
  settings,
  playerName = "VELOCITY PLAYER",
  playerInitials = "VF",
  accountId = "VF-000001",
  onApply,
  onResetDefaults,
  onBack,
  onHome,
  onClearSave,
  onToggleFullscreen,
  playSound,
}: SettingsViewProps) {
  const [activeCategory, setActiveCategory] = useState(0);
  const [localSettings, setLocalSettings] = useState<GameSettings>({ ...settings });
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const categoryRefs = useRef<(HTMLButtonElement | null)[]>([]);

  // Update local settings when prop changes
  useEffect(() => {
    setLocalSettings({ ...settings });
    setHasUnsavedChanges(false);
  }, [settings]);

  const update = <K extends keyof GameSettings>(key: K, value: GameSettings[K]) => {
    setLocalSettings((prev) => ({ ...prev, [key]: value }));
    setHasUnsavedChanges(true);
  };

  const resetCurrentCategory = () => {
    const cat = CATEGORIES[activeCategory].id;
    playSound?.("click");
    if (cat === "audio") {
      setLocalSettings((prev) => ({
        ...prev,
        masterVolume: DEFAULT_SETTINGS.masterVolume,
        musicVolume: DEFAULT_SETTINGS.musicVolume,
        commentaryVolume: DEFAULT_SETTINGS.commentaryVolume,
        crowdVolume: DEFAULT_SETTINGS.crowdVolume,
        sfxVolume: DEFAULT_SETTINGS.sfxVolume,
        menuSound: DEFAULT_SETTINGS.menuSound,
        commentaryEnabled: DEFAULT_SETTINGS.commentaryEnabled,
        audioOutput: DEFAULT_SETTINGS.audioOutput,
      }));
    } else if (cat === "controls") {
      setLocalSettings((prev) => ({
        ...prev,
        controllerPreset: DEFAULT_SETTINGS.controllerPreset,
        vibration: DEFAULT_SETTINGS.vibration,
        assistedShooting: DEFAULT_SETTINGS.assistedShooting,
        shotPowerSensitivity: DEFAULT_SETTINGS.shotPowerSensitivity,
        autoKeeperAssist: DEFAULT_SETTINGS.autoKeeperAssist,
        keyboardHotkeys: DEFAULT_SETTINGS.keyboardHotkeys,
      }));
    } else if (cat === "camera") {
      setLocalSettings((prev) => ({
        ...prev,
        cameraAngle: DEFAULT_SETTINGS.cameraAngle,
        cameraHeight: DEFAULT_SETTINGS.cameraHeight,
        cameraZoom: DEFAULT_SETTINGS.cameraZoom,
        cameraShake: DEFAULT_SETTINGS.cameraShake,
        proKeeperView: DEFAULT_SETTINGS.proKeeperView,
      }));
    } else if (cat === "gameplay") {
      setLocalSettings((prev) => ({
        ...prev,
        difficulty: DEFAULT_SETTINGS.difficulty,
        gameSpeed: DEFAULT_SETTINGS.gameSpeed,
        shotMeterSpeed: DEFAULT_SETTINGS.shotMeterSpeed,
        suddenDeath: DEFAULT_SETTINGS.suddenDeath,
        scoutingTips: DEFAULT_SETTINGS.scoutingTips,
      }));
    } else if (cat === "graphics") {
      setLocalSettings((prev) => ({
        ...prev,
        quality: DEFAULT_SETTINGS.quality,
        stadiumLighting: DEFAULT_SETTINGS.stadiumLighting,
        motionBlur: DEFAULT_SETTINGS.motionBlur,
        pitchDetail: DEFAULT_SETTINGS.pitchDetail,
      }));
    } else if (cat === "language") {
      setLocalSettings((prev) => ({
        ...prev,
        language: DEFAULT_SETTINGS.language,
        commentaryLanguage: DEFAULT_SETTINGS.commentaryLanguage,
        subtitles: DEFAULT_SETTINGS.subtitles,
        stadiumAnnouncer: DEFAULT_SETTINGS.stadiumAnnouncer,
      }));
    } else if (cat === "accessibility") {
      setLocalSettings((prev) => ({
        ...prev,
        reducedMotion: DEFAULT_SETTINGS.reducedMotion,
        highContrast: DEFAULT_SETTINGS.highContrast,
        largeHud: DEFAULT_SETTINGS.largeHud,
        colorblindFilter: DEFAULT_SETTINGS.colorblindFilter,
        singleButtonKick: DEFAULT_SETTINGS.singleButtonKick,
      }));
    } else if (cat === "account") {
      setLocalSettings((prev) => ({
        ...prev,
        cloudSync: DEFAULT_SETTINGS.cloudSync,
        crossplay: DEFAULT_SETTINGS.crossplay,
        telemetry: DEFAULT_SETTINGS.telemetry,
      }));
    }
    setHasUnsavedChanges(true);
  };

  const handleApply = () => {
    playSound?.("whistle");
    onApply(localSettings);
    setHasUnsavedChanges(false);
  };

  const handleResetAll = () => {
    playSound?.("click");
    setLocalSettings({ ...DEFAULT_SETTINGS });
    onResetDefaults();
    setHasUnsavedChanges(false);
  };

  // Keyboard navigation for categories
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target?.closest("input, select, textarea")) return;

      if (e.key === "ArrowUp") {
        e.preventDefault();
        setActiveCategory((prev) => (prev > 0 ? prev - 1 : CATEGORIES.length - 1));
      } else if (e.key === "ArrowDown") {
        e.preventDefault();
        setActiveCategory((prev) => (prev < CATEGORIES.length - 1 ? prev + 1 : 0));
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  const currentCat = CATEGORIES[activeCategory];

  return (
    <section className="settings-screen" aria-label="Game Settings">
      {/* Top Breadcrumb & Heading (Matches Screenshot) */}
      <button className="screen-back" onClick={onBack}>
        <ChevronLeft size={12} /> BACK
      </button>

      <div className="screen-heading">
        <div>
          <div className="eyebrow screen-eyebrow">
            <span />
            VELOCITY FOOTBALL
          </div>
          <div className="screen-title-row">
            <h1>SETTINGS</h1>
            <p>Fine-tune your experience</p>
          </div>
        </div>
        <span className="screen-index">
          <i>/</i>03
        </span>
      </div>

      {/* Main Settings Two-Column Layout */}
      <div className="settings-main-layout">
        {/* Left Column: Categories List */}
        <aside className="settings-sidebar">
          <span className="settings-sidebar-label">SETTINGS CATEGORIES</span>

          <nav className="settings-category-list" aria-label="Settings Categories">
            {CATEGORIES.map((cat, idx) => {
              const Icon = cat.icon;
              const isSelected = activeCategory === idx;
              return (
                <button
                  key={cat.id}
                  ref={(el) => {
                    categoryRefs.current[idx] = el;
                  }}
                  className={`settings-category-btn ${isSelected ? "is-selected" : ""}`}
                  onClick={() => {
                    setActiveCategory(idx);
                    playSound?.("click");
                  }}
                >
                  <span className="cat-num">{cat.number}</span>
                  <Icon size={16} className="cat-icon" />
                  <span className="cat-title">{cat.title}</span>
                  <ChevronRight size={14} className="cat-arrow" />
                </button>
              );
            })}
          </nav>

          {/* User Profile Sync Chip at bottom of left column (as in screenshot) */}
          <div className="settings-profile-chip">
            <span className="settings-profile-badge">{playerInitials}</span>
            <div className="settings-profile-info">
              <strong>{playerName}</strong>
              <small>PROFILE SYNCED</small>
            </div>
            <Check size={14} className="settings-profile-check" />
          </div>
        </aside>

        {/* Right Column: Active Category Settings Panel */}
        <div className="settings-content-panel glass-panel">
          {/* Panel Header */}
          <div className="settings-panel-header">
            <div>
              <span className="settings-panel-eyebrow">{currentCat.eyebrow}</span>
              <h2>{currentCat.title} SETTINGS</h2>
              <p className="settings-panel-sub">{currentCat.subtitle}</p>
            </div>
            <span className="settings-counter">
              <strong>{currentCat.number}</strong>
              <small>/ 08</small>
            </span>
          </div>

          {/* Panel Body: Category-Specific Options */}
          <div className="settings-panel-body">
            {/* 01 AUDIO */}
            {currentCat.id === "audio" && (
              <div className="settings-rows-group">
                <div className="setting-control-row">
                  <div className="setting-info">
                    <strong>MASTER VOLUME</strong>
                    <small>Overall game audio</small>
                  </div>
                  <div className="slider-container">
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={localSettings.masterVolume}
                      onChange={(e) => update("masterVolume", Number(e.target.value))}
                      className="lime-slider"
                      aria-label="Master Volume"
                    />
                    <span className="slider-value">{localSettings.masterVolume}%</span>
                  </div>
                </div>

                <div className="setting-control-row">
                  <div className="setting-info">
                    <strong>MUSIC VOLUME</strong>
                    <small>Menus and soundtrack</small>
                  </div>
                  <div className="slider-container">
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={localSettings.musicVolume}
                      onChange={(e) => update("musicVolume", Number(e.target.value))}
                      className="lime-slider"
                      aria-label="Music Volume"
                    />
                    <span className="slider-value">{localSettings.musicVolume}%</span>
                  </div>
                </div>

                <div className="setting-control-row">
                  <div className="setting-info">
                    <strong>COMMENTARY</strong>
                    <small>Match commentary team</small>
                  </div>
                  <div className="slider-container">
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={localSettings.commentaryVolume}
                      onChange={(e) => update("commentaryVolume", Number(e.target.value))}
                      className="lime-slider"
                      aria-label="Commentary Volume"
                    />
                    <span className="slider-value">{localSettings.commentaryVolume}%</span>
                  </div>
                </div>

                <div className="setting-control-row">
                  <div className="setting-info">
                    <strong>CROWD VOLUME</strong>
                    <small>Stadium atmosphere</small>
                  </div>
                  <div className="slider-container">
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={localSettings.crowdVolume}
                      onChange={(e) => update("crowdVolume", Number(e.target.value))}
                      className="lime-slider"
                      aria-label="Crowd Volume"
                    />
                    <span className="slider-value">{localSettings.crowdVolume}%</span>
                  </div>
                </div>

                <div className="setting-control-row">
                  <div className="setting-info">
                    <strong>SOUND EFFECTS</strong>
                    <small>Ball, contact and whistles</small>
                  </div>
                  <div className="slider-container">
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={localSettings.sfxVolume}
                      onChange={(e) => update("sfxVolume", Number(e.target.value))}
                      className="lime-slider"
                      aria-label="Sound Effects Volume"
                    />
                    <span className="slider-value">{localSettings.sfxVolume}%</span>
                  </div>
                </div>

                {/* Two side-by-side toggles as shown in screenshot */}
                <div className="setting-toggle-pair-row">
                  <div className="toggle-half-block">
                    <div className="setting-info">
                      <strong>MENU SOUND</strong>
                      <small>Interface navigation feedback</small>
                    </div>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={localSettings.menuSound}
                      className={`pill-toggle ${localSettings.menuSound ? "is-on" : ""}`}
                      onClick={() => update("menuSound", !localSettings.menuSound)}
                    >
                      <span className="pill-knob" />
                    </button>
                  </div>

                  <div className="toggle-half-block">
                    <div className="setting-info">
                      <strong>COMMENTARY</strong>
                      <small>In-match spoken commentary</small>
                    </div>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={localSettings.commentaryEnabled}
                      className={`pill-toggle ${localSettings.commentaryEnabled ? "is-on" : ""}`}
                      onClick={() => update("commentaryEnabled", !localSettings.commentaryEnabled)}
                    >
                      <span className="pill-knob" />
                    </button>
                  </div>
                </div>

                {/* Audio Output Dropdown */}
                <div className="setting-control-row">
                  <div className="setting-info">
                    <strong>AUDIO OUTPUT</strong>
                    <small>Optimized output profile</small>
                  </div>
                  <div className="custom-select-wrapper">
                    <select
                      value={localSettings.audioOutput}
                      onChange={(e) => update("audioOutput", e.target.value)}
                      className="custom-settings-select"
                      aria-label="Audio Output Profile"
                    >
                      <option value="STEREO HEADPHONES">STEREO HEADPHONES</option>
                      <option value="TV SPEAKERS">TV SPEAKERS</option>
                      <option value="STUDIO MONITORS">STUDIO MONITORS</option>
                      <option value="5.1 SURROUND">5.1 SURROUND</option>
                    </select>
                    <ChevronDown size={14} className="select-arrow" />
                  </div>
                </div>
              </div>
            )}

            {/* 02 CONTROLS */}
            {currentCat.id === "controls" && (
              <div className="settings-rows-group">
                <div className="setting-control-row">
                  <div className="setting-info">
                    <strong>CONTROLLER PRESET</strong>
                    <small>Default button layout configuration</small>
                  </div>
                  <div className="custom-select-wrapper">
                    <select
                      value={localSettings.controllerPreset}
                      onChange={(e) => update("controllerPreset", e.target.value)}
                      className="custom-settings-select"
                      aria-label="Controller Preset"
                    >
                      <option value="CLASSIC SHOOTER">CLASSIC SHOOTER</option>
                      <option value="ALTERNATE">ALTERNATE</option>
                      <option value="TWO-BUTTON TACTICAL">TWO-BUTTON TACTICAL</option>
                    </select>
                    <ChevronDown size={14} className="select-arrow" />
                  </div>
                </div>

                <div className="setting-control-row">
                  <div className="setting-info">
                    <strong>SHOT POWER SENSITIVITY</strong>
                    <small>Timing needle oscillation speed</small>
                  </div>
                  <div className="slider-container">
                    <input
                      type="range"
                      min="30"
                      max="100"
                      value={localSettings.shotPowerSensitivity}
                      onChange={(e) => update("shotPowerSensitivity", Number(e.target.value))}
                      className="lime-slider"
                      aria-label="Shot Power Sensitivity"
                    />
                    <span className="slider-value">{localSettings.shotPowerSensitivity}%</span>
                  </div>
                </div>

                <div className="setting-control-row">
                  <div className="setting-info">
                    <strong>GOALKEEPER DIVE ASSIST</strong>
                    <small>Reach window tolerance when diving</small>
                  </div>
                  <div className="slider-container">
                    <input
                      type="range"
                      min="20"
                      max="100"
                      value={localSettings.autoKeeperAssist}
                      onChange={(e) => update("autoKeeperAssist", Number(e.target.value))}
                      className="lime-slider"
                      aria-label="Goalkeeper Assist"
                    />
                    <span className="slider-value">{localSettings.autoKeeperAssist}%</span>
                  </div>
                </div>

                <div className="setting-toggle-pair-row">
                  <div className="toggle-half-block">
                    <div className="setting-info">
                      <strong>VIBRATION / HAPTICS</strong>
                      <small>Impact feedback on post and shots</small>
                    </div>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={localSettings.vibration}
                      className={`pill-toggle ${localSettings.vibration ? "is-on" : ""}`}
                      onClick={() => update("vibration", !localSettings.vibration)}
                    >
                      <span className="pill-knob" />
                    </button>
                  </div>

                  <div className="toggle-half-block">
                    <div className="setting-info">
                      <strong>ASSISTED SHOOTING</strong>
                      <small>Directional stability on full power</small>
                    </div>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={localSettings.assistedShooting}
                      className={`pill-toggle ${localSettings.assistedShooting ? "is-on" : ""}`}
                      onClick={() => update("assistedShooting", !localSettings.assistedShooting)}
                    >
                      <span className="pill-knob" />
                    </button>
                  </div>
                </div>

                <div className="setting-control-row">
                  <div className="setting-info">
                    <strong>KEYBOARD ZONE HOTKEYS (1-9)</strong>
                    <small>Select net targets directly via numpad keys</small>
                  </div>
                  <button
                    type="button"
                    role="switch"
                    aria-checked={localSettings.keyboardHotkeys}
                    className={`pill-toggle ${localSettings.keyboardHotkeys ? "is-on" : ""}`}
                    onClick={() => update("keyboardHotkeys", !localSettings.keyboardHotkeys)}
                  >
                    <span className="pill-knob" />
                  </button>
                </div>
              </div>
            )}

            {/* 03 CAMERA */}
            {currentCat.id === "camera" && (
              <div className="settings-rows-group">
                <div className="setting-control-row">
                  <div className="setting-info">
                    <strong>CAMERA ANGLE</strong>
                    <small>Default in-match broadcast perspective</small>
                  </div>
                  <div className="custom-select-wrapper">
                    <select
                      value={localSettings.cameraAngle}
                      onChange={(e) => update("cameraAngle", e.target.value)}
                      className="custom-settings-select"
                      aria-label="Camera Angle"
                    >
                      <option value="BROADCAST TELE">BROADCAST TELE</option>
                      <option value="TACTICAL HIGH">TACTICAL HIGH</option>
                      <option value="DYNAMIC PITCH">DYNAMIC PITCH</option>
                      <option value="END-TO-END BEHIND">END-TO-END BEHIND</option>
                    </select>
                    <ChevronDown size={14} className="select-arrow" />
                  </div>
                </div>

                <div className="setting-control-row">
                  <div className="setting-info">
                    <strong>CAMERA HEIGHT</strong>
                    <small>Elevation over the penalty spot</small>
                  </div>
                  <div className="slider-container">
                    <input
                      type="range"
                      min="10"
                      max="100"
                      value={localSettings.cameraHeight}
                      onChange={(e) => update("cameraHeight", Number(e.target.value))}
                      className="lime-slider"
                      aria-label="Camera Height"
                    />
                    <span className="slider-value">{localSettings.cameraHeight}%</span>
                  </div>
                </div>

                <div className="setting-control-row">
                  <div className="setting-info">
                    <strong>CAMERA ZOOM</strong>
                    <small>Field of view focal length</small>
                  </div>
                  <div className="slider-container">
                    <input
                      type="range"
                      min="10"
                      max="100"
                      value={localSettings.cameraZoom}
                      onChange={(e) => update("cameraZoom", Number(e.target.value))}
                      className="lime-slider"
                      aria-label="Camera Zoom"
                    />
                    <span className="slider-value">{localSettings.cameraZoom}%</span>
                  </div>
                </div>

                <div className="setting-toggle-pair-row">
                  <div className="toggle-half-block">
                    <div className="setting-info">
                      <strong>CAMERA IMPACT SHAKE</strong>
                      <small>Screen vibration on ball strike</small>
                    </div>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={localSettings.cameraShake}
                      className={`pill-toggle ${localSettings.cameraShake ? "is-on" : ""}`}
                      onClick={() => update("cameraShake", !localSettings.cameraShake)}
                    >
                      <span className="pill-knob" />
                    </button>
                  </div>

                  <div className="toggle-half-block">
                    <div className="setting-info">
                      <strong>PRO KEEPER PERSPECTIVE</strong>
                      <small>Invert camera when diving</small>
                    </div>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={localSettings.proKeeperView}
                      className={`pill-toggle ${localSettings.proKeeperView ? "is-on" : ""}`}
                      onClick={() => update("proKeeperView", !localSettings.proKeeperView)}
                    >
                      <span className="pill-knob" />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* 04 GAMEPLAY */}
            {currentCat.id === "gameplay" && (
              <div className="settings-rows-group">
                <div className="setting-control-row">
                  <div className="setting-info">
                    <strong>MATCH DIFFICULTY</strong>
                    <small>Goalkeeper reads and striker precision</small>
                  </div>
                  <div className="segmented-control">
                    {(["rookie", "pro", "legend"] as Difficulty[]).map((diff) => (
                      <button
                        key={diff}
                        className={localSettings.difficulty === diff ? "selected" : ""}
                        onClick={() => update("difficulty", diff)}
                      >
                        {diff.toUpperCase()}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="setting-control-row">
                  <div className="setting-info">
                    <strong>SIMULATION SPEED</strong>
                    <small>Gameplay pacing and frame simulation</small>
                  </div>
                  <div className="custom-select-wrapper">
                    <select
                      value={localSettings.gameSpeed}
                      onChange={(e) => update("gameSpeed", e.target.value)}
                      className="custom-settings-select"
                      aria-label="Game Speed"
                    >
                      <option value="NORMAL (60 FPS)">NORMAL (60 FPS)</option>
                      <option value="FAST PACED">FAST PACED</option>
                      <option value="TACTICAL REALISM">TACTICAL REALISM</option>
                    </select>
                    <ChevronDown size={14} className="select-arrow" />
                  </div>
                </div>

                <div className="setting-control-row">
                  <div className="setting-info">
                    <strong>POWER METER SPEED</strong>
                    <small>Oscillation frequency of the shot gauge</small>
                  </div>
                  <div className="slider-container">
                    <input
                      type="range"
                      min="30"
                      max="100"
                      value={localSettings.shotMeterSpeed}
                      onChange={(e) => update("shotMeterSpeed", Number(e.target.value))}
                      className="lime-slider"
                      aria-label="Power Meter Speed"
                    />
                    <span className="slider-value">{localSettings.shotMeterSpeed}%</span>
                  </div>
                </div>

                <div className="setting-toggle-pair-row">
                  <div className="toggle-half-block">
                    <div className="setting-info">
                      <strong>SUDDEN DEATH RULE</strong>
                      <small>Continue past round 5 if score is tied</small>
                    </div>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={localSettings.suddenDeath}
                      className={`pill-toggle ${localSettings.suddenDeath ? "is-on" : ""}`}
                      onClick={() => update("suddenDeath", !localSettings.suddenDeath)}
                    >
                      <span className="pill-knob" />
                    </button>
                  </div>

                  <div className="toggle-half-block">
                    <div className="setting-info">
                      <strong>OPPONENT SCOUTING HINTS</strong>
                      <small>Show keeper/striker styles on pitch</small>
                    </div>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={localSettings.scoutingTips}
                      className={`pill-toggle ${localSettings.scoutingTips ? "is-on" : ""}`}
                      onClick={() => update("scoutingTips", !localSettings.scoutingTips)}
                    >
                      <span className="pill-knob" />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* 05 GRAPHICS */}
            {currentCat.id === "graphics" && (
              <div className="settings-rows-group">
                <div className="setting-control-row">
                  <div className="setting-info">
                    <strong>GRAPHICS QUALITY</strong>
                    <small>Texture resolutions and shader level</small>
                  </div>
                  <div className="segmented-control">
                    {(["performance", "balanced", "high"] as const).map((q) => (
                      <button
                        key={q}
                        className={localSettings.quality === q ? "selected" : ""}
                        onClick={() => update("quality", q)}
                      >
                        {q === "performance" ? "LOW" : q === "balanced" ? "MED" : "HIGH"}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="setting-control-row">
                  <div className="setting-info">
                    <strong>STADIUM ILLUMINATION</strong>
                    <small>Floodlight bloom, mist and lens flare</small>
                  </div>
                  <div className="slider-container">
                    <input
                      type="range"
                      min="20"
                      max="100"
                      value={localSettings.stadiumLighting}
                      onChange={(e) => update("stadiumLighting", Number(e.target.value))}
                      className="lime-slider"
                      aria-label="Stadium Illumination"
                    />
                    <span className="slider-value">{localSettings.stadiumLighting}%</span>
                  </div>
                </div>

                <div className="setting-toggle-pair-row">
                  <div className="toggle-half-block">
                    <div className="setting-info">
                      <strong>MOTION BLUR</strong>
                      <small>High velocity ball trail blur</small>
                    </div>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={localSettings.motionBlur}
                      className={`pill-toggle ${localSettings.motionBlur ? "is-on" : ""}`}
                      onClick={() => update("motionBlur", !localSettings.motionBlur)}
                    >
                      <span className="pill-knob" />
                    </button>
                  </div>

                  <div className="toggle-half-block">
                    <div className="setting-info">
                      <strong>PITCH WEAR DETAIL</strong>
                      <small>Turf degradation and penalty spot marks</small>
                    </div>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={localSettings.pitchDetail}
                      className={`pill-toggle ${localSettings.pitchDetail ? "is-on" : ""}`}
                      onClick={() => update("pitchDetail", !localSettings.pitchDetail)}
                    >
                      <span className="pill-knob" />
                    </button>
                  </div>
                </div>

                {onToggleFullscreen && (
                  <div className="setting-control-row">
                    <div className="setting-info">
                      <strong>DISPLAY MODE</strong>
                      <small>Switch between windowed and fullscreen</small>
                    </div>
                    <button className="secondary-action" onClick={onToggleFullscreen}>
                      <Maximize size={14} /> TOGGLE FULLSCREEN
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* 06 LANGUAGE */}
            {currentCat.id === "language" && (
              <div className="settings-rows-group">
                <div className="setting-control-row">
                  <div className="setting-info">
                    <strong>TEXT LANGUAGE</strong>
                    <small>In-game user interface translation</small>
                  </div>
                  <div className="custom-select-wrapper">
                    <select
                      value={localSettings.language}
                      onChange={(e) => update("language", e.target.value)}
                      className="custom-settings-select"
                      aria-label="Text Language"
                    >
                      <option value="ENGLISH (US)">ENGLISH (US)</option>
                      <option value="SWAHILI (KISWAHILI)">SWAHILI (KISWAHILI)</option>
                      <option value="ESPAÑOL">ESPAÑOL</option>
                      <option value="FRANÇAIS">FRANÇAIS</option>
                      <option value="DEUTSCH">DEUTSCH</option>
                      <option value="PORTUGUÊS">PORTUGUÊS</option>
                    </select>
                    <ChevronDown size={14} className="select-arrow" />
                  </div>
                </div>

                <div className="setting-control-row">
                  <div className="setting-info">
                    <strong>COMMENTARY AUDIO</strong>
                    <small>Spoken stadium announcer voicepack</small>
                  </div>
                  <div className="custom-select-wrapper">
                    <select
                      value={localSettings.commentaryLanguage}
                      onChange={(e) => update("commentaryLanguage", e.target.value)}
                      className="custom-settings-select"
                      aria-label="Commentary Language"
                    >
                      <option value="ENGLISH (UK)">ENGLISH (UK)</option>
                      <option value="ENGLISH (US)">ENGLISH (US)</option>
                      <option value="ESPAÑOL LATINO">ESPAÑOL LATINO</option>
                      <option value="FRANÇAIS">FRANÇAIS</option>
                    </select>
                    <ChevronDown size={14} className="select-arrow" />
                  </div>
                </div>

                <div className="setting-toggle-pair-row">
                  <div className="toggle-half-block">
                    <div className="setting-info">
                      <strong>SUBTITLES</strong>
                      <small>Display announcer speech captions</small>
                    </div>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={localSettings.subtitles}
                      className={`pill-toggle ${localSettings.subtitles ? "is-on" : ""}`}
                      onClick={() => update("subtitles", !localSettings.subtitles)}
                    >
                      <span className="pill-knob" />
                    </button>
                  </div>

                  <div className="toggle-half-block">
                    <div className="setting-info">
                      <strong>STADIUM PA CALLS</strong>
                      <small>Public address speaker announcements</small>
                    </div>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={localSettings.stadiumAnnouncer}
                      className={`pill-toggle ${localSettings.stadiumAnnouncer ? "is-on" : ""}`}
                      onClick={() => update("stadiumAnnouncer", !localSettings.stadiumAnnouncer)}
                    >
                      <span className="pill-knob" />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* 07 ACCESSIBILITY */}
            {currentCat.id === "accessibility" && (
              <div className="settings-rows-group">
                <div className="setting-toggle-pair-row">
                  <div className="toggle-half-block">
                    <div className="setting-info">
                      <strong>HIGH CONTRAST INTERFACE</strong>
                      <small>Stronger panel borders & text</small>
                    </div>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={localSettings.highContrast}
                      className={`pill-toggle ${localSettings.highContrast ? "is-on" : ""}`}
                      onClick={() => update("highContrast", !localSettings.highContrast)}
                    >
                      <span className="pill-knob" />
                    </button>
                  </div>

                  <div className="toggle-half-block">
                    <div className="setting-info">
                      <strong>REDUCED MOTION</strong>
                      <small>Disable camera shake & quick pulses</small>
                    </div>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={localSettings.reducedMotion}
                      className={`pill-toggle ${localSettings.reducedMotion ? "is-on" : ""}`}
                      onClick={() => update("reducedMotion", !localSettings.reducedMotion)}
                    >
                      <span className="pill-knob" />
                    </button>
                  </div>
                </div>

                <div className="setting-control-row">
                  <div className="setting-info">
                    <strong>COLORBLIND FILTER</strong>
                    <small>Adjust HUD and team crest contrast</small>
                  </div>
                  <div className="custom-select-wrapper">
                    <select
                      value={localSettings.colorblindFilter}
                      onChange={(e) => update("colorblindFilter", e.target.value)}
                      className="custom-settings-select"
                      aria-label="Colorblind Filter"
                    >
                      <option value="NONE">NONE (DEFAULT)</option>
                      <option value="PROTANOPIA">PROTANOPIA (RED-WEAK)</option>
                      <option value="DEUTERANOPIA">DEUTERANOPIA (GREEN-WEAK)</option>
                      <option value="TRITANOPIA">TRITANOPIA (BLUE-WEAK)</option>
                    </select>
                    <ChevronDown size={14} className="select-arrow" />
                  </div>
                </div>

                <div className="setting-toggle-pair-row">
                  <div className="toggle-half-block">
                    <div className="setting-info">
                      <strong>LARGE HUD ICONS</strong>
                      <small>Increase scoreboard & target sizes</small>
                    </div>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={localSettings.largeHud}
                      className={`pill-toggle ${localSettings.largeHud ? "is-on" : ""}`}
                      onClick={() => update("largeHud", !localSettings.largeHud)}
                    >
                      <span className="pill-knob" />
                    </button>
                  </div>

                  <div className="toggle-half-block">
                    <div className="setting-info">
                      <strong>SINGLE-BUTTON KICK</strong>
                      <small>Simplified one-tap shot mechanics</small>
                    </div>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={localSettings.singleButtonKick}
                      className={`pill-toggle ${localSettings.singleButtonKick ? "is-on" : ""}`}
                      onClick={() => update("singleButtonKick", !localSettings.singleButtonKick)}
                    >
                      <span className="pill-knob" />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* 08 ACCOUNT */}
            {currentCat.id === "account" && (
              <div className="settings-rows-group">
                <div className="setting-control-row">
                  <div className="setting-info">
                    <strong>PLAYER IDENTITY</strong>
                    <small>Official Velocity Football license holder</small>
                  </div>
                  <span className="account-tag">{playerName} • #{accountId}</span>
                </div>

                <div className="setting-toggle-pair-row">
                  <div className="toggle-half-block">
                    <div className="setting-info">
                      <strong>LOCAL DATA SYNC</strong>
                      <small>Auto-save career to this browser</small>
                    </div>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={localSettings.cloudSync}
                      className={`pill-toggle ${localSettings.cloudSync ? "is-on" : ""}`}
                      onClick={() => update("cloudSync", !localSettings.cloudSync)}
                    >
                      <span className="pill-knob" />
                    </button>
                  </div>

                  <div className="toggle-half-block">
                    <div className="setting-info">
                      <strong>CROSS-PLAY MATCHMAKING</strong>
                      <small>Connect with all player pools</small>
                    </div>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={localSettings.crossplay}
                      className={`pill-toggle ${localSettings.crossplay ? "is-on" : ""}`}
                      onClick={() => update("crossplay", !localSettings.crossplay)}
                    >
                      <span className="pill-knob" />
                    </button>
                  </div>
                </div>

                <div className="setting-control-row">
                  <div className="setting-info">
                    <strong>ANONYMOUS TELEMETRY</strong>
                    <small>Send performance diagnostic logs to McGregor Studio</small>
                  </div>
                  <button
                    type="button"
                    role="switch"
                    aria-checked={localSettings.telemetry}
                    className={`pill-toggle ${localSettings.telemetry ? "is-on" : ""}`}
                    onClick={() => update("telemetry", !localSettings.telemetry)}
                  >
                    <span className="pill-knob" />
                  </button>
                </div>

                {onClearSave && (
                  <div className="danger-zone-row">
                    <div>
                      <strong>RESET CAREER & GAME SAVE</strong>
                      <small>Irreversibly clears matches, coins and unlocks</small>
                    </div>
                    <button
                      className="danger-btn"
                      onClick={() => setShowClearConfirm(true)}
                    >
                      <AlertTriangle size={13} /> CLEAR DATA
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Reset Current Category Button (Matches Screenshot: [Gear icon] RESET AUDIO SETTINGS) */}
            <div className="settings-reset-cat-wrap">
              <button
                className="reset-category-btn"
                onClick={resetCurrentCategory}
                aria-label={`Reset ${currentCat.title} Settings`}
              >
                <RotateCcw size={13} className="reset-cat-icon" />
                RESET {currentCat.title} SETTINGS
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Action Footer (Matches Screenshot) */}
      <div className="settings-bottom-bar">
        <button className="back-to-menu-btn" onClick={onHome}>
          <ChevronLeft size={13} /> BACK TO MAIN MENU
        </button>

        <div className="settings-bottom-actions">
          <button className="reset-default-btn" onClick={handleResetAll}>
            RESET TO DEFAULT
          </button>
          <button
            className={`apply-changes-btn ${hasUnsavedChanges ? "has-changes" : ""}`}
            onClick={handleApply}
          >
            <Check size={14} /> APPLY CHANGES
          </button>
        </div>
      </div>

      {/* Clear Data Confirmation Modal */}
      {showClearConfirm && (
        <div className="modal-backdrop" onClick={() => setShowClearConfirm(false)}>
          <section
            className="modal confirm-modal"
            role="dialog"
            aria-modal="true"
            aria-label="Confirm data reset"
            onClick={(e) => e.stopPropagation()}
          >
            <span className="confirm-icon">
              <AlertTriangle size={24} className="text-lime" />
            </span>
            <span className="eyebrow">DANGER ZONE</span>
            <h2>CLEAR ALL DATA?</h2>
            <p>
              This will reset all career weeks, cup trophies, coin balances, and unlocks back to initial state.
            </p>
            <div className="confirm-actions">
              <button className="secondary-action" onClick={() => setShowClearConfirm(false)}>
                CANCEL
              </button>
              <button
                className="primary-action"
                style={{ background: "#ff4d4d", color: "#fff" }}
                onClick={() => {
                  setShowClearConfirm(false);
                  onClearSave?.();
                }}
              >
                CONFIRM RESET
              </button>
            </div>
          </section>
        </div>
      )}
    </section>
  );
}
