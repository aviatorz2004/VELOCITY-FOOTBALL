import type { Nation, RegionId } from "./careerData";
import { REGIONS } from "./careerData";

export type Position = "GK" | "CB" | "LB" | "RB" | "CDM" | "CM" | "CAM" | "LW" | "RW" | "ST";
export type PositionGroup = "GK" | "DEF" | "MID" | "FWD";

export interface Player {
  id: string;
  name: string;
  shortName: string;
  position: Position;
  group: PositionGroup;
  number: number;
  rating: number;
  age: number;
  foot: "L" | "R";
  form: 1 | 2 | 3 | 4 | 5;
  fitness: number;
  caps: number;
  goals: number;
}

export const POSITION_GROUP: Record<Position, PositionGroup> = {
  GK: "GK",
  CB: "DEF",
  LB: "DEF",
  RB: "DEF",
  CDM: "MID",
  CM: "MID",
  CAM: "MID",
  LW: "FWD",
  RW: "FWD",
  ST: "FWD",
};

const NAME_POOLS: Record<string, { first: string[]; last: string[] }> = {
  africaEast: {
    first: ["Juma", "Baraka", "Hassan", "Amani", "Kelvin", "Mbwana", "Simon", "Farid", "Victor", "Michael", "Said", "Bernard", "Emmanuel", "Ally", "Feisal", "Dickson"],
    last: ["Mwinyi", "Samatta", "Msuva", "Kapombe", "Olunga", "Wanyama", "Omolo", "Mtui", "Kayuni", "Okello", "Ochieng", "Mayele", "Ngoma", "Salum", "Mkude", "Kamau", "Kipande", "Mushi", "Rutonda", "Mollel", "Mukasa", "Omondi", "Muhwezi", "Achieng", "Macharia", "Nyandiko"],
  },
  africaWest: {
    first: ["Kwame", "Kofi", "Sadio", "Ismaila", "Chukwu", "Victor", "Ademola", "Mohammed", "Seydou", "Ibrahima", "Thomas", "Kalidou", "Andre", "Franck", "Nicolas", "Wilfried"],
    last: ["Mensah", "Osimhen", "Mane", "Sarr", "Koulibaly", "Ayew", "Kudus", "Partey", "Lookman", "Iwobi", "Gueye", "Diallo", "Zaha", "Kessie", "Haller", "Onana", "Barkley", "Adeyemi", "Balo", "Ndiaye", "Fofana", "Mendy", "Toure", "Sow", "Trape", "Kamara"],
  },
  africaNorth: {
    first: ["Achraf", "Youssef", "Mohamed", "Riyad", "Hakim", "Sofyan", "Yassine", "Omar", "Ismael", "Nayef", "Aissa", "Hannibal", "Wahbi", "Mostafa", "Trezeguet", "Amine"],
    last: ["Hakimi", "En-Nesyri", "Salah", "Mahrez", "Ziyech", "Amrabat", "Bounou", "Marmoush", "Bennacer", "Aguerd", "Mandi", "Mejbri", "Khazri", "Mohamed", "Harit", "Elneny", "Ghoulam", "Brahimi", "Slimani", "Mazraoui", "Hajri", "Aboukhal", "En-Yami", "Chamakh", "Labyad", "Zouhri"],
  },
  africaSouth: {
    first: ["Percy", "Themba", "Ronwen", "Teboho", "Lyle", "Thapelo", "Bongani", "Sipho", "Khuliso", "Mothobi", "Evidence", "Siyanda", "Nkosinathi", "Grant", "Elias", "Aubrey"],
    last: ["Tau", "Zwane", "Williams", "Mokoena", "Foster", "Morena", "Zungu", "Mudau", "Mvala", "Makgopa", "Sibisi", "Xulu", "Modiba", "Kekana", "Mobbie", "Faka", "Ramphele", "Buthelezi", "Nkosi", "Mahlangu", "Mofokeng", "Kokolo", "Baloyi", "Mogale", "Sithole", "Ndlovu"],
  },
  europeWest: {
    first: ["Kylian", "Antoine", "Jamal", "Florian", "Pedro", "Rodrigo", "Federico", "Nicolo", "Bruno", "Rafael", "Cody", "Xavi", "Kevin", "Jeremy", "Luka", "Granit"],
    last: ["Dupont", "Lefevre", "Muller", "Schneider", "Garcia", "Fernandez", "Rossi", "Bianchi", "Silva", "Costa", "De Jong", "Bakker", "Mertens", "Peeters", "Horvat", "Xhaka", "Lacazette", "Rabiot", "Kounde", "Sissoko", "Camara", "Zubiaurre", "Thiaw", "Nkunku", "Grimaldo", "Dembele"],
  },
  europeNorth: {
    first: ["Rasmus", "Christian", "Alexander", "Viktor", "Erling", "Martin", "Robert", "Piotr", "David", "Marcel", "Dusan", "Sergej", "Hakan", "Arda", "Oleksandr", "Patrik"],
    last: ["Hojlund", "Eriksen", "Isak", "Gyokeres", "Haaland", "Odegaard", "Lewandowski", "Zielinski", "Alaba", "Sabitzer", "Vlahovic", "Milinkovic", "Calhanoglu", "Guler", "Zinchenko", "Schick", "Dahl", "Olsen", "Madsen", "Larsen", "Jorgensen", "Kjaer", "Lindelof", "Kristiansen", "Elyasou", "Pjaca"],
  },
  europeSouth: {
    first: ["Giorgos", "Tasos", "Kiril", "Benjamin", "Jan", "Milan", "Edin", "Stevan", "Eljif", "Armando", "Teemu", "Lukas", "Nikola", "Dimitris", "Ondrej", "Petar"],
    last: ["Giakoumakis", "Bakasetas", "Despodov", "Sesko", "Oblak", "Skriniar", "Dzeko", "Jovetic", "Elmas", "Broja", "Pukki", "Hradecky", "Vlasic", "Pelkas", "Duda", "Musa", "Mitrovic", "Stefanovic", "Krunic", "Hamsik", "Kozak", "Hlozek", "Kral", "Pavlovic", "Ljajic", "Tadic"],
  },
  americasNorth: {
    first: ["Santiago", "Hirving", "Edson", "Christian", "Weston", "Tyler", "Alphonso", "Jonathan", "Leon", "Keylor", "Joel", "Adalberto", "Alberth", "Luis", "Onel", "Kevin"],
    last: ["Gimenez", "Lozano", "Alvarez", "Pulisic", "McKennie", "Adams", "Davies", "David", "Bailey", "Navas", "Campbell", "Carrasquilla", "Elis", "Palma", "Hernandez", "Molino", "Paredes", "Arias", "Castro", "Torres", "Vasquez", "Rojas", "Quintero", "Pineda", "Chavarria", "Fuentes"],
  },
  americasSouth: {
    first: ["Vinicius", "Rodrygo", "Lionel", "Julian", "Enzo", "Darwin", "Federico", "Luis", "James", "Alexis", "Enner", "Moises", "Paolo", "Salomon", "Miguel", "Gustavo"],
    last: ["Junior", "Goes", "Messi", "Alvarez", "Fernandez", "Nunez", "Valverde", "Diaz", "Rodriguez", "Sanchez", "Valencia", "Caicedo", "Guerrero", "Rondon", "Almiron", "Gomez", "Silva", "Martinez", "Pereira", "Soto", "Aguero", "Llorente", "Mondragon", "Vega", "Machado", "Paz"],
  },
  asiaEast: {
    first: ["Takefusa", "Kaoru", "Son", "Lee", "Kim", "Wu", "Chanathip", "Nguyen", "Egy", "Safawi", "Sunil", "Baktiyor", "Eldor", "Neil", "Hwang", "Ritsu"],
    last: ["Kubo", "Mitoma", "Heung-min", "Kang-in", "Min-jae", "Lei", "Songkrasin", "Quang Hai", "Maulana", "Rasid", "Chhetri", "Zaynutdinov", "Shomurodov", "Etheridge", "Hee-chan", "Doan", "Endo", "Sakai", "Ito", "Ono", "Kawabe", "Wong", "Supachok", "Tuan", "Dinh", "Mamadov"],
  },
  middleEast: {
    first: ["Salem", "Mehdi", "Akram", "Ali", "Aymen", "Mousa", "Yousef", "Issam", "Abdullah", "Sardar", "Firas", "Hassan", "Saleh", "Fahad", "Mohanad", "Khalid"],
    last: ["Al-Dawsari", "Taremi", "Afif", "Mabkhout", "Hussein", "Al-Tamari", "Nasser", "Al-Sabhi", "Al-Hamdan", "Azmoun", "Al-Buraikan", "Al-Haidos", "Al-Shehri", "Al-Muwallad", "Ali", "Al-Ghannam", "Al-Bulaihi", "Khan", "Jassim", "Al-Mathrashi", "Khaled", "Al-Abdulkarim", "Nouri", "Shahin", "Al-Rashidi", "Faisal"],
  },
  oceania: {
    first: ["Mathew", "Jackson", "Chris", "Liberato", "Roy", "Raphael", "Micah", "Brian", "Kevin", "Gagame", "Ben", "Jai", "Roberto", "Sione", "Tevita", "Alex"],
    last: ["Ryan", "Irvine", "Wood", "Cacace", "Krishna", "Lea'alafa", "Taumoepeau", "Kaltak", "Houma", "Feni", "Waine", "Ingham", "Nicolas", "Taufa", "Filo", "Paulsen", "Koloai", "Ma'afu", "Vunipola", "Sopape", "Ratuni", "Kareia", "Dua", "Lolohea", "Tui", "Pita"],
  },
};

function poolForNation(nation: Nation, regionId: RegionId) {
  if (regionId === "africa") {
    if (["KE", "TZ", "UG"].includes(nation.code)) return NAME_POOLS.africaEast;
    if (["EG", "MA", "DZ", "TN"].includes(nation.code)) return NAME_POOLS.africaNorth;
    if (nation.code === "ZA") return NAME_POOLS.africaSouth;
    return NAME_POOLS.africaWest;
  }
  if (regionId === "europe1") return NAME_POOLS.europeWest;
  if (regionId === "europe2") return NAME_POOLS.europeNorth;
  if (regionId === "europe3") return NAME_POOLS.europeSouth;
  if (regionId === "americas") return NAME_POOLS.americasNorth;
  if (regionId === "southAmerica") return NAME_POOLS.americasSouth;
  if (regionId === "asia") return NAME_POOLS.asiaEast;
  if (regionId === "middleEast") return NAME_POOLS.middleEast;
  return NAME_POOLS.oceania;
}

// Deterministic pseudo-random so the same nation always shows the same squad.
function seeded(seed: string) {
  let h = 2166136261;
  for (let i = 0; i < seed.length; i += 1) {
    h ^= seed.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return () => {
    h += 0x6d2b79f5;
    let t = h;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const SQUAD_TEMPLATE: Position[] = [
  "GK", "GK", "GK",
  "CB", "CB", "CB", "CB", "LB", "LB", "RB", "RB",
  "CDM", "CDM", "CM", "CM", "CM", "CAM", "CAM",
  "LW", "LW", "RW", "RW", "ST", "ST", "ST",
];

export function regionOfNation(code: string): RegionId {
  return REGIONS.find((region) => region.nations.some((nation) => nation.code === code))?.id ?? "africa";
}

export function generateSquad(nation: Nation): Player[] {
  const regionId = regionOfNation(nation.code);
  const pool = poolForNation(nation, regionId);
  const rand = seeded(`${nation.code}-${nation.name}`);
  const usedNames = new Set<string>();
  const usedLasts = new Set<string>();
  const usedNumbers = new Set<number>();

  return SQUAD_TEMPLATE.map((position, index) => {
    const first = pool.first[Math.floor(rand() * pool.first.length)];
    // Pools hold 26 distinct surnames for 25 players, so every squad gets unique last names.
    const available = pool.last.filter((name) => !usedLasts.has(name));
    const last = available[Math.floor(rand() * available.length)] ?? pool.last[0];
    usedNames.add(`${first} ${last}`);
    usedLasts.add(last);

    // 25 players need 25 distinct shirt numbers: cycle through 1–30 so the search always terminates.
    const preferred = position === "GK" ? [1, 12, 23] : position === "ST" ? [9, 10, 11, 19, 20] : [];
    let number = preferred.find((n) => !usedNumbers.has(n)) ?? 2 + Math.floor(rand() * 21);
    while (usedNumbers.has(number)) number = (number % 30) + 1;
    usedNumbers.add(number);

    const spread = Math.round((rand() - 0.5) * 12);
    const rating = Math.max(52, Math.min(96, nation.rating + spread - (index % 3 === 2 ? 4 : 0)));
    const age = 19 + Math.floor(rand() * 15);
    return {
      id: `${nation.code}-${index}`,
      name: `${first} ${last}`,
      shortName: `${first[0]}. ${last}`,
      position,
      group: POSITION_GROUP[position],
      number,
      rating,
      age,
      foot: rand() < 0.26 ? "L" : "R",
      form: (1 + Math.floor(rand() * 5)) as Player["form"],
      fitness: 72 + Math.floor(rand() * 28),
      caps: Math.floor(rand() * 90),
      goals: position === "GK" ? 0 : Math.floor(rand() * (position === "ST" ? 40 : 15)),
    };
  });
}

/** Positions the pitch needs for a formation, defence first (excludes GK). */
export function slotsForFormation(lines: number[]): Position[] {
  const slots: Position[] = [];
  const defenders = lines[0] ?? 4;
  const forwards = lines.length > 1 ? lines[lines.length - 1] : 2;
  const midfielders = 10 - defenders - forwards;

  const defSlots: Position[] = defenders >= 4 ? ["LB", "CB", "CB", "RB"] : ["CB", "CB", "CB"];
  while (defSlots.length < defenders) defSlots.splice(1, 0, "CB");
  slots.push(...defSlots.slice(0, defenders));

  const midSlots: Position[] = midfielders >= 3 ? ["CDM", "CM", "CAM"] : ["CM", "CM"];
  while (midSlots.length < midfielders) midSlots.splice(1, 0, "CM");
  slots.push(...midSlots.slice(0, midfielders));

  const fwdSlots: Position[] = forwards >= 3 ? ["LW", "ST", "RW"] : forwards === 2 ? ["ST", "ST"] : ["ST"];
  while (fwdSlots.length < forwards) fwdSlots.splice(1, 0, "ST");
  slots.push(...fwdSlots.slice(0, forwards));
  return slots;
}

/** Picks the best XI (by rating) that fits the formation's position slots. */
export function autoPickXI(squad: Player[], lines: number[]): string[] {
  const sorted = [...squad].sort((a, b) => b.rating - a.rating);
  const taken = new Set<string>();
  const pickFor = (match: (player: Player) => boolean) => {
    const player = sorted.find((p) => !taken.has(p.id) && match(p));
    if (player) taken.add(player.id);
    return player?.id;
  };
  const xi: string[] = [];
  const gk = pickFor((p) => p.position === "GK");
  if (gk) xi.push(gk);
  slotsForFormation(lines).forEach((slot) => {
    const exact = pickFor((p) => p.position === slot);
    if (exact) {
      xi.push(exact);
      return;
    }
    const group = POSITION_GROUP[slot];
    const fallback = pickFor((p) => p.group === group) ?? pickFor((p) => p.position !== "GK");
    if (fallback) xi.push(fallback);
  });
  return xi;
}

export const positionLabel = (position: Position) => position;
export const groupLabel: Record<PositionGroup, string> = { GK: "GOALKEEPERS", DEF: "DEFENDERS", MID: "MIDFIELDERS", FWD: "FORWARDS" };
