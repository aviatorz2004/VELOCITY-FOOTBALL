/**
 * Stadiums are sold for coins. A `price` of 0 marks a free starter venue, which is always unlocked.
 * Everything else starts locked until the player buys it.
 */
export const STADIUMS = [
  {
    id: "uhuru-arena",
    name: "Uhuru Arena",
    city: "Dar es Salaam",
    country: "Tanzania",
    atmosphere: "Blue hour",
    capacity: "60,000",
    price: 0,
    sceneKey: "stadium_uhuru_arena",
    imageDescription: "A floodlit green pitch beneath an open stadium roof at blue hour.",
  },
  {
    id: "kilimani-park",
    name: "Kilimani Park",
    city: "Nairobi",
    country: "Kenya",
    atmosphere: "Afternoon",
    capacity: "28,000",
    price: 15000,
    sceneKey: "stadium_kilimani_park",
    imageDescription: "A sunlit football ground surrounded by green highlands and acacia trees.",
  },
  {
    id: "atlantic-stadium",
    name: "Atlantic Stadium",
    city: "Cape Town",
    country: "South Africa",
    atmosphere: "Sunset",
    capacity: "55,000",
    price: 25000,
    sceneKey: "stadium_atlantic_stadium",
    imageDescription: "A coastal stadium with blue seats and a glowing orange sunset over the ocean.",
  },
  {
    id: "metro-ground",
    name: "Metro Ground",
    city: "London",
    country: "England",
    atmosphere: "Under the lights",
    capacity: "48,000",
    price: 40000,
    sceneKey: "stadium_metro_ground",
    imageDescription: "A dramatic night stadium with red stands and a ring of white floodlights.",
  },
  {
    id: "neon-arena",
    name: "Neon Arena",
    city: "Tokyo",
    country: "Japan",
    atmosphere: "Night match",
    capacity: "68,000",
    price: 60000,
    sceneKey: "stadium_neon_arena",
    imageDescription: "A packed modern football arena illuminated by cool blue stadium lighting.",
  },
  {
    id: "nile-arena",
    name: "Nile Arena",
    city: "Cairo",
    country: "Egypt",
    atmosphere: "Floodlit night",
    capacity: "75,000",
    price: 85000,
    sceneKey: "stadium_nile_arena",
    imageDescription: "A misty night stadium ringed by bright floodlights above a deep green pitch.",
  },
] as const;

export const MATCH_DURATIONS = [3, 5, 10, 15, 30] as const;

export const OPPONENT_LEVELS = [
  { id: "easy", label: "Easy", rank: 1, description: "A relaxed challenge. Room to learn and find your rhythm." },
  { id: "medium", label: "Medium", rank: 2, description: "A balanced challenge for a competitive match." },
  { id: "hard", label: "Hard", rank: 3, description: "A demanding opponent. Every decision will matter." },
  { id: "very-hard", label: "Very Hard", rank: 4, description: "The toughest challenge. Bring your strongest lineup." },
] as const;

export type StadiumId = (typeof STADIUMS)[number]["id"];
export type MatchDuration = (typeof MATCH_DURATIONS)[number];
export type OpponentLevel = (typeof OPPONENT_LEVELS)[number]["id"];

export interface MatchdayPreferences {
  stadiumId: StadiumId;
  durationMinutes: MatchDuration;
  opponentDifficulty: OpponentLevel;
}

export const MATCHDAY_PREFERENCES_KEY = "afrokick-match-preferences";
export const MATCHDAY_HANDOFF_KEY = "afrokick-match-handoff";
export const MATCHDAY_READY_EVENT = "afrokick:match-ready";

export const DEFAULT_MATCHDAY_PREFERENCES: MatchdayPreferences = {
  stadiumId: "uhuru-arena",
  durationMinutes: 5,
  opponentDifficulty: "medium",
};

export const getStadium = (id: string) => STADIUMS.find((stadium) => stadium.id === id) ?? STADIUMS[0];
export const getOpponentLevel = (id: string) => OPPONENT_LEVELS.find((level) => level.id === id) ?? OPPONENT_LEVELS[1];

/** Free starter venues, which every player owns from the beginning. */
export const FREE_STADIUM_IDS: StadiumId[] = STADIUMS.filter((stadium) => stadium.price === 0).map((stadium) => stadium.id);

/**
 * Turns whatever was stored into a clean list of owned stadium ids: unknown or duplicate ids
 * are dropped and the free starter venue is always included, so an old or edited save can never lock a player out.
 */
export function normaliseUnlockedStadiums(value: unknown): StadiumId[] {
  const owned = new Set<string>(Array.isArray(value) ? value.filter((id): id is string => typeof id === "string") : []);
  return STADIUMS.filter((stadium) => stadium.price === 0 || owned.has(stadium.id)).map((stadium) => stadium.id);
}

/** If the saved stadium is not owned (for example a save from before stadiums were locked), fall back to a free one. */
export function ensureUnlockedStadium(preferences: MatchdayPreferences, unlocked: readonly string[]): MatchdayPreferences {
  return unlocked.includes(preferences.stadiumId) ? preferences : { ...preferences, stadiumId: FREE_STADIUM_IDS[0] };
}

// Validate each field independently so old or edited browser saves cannot break the selectors.
export function normaliseMatchdayPreferences(value: unknown): MatchdayPreferences {
  const stored = value && typeof value === "object" ? value as Record<string, unknown> : {};
  return {
    stadiumId: STADIUMS.find((stadium) => stadium.id === stored.stadiumId)?.id ?? DEFAULT_MATCHDAY_PREFERENCES.stadiumId,
    durationMinutes: MATCH_DURATIONS.find((duration) => duration === stored.durationMinutes) ?? DEFAULT_MATCHDAY_PREFERENCES.durationMinutes,
    opponentDifficulty: OPPONENT_LEVELS.find((level) => level.id === stored.opponentDifficulty)?.id ?? DEFAULT_MATCHDAY_PREFERENCES.opponentDifficulty,
  };
}

export function loadMatchdayPreferences(): MatchdayPreferences {
  try {
    return normaliseMatchdayPreferences(JSON.parse(localStorage.getItem(MATCHDAY_PREFERENCES_KEY) ?? "null"));
  } catch {
    return { ...DEFAULT_MATCHDAY_PREFERENCES };
  }
}

export function saveMatchdayPreferences(preferences: MatchdayPreferences) {
  try {
    localStorage.setItem(MATCHDAY_PREFERENCES_KEY, JSON.stringify(preferences));
  } catch {
    // The current match still keeps its settings when browser storage is unavailable.
  }
}
