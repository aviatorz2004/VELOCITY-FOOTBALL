import { useEffect, useMemo, useRef, useState, type CSSProperties, type ReactNode } from "react";
import {
  ArrowLeft,
  ArrowRight,
  Award,
  Bell,
  Check,
  ChevronRight,
  CircleHelp,
  Clock3,
  Coins,
  Dumbbell,
  Flag,
  Grid2X2,
  Info,
  Lock,
  LogOut,
  Play,
  Plus,
  Settings,
  Shield,
  ShoppingBag,
  Sparkles,
  Trophy,
  User,
  X,
} from "lucide-react";
import GameModes, { MODE_TILES } from "./components/GameModes";
import OnlineMatchmaking from "./components/OnlineMatchmaking";
import PenaltyMatch from "./components/PenaltyMatch";
import GameInfoView from "./components/GameInfoView";
import TournamentView from "./components/TournamentView";
import SettingsView, { type GameSettings, DEFAULT_SETTINGS } from "./components/SettingsView";
import TitleScreen from "./components/TitleScreen";
import LoadingScreen from "./components/LoadingScreen";
import VelocityLogo from "./components/VelocityLogo";
import RegistrationScreen, { type PlayerProfileInput } from "./components/RegistrationScreen";
import CareerSetup, { type CareerFixture } from "./components/CareerSetup";
import QuickFormationSetup, { type QuickFixture } from "./components/QuickFormationSetup";
import MatchPreview, { type MatchdayLineup, type PreviewFixture } from "./components/MatchPreview";
import { formationName } from "./careerData";
import {
  getOpponentLevel,
  getStadium,
  MATCHDAY_HANDOFF_KEY,
  MATCHDAY_READY_EVENT,
  normaliseUnlockedStadiums,
  STADIUMS,
  type StadiumId,
} from "./matchdaySettings";

import {
  EVENT_STAGES,
  OPPONENTS,
  SHOP_ITEMS,
  type MatchMode,
  type OnlineRecord,
  type Opponent,
} from "./gameData";
import {
  TOURNAMENT_ROUNDS,
  createTournament,
  findOpponent,
  isValidTournament,
  playerOpponentId,
  resolveTournamentRound,
  type TieResult,
  type TournamentState,
} from "./tournament";

type Screen = "home" | "modes" | "career" | "careerSetup" | "quickSetup" | "event" | "options" | "info" | "tournament";
type Overlay = "notifications" | "profile" | "store" | "exit" | "help" | "training" | "quickSetup" | "online" | null;

interface NotificationItem {
  id: string;
  title: string;
  body: string;
  time: string;
  unread: boolean;
  action?: "event" | "career";
  reward?: number;
  claimed?: boolean;
}

interface SaveData {
  coins: number;
  xp: number;
  careerWeek: number;
  careerWins: number;
  careerLosses: number;
  totalGoals: number;
  matches: number;
  form: ("W" | "L" | "D")[];
  eventStage: number;
  eventEndsAt: number;
  championsBadge: boolean;
  inventory: string[];
  equipped: { kit: string; gloves: string; trail: string };
  notifications: NotificationItem[];
  online: OnlineRecord;
  tournament: TournamentState;
  profile: {
    completed: boolean;
    name: string;
    club: string;
    number: number;
    position: string;
    accountId: string;
  };
  /** Stadiums the player owns. Free starter venues are always included. */
  unlockedStadiums: StadiumId[];
}

interface MatchConfig {
  mode: MatchMode;
  opponent: Opponent;
  eventStage: number;
  stageLabel: string;
  tournamentRound?: number;
  /** Career Mode national-team fixtures override the player's club identity. */
  home?: { name: string; short: string; color: string; flag: string };
  awayFlag?: string;
}

interface LaunchOptions {
  stageLabel?: string;
  home?: MatchConfig["home"];
  awayFlag?: string;
}

const DEFAULT_SAVE: SaveData = {
  coins: 12480,
  xp: 23250,
  careerWeek: 8,
  careerWins: 19,
  careerLosses: 12,
  totalGoals: 47,
  matches: 31,
  form: ["W", "W", "L", "W", "W"],
  eventStage: 0,
  eventEndsAt: Date.now() + (2 * 24 + 14) * 60 * 60 * 1000,
  championsBadge: false,
  inventory: ["classic"],
  equipped: { kit: "classic", gloves: "none", trail: "none" },
  notifications: [
    {
      id: "event-live",
      title: "Champions of the City is live",
      body: "Three rivals stand between you and the city title. First stage: Northgate City.",
      time: "NOW",
      unread: true,
      action: "event",
    },
    {
      id: "weekly-reward",
      title: "Weekly club grant",
      body: "Your weekly club grant is ready to collect.",
      time: "2H",
      unread: true,
      reward: 350,
      claimed: false,
    },
    {
      id: "career-fixture",
      title: "Next fixture confirmed",
      body: "Harbor Athletic await in Career Week 8. Scouting report is now available.",
      time: "1D",
      unread: false,
      action: "career",
    },
  ],
  online: { rating: 1250, wins: 0, losses: 0, streak: 0 },
  tournament: createTournament(),
  profile: { completed: false, name: "", club: "VELOCITY FC", number: 9, position: "FWD", accountId: "VF-000001" },
  unlockedStadiums: normaliseUnlockedStadiums([]),
};

const SAVE_KEY = "afrokick-save";
const SETTINGS_KEY = "afrokick-settings";
// Earlier builds stored progress under these keys. They are only read, so existing saves carry over.
const LEGACY_SAVE_KEY = "velocity-save";
const LEGACY_SETTINGS_KEY = "velocity-settings";

const readStored = (key: string, legacyKey: string) =>
  localStorage.getItem(key) ?? localStorage.getItem(legacyKey) ?? "{}";

const loadSettings = (): GameSettings => {
  try {
    return { ...DEFAULT_SETTINGS, ...JSON.parse(readStored(SETTINGS_KEY, LEGACY_SETTINGS_KEY)) };
  } catch {
    return DEFAULT_SETTINGS;
  }
};

const loadSave = (): SaveData => {
  try {
    const stored = JSON.parse(readStored(SAVE_KEY, LEGACY_SAVE_KEY)) as Partial<SaveData>;
    return {
      ...DEFAULT_SAVE,
      ...stored,
      equipped: { ...DEFAULT_SAVE.equipped, ...stored.equipped },
      notifications: stored.notifications ?? DEFAULT_SAVE.notifications,
      online: { ...DEFAULT_SAVE.online, ...stored.online },
      tournament: isValidTournament(stored.tournament) ? stored.tournament : DEFAULT_SAVE.tournament,
      profile: { ...DEFAULT_SAVE.profile, ...stored.profile },
      unlockedStadiums: normaliseUnlockedStadiums(stored.unlockedStadiums),
    };
  } catch {
    return DEFAULT_SAVE;
  }
};

const careerOpponent = (week: number) => OPPONENTS[(Math.max(8, week) - 8) % OPPONENTS.length];
const money = (value: number) => value.toLocaleString("en-US");
const initialsOf = (value: string, max: number, fallback: string) => {
  const letters = value
    .trim()
    .split(/\s+/)
    .map((word) => word[0])
    .filter(Boolean)
    .slice(0, max)
    .join("")
    .toUpperCase();
  return letters || fallback;
};

function Brand({ onClick }: { onClick: () => void }) {
  return (
    <button className="brand" onClick={onClick} aria-label="Velocity Football home">
      <VelocityLogo height={28} />
    </button>
  );
}

function ViewHeading({ eyebrow, title, onBack, aside }: { eyebrow: string; title: string; onBack: () => void; aside?: ReactNode }) {
  return (
    <div className="view-heading">
      <button className="back-button" onClick={onBack}><ArrowLeft size={16} /> BACK</button>
      <div><span className="eyebrow">{eyebrow}</span><h1>{title}</h1></div>
      {aside && <div className="view-heading-aside">{aside}</div>}
    </div>
  );
}

export default function App() {
  const [save, setSave] = useState<SaveData>(loadSave);
  const [settings, setSettings] = useState<GameSettings>(loadSettings);
  const [screen, setScreen] = useState<Screen>("home");
  const [history, setHistory] = useState<Screen[]>([]);
  const [overlay, setOverlay] = useState<Overlay>(null);
  const [activeMenu, setActiveMenu] = useState(0);
  const [modeIndex, setModeIndex] = useState(0);

  const [matchConfig, setMatchConfig] = useState<MatchConfig | null>(null);
  const [previewFixture, setPreviewFixture] = useState<PreviewFixture | null>(null);
  const [matchOrigin, setMatchOrigin] = useState<Screen>("home");
  const [showTitle, setShowTitle] = useState(true);
  const [showLoading, setShowLoading] = useState(false);
  const [exited, setExited] = useState(false);
  const [toast, setToast] = useState<{ title: string; detail: string } | null>(null);
  const [now, setNow] = useState(Date.now());
  const audioContext = useRef<AudioContext | null>(null);
  const toastTimer = useRef<number | null>(null);
  const menuRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const keyHandler = useRef<(event: KeyboardEvent) => void>(() => undefined);

  const level = Math.floor(save.xp / 1000) + 1;
  const levelProgress = (save.xp % 1000) / 10;
  const playerOvr = Math.min(94, 70 + Math.floor(level / 2));
  const needsProfile = !save.profile.completed;
  const profileName = save.profile.name.trim() || "VELOCITY PLAYER";
  const profileClub = save.profile.club.trim() || "VELOCITY FC";
  const profileShort = initialsOf(profileClub, 3, "VF");
  const playerInitials = initialsOf(profileName, 2, "VF");
  const unread = save.notifications.filter((item) => item.unread).length;
  const nextCareerOpponent = careerOpponent(save.careerWeek);
  const currentEventStage = Math.min(save.eventStage, EVENT_STAGES.length - 1);
  const eventRemaining = Math.max(0, save.eventEndsAt - now);
  const eventDays = Math.floor(eventRemaining / 86400000);
  const eventHours = Math.floor((eventRemaining % 86400000) / 3600000);
  const eventMinutes = Math.floor((eventRemaining % 3600000) / 60000);
  const equippedKit = SHOP_ITEMS.find((item) => item.id === save.equipped.kit)?.color ?? "#f1f1e9";
  const saveBoost = save.equipped.gloves === "pro-gloves" ? 0.1 : 0;
  const hasTrail = save.equipped.trail === "lime-trail";
  const tournamentOpponentId = playerOpponentId(save.tournament);

  useEffect(() => {
    try { localStorage.setItem(SAVE_KEY, JSON.stringify(save)); } catch { /* storage can be disabled */ }
  }, [save]);

  useEffect(() => {
    try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)); } catch { /* storage can be disabled */ }
  }, [settings]);

  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 30000);
    return () => window.clearInterval(timer);
  }, []);

  const showToast = (title: string, detail: string) => {
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    setToast({ title, detail });
    toastTimer.current = window.setTimeout(() => setToast(null), 3200);
  };

  const playSound = (kind: "click" | "whistle" | "kick" | "goal" | "save" = "click") => {
    if (settings.muted || settings.masterVolume === 0 || settings.sfxVolume === 0) return;
    try {
      if (!audioContext.current) audioContext.current = new AudioContext();
      const context = audioContext.current;
      if (context.state === "suspended") void context.resume();
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      const frequencies = { click: 440, whistle: 1250, kick: 115, goal: 720, save: 240 };
      const durations = { click: 0.045, whistle: 0.24, kick: 0.09, goal: 0.22, save: 0.12 };
      oscillator.type = kind === "kick" ? "triangle" : kind === "click" ? "square" : "sine";
      oscillator.frequency.setValueAtTime(frequencies[kind], context.currentTime);
      if (kind === "goal") oscillator.frequency.exponentialRampToValueAtTime(1080, context.currentTime + 0.18);
      if (kind === "whistle") oscillator.frequency.setValueAtTime(1550, context.currentTime + 0.1);
      const volume = 0.055 * (settings.masterVolume / 100) * (settings.sfxVolume / 100);
      gain.gain.setValueAtTime(volume, context.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + durations[kind]);
      oscillator.connect(gain).connect(context.destination);
      oscillator.start();
      oscillator.stop(context.currentTime + durations[kind]);
    } catch { /* audio is optional when the browser blocks Web Audio */ }
  };

  const navigate = (destination: Screen) => {
    setOverlay(null);
    if (destination === "home") {
      setHistory([]);
      setActiveMenu(0);
      setScreen("home");
      return;
    }
    if (destination === screen) return;
    setHistory((stack) => [...stack.filter((item) => item !== destination && item !== screen), screen]);
    setScreen(destination);
  };

  const goBackScreen = () => {
    setOverlay(null);
    const previous = history[history.length - 1] ?? "home";
    setHistory((stack) => stack.slice(0, -1));
    setScreen(previous);
  };

  const goBack = () => {
    if (overlay) setOverlay(null);
    else if (screen === "home") setOverlay("exit");
    else goBackScreen();
  };

  const activateMenu = (index: number) => {
    setActiveMenu(index);
    if (index === 0) navigate("career");
    if (index === 1) navigate("modes");
    if (index === 2) navigate("options");
    if (index === 3) navigate("info");
    if (index === 4) setOverlay("exit");
  };

  const launchMatch = (mode: MatchMode, opponentOverride?: Opponent, tournamentRound?: number, options: LaunchOptions = {}) => {
    const eventStage = Math.min(save.eventStage, EVENT_STAGES.length - 1);
    const opponent =
      opponentOverride ??
      (mode === "career"
        ? nextCareerOpponent
        : mode === "event"
          ? EVENT_STAGES[eventStage].opponent
          : mode === "quick"
            ? OPPONENTS[1]
            : OPPONENTS[0]);
    const stageLabel =
      mode === "career"
        ? `WEEK ${save.careerWeek}`
        : mode === "event"
          ? EVENT_STAGES[eventStage].name.toUpperCase()
          : mode === "tournament"
            ? TOURNAMENT_ROUNDS[Math.min(tournamentRound ?? 0, 2)].name.toUpperCase()
            : mode === "online"
              ? "RANKED"
              : mode === "training"
                ? "PRACTICE"
                : "FRIENDLY";
    setMatchOrigin(screen);
    setMatchConfig({
      mode,
      opponent,
      eventStage,
      stageLabel: options.stageLabel ?? stageLabel,
      tournamentRound,
      home: options.home,
      awayFlag: options.awayFlag,
    });
    setOverlay(null);
  };

  const startCareerFixture = (fixture: CareerFixture) => {
    setOverlay(null);
    setPreviewFixture({
      mode: "career",
      type: fixture.type,
      home: fixture.home,
      away: fixture.away,
      homeFormation: fixture.homeFormation,
      awayFormation: fixture.awayFormation,
    });
  };

  const startQuickMatch = (fixture: QuickFixture) => {
    setOverlay(null);
    setPreviewFixture({
      mode: "quick",
      type: "friendly",
      home: fixture.home,
      away: fixture.away,
      homeFormation: fixture.homeFormation,
      awayFormation: fixture.awayFormation,
    });
  };

  // Buying a stadium spends real coins from the player's balance and is saved with the rest of their progress.
  const unlockStadium = (id: StadiumId): boolean => {
    const stadium = STADIUMS.find((item) => item.id === id);
    if (!stadium) return false;
    if (save.unlockedStadiums.includes(id)) return true;
    if (stadium.price <= 0 || save.coins < stadium.price) return false;
    // Re-check inside the updater so a double click can never charge twice.
    setSave((previous) =>
      previous.unlockedStadiums.includes(id) || previous.coins < stadium.price
        ? previous
        : {
            ...previous,
            coins: previous.coins - stadium.price,
            unlockedStadiums: normaliseUnlockedStadiums([...previous.unlockedStadiums, id]),
          },
    );
    playSound("goal");
    return true;
  };

  // UI-only handoff: a future Unity bridge can consume this event or the saved JSON.
  const kickOff = (lineup: MatchdayLineup) => {
    const fixture = previewFixture;
    if (!fixture) return;
    if (!save.unlockedStadiums.includes(lineup.matchSettings.stadiumId)) {
      showToast("Stadium locked", "Unlock this stadium with coins, or pick one you own, before kick-off.");
      return;
    }
    const stadium = getStadium(lineup.matchSettings.stadiumId);
    const handoff = {
      schemaVersion: 1,
      fixture,
      lineup,
      stadium: { id: stadium.id, name: stadium.name, sceneKey: stadium.sceneKey },
    };
    try {
      localStorage.setItem(MATCHDAY_HANDOFF_KEY, JSON.stringify(handoff));
    } catch { /* The event still carries the setup when local storage is unavailable. */ }
    window.dispatchEvent(new CustomEvent(MATCHDAY_READY_EVENT, { detail: handoff }));
    setPreviewFixture(null);
    navigate("modes");
    showToast(
      `${fixture.home.name} vs ${fixture.away.name}`,
      `${stadium.name} · ${lineup.matchSettings.durationMinutes} min · ${getOpponentLevel(lineup.matchSettings.opponentDifficulty).label} · ${formationName(lineup.formation)} · Setup confirmed`,
    );
  };

  const activateMode = (index: number) => {
    const tile = MODE_TILES[index];
    if (!tile) return;
    setModeIndex(index);
    if (tile.id === "quick") navigate("quickSetup");
    if (tile.id === "career") navigate("careerSetup");
    if (tile.id === "online") setOverlay("online");
    if (tile.id === "tournament") navigate("tournament");
    if (tile.id === "training") setOverlay("training");
  };

  const leaveMatch = () => {
    setMatchConfig(null);
    setScreen(matchOrigin);
  };

  const completeMatch = (result: TieResult) => {
    if (!matchConfig) return;
    const { mode, opponent, eventStage, tournamentRound } = matchConfig;
    if (mode === "training") {
      showToast("Training session complete", `${result.playerScore} goals scored · Practice only, no rewards at stake`);
      return;
    }

    const roundIndex = tournamentRound ?? 0;
    const tournamentLive = mode === "tournament" && save.tournament.round === roundIndex && !save.tournament.eliminated;
    let coinReward = result.won ? opponent.reward : 100;
    if (mode === "career" && result.won) coinReward += 150;
    if (mode === "event") coinReward = result.won ? EVENT_STAGES[eventStage].reward : 100;
    if (mode === "online") coinReward = result.won ? 300 : 100;
    if (mode === "tournament") coinReward = tournamentLive ? (result.won ? TOURNAMENT_ROUNDS[roundIndex].reward : 100) : 0;
    const xpReward = mode === "tournament" && !tournamentLive ? 0 : result.won ? 240 : 90;
    const ratingChange = result.won ? 25 + Math.min(15, save.online.streak * 5) : -18;

    setSave((previous) => {
      const inventory = [...previous.inventory];
      let eventStageNow = previous.eventStage;
      let championsBadge = previous.championsBadge;
      if (mode === "event" && result.won && previous.eventStage === eventStage) {
        eventStageNow = Math.min(3, previous.eventStage + 1);
        if (eventStage === 0 && !inventory.includes("lime-kit")) inventory.push("lime-kit");
        if (eventStage === 1 && !inventory.includes("lime-trail")) inventory.push("lime-trail");
        if (eventStage === 2) championsBadge = true;
      }
      const tournament =
        mode === "tournament" && previous.tournament.round === roundIndex && !previous.tournament.eliminated
          ? resolveTournamentRound(previous.tournament, result, playerOvr)
          : previous.tournament;
      const online: OnlineRecord =
        mode === "online"
          ? {
              rating: Math.max(800, previous.online.rating + ratingChange),
              wins: previous.online.wins + (result.won ? 1 : 0),
              losses: previous.online.losses + (result.won ? 0 : 1),
              streak: result.won ? previous.online.streak + 1 : 0,
            }
          : previous.online;
      return {
        ...previous,
        coins: previous.coins + coinReward,
        xp: previous.xp + xpReward,
        matches: previous.matches + 1,
        totalGoals: previous.totalGoals + result.playerScore,
        careerWeek: mode === "career" ? Math.min(38, previous.careerWeek + 1) : previous.careerWeek,
        careerWins: previous.careerWins + (result.won ? 1 : 0),
        careerLosses: previous.careerLosses + (result.won ? 0 : 1),
        form: [...previous.form, result.won ? ("W" as const) : ("L" as const)].slice(-5),
        eventStage: eventStageNow,
        championsBadge,
        inventory,
        tournament,
        online,
      };
    });

    let title = result.won ? "Victory rewards collected" : "Match rewards collected";
    let detail = `+${money(coinReward)} coins · +${xpReward} XP`;
    if (mode === "event" && result.won) detail += " · Event progress updated";
    if (mode === "online") {
      title = result.won ? "Ranked victory" : "Ranked defeat";
      detail += ` · ${ratingChange > 0 ? "+" : ""}${ratingChange} SR`;
    }
    if (mode === "tournament" && tournamentLive) {
      title = result.won
        ? roundIndex === 2
          ? "Velocity Cup champions!"
          : `Through to the ${TOURNAMENT_ROUNDS[roundIndex + 1].name.toLowerCase()}`
        : "Knocked out of the Velocity Cup";
    }
    showToast(title, detail);
  };

  const newTournamentDraw = () => {
    setSave((previous) => ({ ...previous, tournament: createTournament(previous.tournament.titles) }));
    showToast("New cup draw", "Eight clubs have been drawn into the Velocity Cup.");
  };

  const completeRegistration = (profile: PlayerProfileInput) => {
    const accountId = `VF-${Math.floor(100000 + Math.random() * 900000)}`;
    setSave((previous) => ({
      ...previous,
      profile: { ...profile, completed: true, accountId },
    }));
    playSound("goal");
    showToast("Welcome to Velocity Football", `${profile.name.split(" ")[0]}, your player profile is ready.`);
  };



  const toggleFullscreen = async () => {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await document.documentElement.requestFullscreen();
    } catch {
      showToast("Fullscreen unavailable", "Your browser or embedded preview does not allow fullscreen mode.");
    }
  };

  const markNotificationRead = (id: string) => {
    setSave((previous) => ({
      ...previous,
      notifications: previous.notifications.map((item) => (item.id === id ? { ...item, unread: false } : item)),
    }));
  };

  const openNotification = (item: NotificationItem) => {
    markNotificationRead(item.id);
    if (item.action) navigate(item.action);
  };

  const claimNotification = (id: string, reward: number) => {
    setSave((previous) => ({
      ...previous,
      coins: previous.coins + reward,
      notifications: previous.notifications.map((item) => (item.id === id ? { ...item, claimed: true, unread: false } : item)),
    }));
    showToast("Club grant collected", `+${money(reward)} coins added to your balance`);
  };

  const handleShopItem = (id: string) => {
    const item = SHOP_ITEMS.find((entry) => entry.id === id);
    if (!item) return;
    const owned = save.inventory.includes(id);
    const equipped = save.equipped[item.category] === id;
    if (owned && equipped) {
      if (item.category === "kit") {
        showToast("Kit equipped", `${item.name} is your current match kit.`);
        return;
      }
      setSave((previous) => ({ ...previous, equipped: { ...previous.equipped, [item.category]: "none" } }));
      showToast("Item unequipped", `${item.name} returned to your inventory.`);
      return;
    }
    if (owned) {
      setSave((previous) => ({ ...previous, equipped: { ...previous.equipped, [item.category]: id } }));
      showToast("Item equipped", `${item.name} is active${id === "pro-gloves" ? " · Save boost +10%" : ""}.`);
      return;
    }
    if (save.coins < item.price) {
      showToast("Not enough coins", `You need ${money(item.price - save.coins)} more coins. Win matches to earn them.`);
      return;
    }
    setSave((previous) => ({
      ...previous,
      coins: previous.coins - item.price,
      inventory: [...previous.inventory, id],
      equipped: { ...previous.equipped, [item.category]: id },
    }));
    showToast("Purchased and equipped", `${item.name} · −${money(item.price)} coins`);
  };

  useEffect(() => {
    keyHandler.current = (event: KeyboardEvent) => {
      if (matchConfig || previewFixture || exited || showTitle || showLoading || needsProfile) return;
      if (event.key === "Escape") {
        event.preventDefault();
        goBack();
        return;
      }
      if (overlay || screen !== "home") return;
      if (event.key === "ArrowDown" || event.key === "ArrowUp") {
        event.preventDefault();
        const next = (activeMenu + (event.key === "ArrowDown" ? 1 : 4)) % 5;
        setActiveMenu(next);
        menuRefs.current[next]?.focus();
        return;
      }
      if (event.key === "Enter" || event.code === "Space") {
        if ((event.target as HTMLElement | null)?.closest("button, input, select, textarea, summary, a")) return;
        event.preventDefault();
        activateMenu(activeMenu);
      }
    };
  });

  useEffect(() => {
    const listener = (event: KeyboardEvent) => keyHandler.current(event);
    window.addEventListener("keydown", listener);
    return () => window.removeEventListener("keydown", listener);
  }, []);

  const menuItems = useMemo(
    () => [
      { label: "START GAME", icon: Play },
      { label: "GAME MODES", icon: Grid2X2 },
      { label: "OPTIONS", icon: Settings },
      { label: "GAME INFO", icon: Info },
      { label: "EXIT GAME", icon: LogOut },
    ],
    [],
  );

  const winRate = save.matches ? Math.round((save.careerWins / save.matches) * 100) : 0;
  const ambient = !exited && !matchConfig && !previewFixture && !showTitle && !showLoading && (screen === "modes" || screen === "tournament" || screen === "options" || screen === "careerSetup") ? "dark" : "stadium";
  const footerSelect =
    screen === "home"
      ? () => activateMenu(activeMenu)
      : screen === "modes"
        ? () => activateMode(modeIndex)
        : screen === "tournament" && tournamentOpponentId
          ? () => launchMatch("tournament", findOpponent(tournamentOpponentId), save.tournament.round)
          : null;
  const footerRight: [string, string] =
    screen === "modes" || screen === "options"
      ? ["VF", "2025"]
      : screen === "careerSetup"
        ? ["CAREER MODE", "SETUP"]
      : screen === "tournament"
        ? ["VELOCITY CUP", save.tournament.round >= 3 ? "COMPLETE" : TOURNAMENT_ROUNDS[save.tournament.round].short]
        : ["SEASON 01", `MATCHDAY ${Math.min(38, save.careerWeek + 10)}`];
  const primaryHint = screen === "modes" || screen === "tournament" || screen === "options";

  return (
    <div
      className={`app-stage ${settings.reducedMotion ? "reduce-motion" : ""} ${settings.highContrast ? "high-contrast" : ""}`}
      data-quality={settings.quality}
    >
      <div className="device-frame">
        <span className="device-camera" aria-hidden="true" />
        <main
          className="game-screen"
          data-ambient={ambient}
          onClickCapture={(event) => {
            if ((event.target as HTMLElement).closest("button")) playSound("click");
          }}
        >
          <div className="stadium-background" />
          <div className="screen-vignette" />
          <div className="ambient-layer" />

          {showTitle ? (
            <TitleScreen
              onContinue={() => {
                playSound("whistle");
                setShowTitle(false);
                setShowLoading(true);
              }}
            />
          ) : showLoading ? (
            <LoadingScreen
              durationMs={20000}
              onComplete={() => {
                setShowLoading(false);
              }}
            />
          ) : needsProfile ? (
            <RegistrationScreen
              defaultClub="VELOCITY FC"
              onBack={() => setShowTitle(true)}
              onComplete={completeRegistration}
            />
          ) : exited ? (
            <section className="standby-screen">
              <Brand onClick={() => setExited(false)} />
              <div>
                <span className="eyebrow">SESSION CLOSED / PROGRESS SAVED</span>
                <h1>SEE YOU ON<br /><em>THE PITCH.</em></h1>
                <p>Your career, inventory, and settings are stored on this device.</p>
                <button className="primary-action" onClick={() => { setExited(false); navigate("home"); }}>
                  <Play size={16} /> RELAUNCH VELOCITY
                </button>
              </div>
              <small>VELOCITY FOOTBALL · LOCAL SESSION</small>
            </section>
          ) : previewFixture ? (
            <MatchPreview
              key={`${previewFixture.home.code}-${previewFixture.away.code}`}
              fixture={previewFixture}
              coins={save.coins}
              unlockedStadiums={save.unlockedStadiums}
              onUnlockStadium={unlockStadium}
              onBack={() => setPreviewFixture(null)}
              onStart={kickOff}
            />
          ) : matchConfig ? (
            <PenaltyMatch
              key={`${matchConfig.mode}-${matchConfig.opponent.id}-${matchConfig.eventStage}-${matchConfig.tournamentRound ?? "x"}`}
              opponent={matchConfig.opponent}
              clubName={matchConfig.home?.name ?? profileClub}
              clubShort={matchConfig.home?.short ?? profileShort}
              homeFlag={matchConfig.home?.flag}
              awayFlag={matchConfig.awayFlag}
              mode={matchConfig.mode}
              stageLabel={matchConfig.stageLabel}
              allowRematch={matchConfig.mode === "quick" || matchConfig.mode === "training"}
              difficulty={matchConfig.mode === "training" ? "rookie" : settings.difficulty}
              saveBoost={saveBoost}
              trail={hasTrail}
              kitColor={matchConfig.home?.color ?? equippedKit}
              settings={settings}
              onExit={leaveMatch}
              onComplete={completeMatch}
              playSound={playSound}
            />
          ) : (
            <>
              <header className="game-header">
                <Brand onClick={() => navigate("home")} />
                <div className="header-actions">
                  <div className="currency-pill">
                    <Coins size={14} />
                    <strong>{money(save.coins)}</strong>
                    <button onClick={() => setOverlay("store")} aria-label="Open club shop"><Plus size={15} /></button>
                  </div>
                  <button
                    className={`header-icon ${overlay === "notifications" ? "active" : ""}`}
                    onClick={() => setOverlay(overlay === "notifications" ? null : "notifications")}
                    aria-label={`${unread} unread notifications`}
                  >
                    <Bell size={17} />
                    {unread > 0 && <span className="notification-dot" />}
                  </button>
                  <button
                    className={`profile-button ${overlay === "profile" ? "active" : ""}`}
                    onClick={() => setOverlay(overlay === "profile" ? null : "profile")}
                  >
                    <span className="profile-avatar">{playerInitials}</span>
                    <span className="profile-copy">
                      <strong>{profileName.toUpperCase()}</strong>
                      <small>LEVEL {level}<i><b style={{ width: `${levelProgress}%` }} /></i></small>
                    </span>
                    <ChevronRight size={14} />
                  </button>
                </div>
              </header>

              {screen === "home" && (
                <section className="home-view" aria-label="Main menu">
                  <div className="home-copy">
                    <div className="eyebrow home-eyebrow"><span />PLAY BEYOND LIMITS</div>
                    <h1 className="hero-title">OWN THE<br /><em>GAME.</em></h1>
                    <p>Build your legacy. Control every moment.</p>
                    <nav className="main-menu" aria-label="Game menu">
                      {menuItems.map((item, index) => {
                        const Icon = item.icon;
                        return (
                          <button
                            key={item.label}
                            ref={(element) => {
                              menuRefs.current[index] = element;
                            }}
                            className={`menu-item ${index === 0 ? "start-item" : ""} ${activeMenu === index ? "selected" : ""}`}
                            onClick={() => activateMenu(index)}
                            onMouseEnter={() => setActiveMenu(index)}
                            onFocus={() => setActiveMenu(index)}
                          >
                            <span className="menu-icon"><Icon size={index === 0 ? 13 : 16} /></span>
                            <span className="menu-label">{item.label}</span>
                            {index === 0 && (
                              <span className="continue-copy">
                                <strong>CONTINUE</strong>
                                <small>Career · Week {save.careerWeek}</small>
                              </span>
                            )}
                            <ChevronRight className="menu-chevron" size={15} />
                          </button>
                        );
                      })}
                    </nav>
                  </div>

                  <button className="live-event-card" onClick={() => navigate("event")}>
                    <div className="event-card-top"><span>Ends in {eventDays}d {eventHours}h</span><strong>LIVE EVENT</strong></div>
                    <span className="event-title">CHAMPIONS<br />OF THE CITY</span>
                    <span className="event-progress">
                      <i><b style={{ width: `${(save.eventStage / 3) * 100}%` }} /></i>
                      <small>{save.eventStage}/3</small>
                    </span>
                    <span className="event-link">VIEW EVENT <ChevronRight size={12} /></span>
                  </button>
                </section>
              )}

              {screen === "modes" && (
                <GameModes
                  selected={modeIndex}
                  interactive={overlay === null}
                  onSelect={setModeIndex}
                  onActivate={activateMode}
                  onBack={goBackScreen}
                />
              )}

              {screen === "careerSetup" && (
                <CareerSetup onBack={goBackScreen} onStart={startCareerFixture} />
              )}

              {screen === "quickSetup" && (
                <QuickFormationSetup onBack={goBackScreen} onStart={startQuickMatch} />
              )}

              {screen === "tournament" && (
                <TournamentView
                  tournament={save.tournament}
                  kitColor={equippedKit}
                  playerClub={profileClub}
                  playerShort={profileShort}
                  playerOvr={playerOvr}
                  onPlay={(opponent) => launchMatch("tournament", opponent, save.tournament.round)}
                  onNewDraw={newTournamentDraw}
                  onBack={goBackScreen}
                />
              )}

              {screen === "options" && (
                <SettingsView
                  settings={settings}
                  playerName={profileName}
                  playerInitials={playerInitials}
                  accountId={save.profile.accountId}
                  onApply={(newSettings) => {
                    setSettings(newSettings);
                    showToast("Settings Saved", "Your game settings have been applied and synced.");
                  }}
                  onResetDefaults={() => {
                    setSettings(DEFAULT_SETTINGS);
                    showToast("Settings Restored", "All options have been reset to factory defaults.");
                  }}
                  onBack={goBackScreen}
                  onHome={() => navigate("home")}
                  onClearSave={() => {
                    setSave(DEFAULT_SAVE);
                    showToast("Progress Reset", "All match records and coin balances have been reset.");
                  }}
                  onToggleFullscreen={toggleFullscreen}
                  playSound={playSound}
                />
              )}

              {(screen === "career" || screen === "event" || screen === "info") && (
                <div className="view-scroll">
                  {screen === "career" && (
                    <section className="content-view career-view">
                      <ViewHeading
                        eyebrow={`SEASON 01 / WEEK ${save.careerWeek}`}
                        title="CAREER HUB"
                        onBack={goBackScreen}
                        aside={
                          <div className="career-form">
                            <span>FORM</span>
                            {save.form.map((result, index) => (
                              <i key={index} className={result === "W" ? "won" : result === "D" ? "drawn" : "lost"}>{result}</i>
                            ))}
                          </div>
                        }
                      />
                      <div className="career-layout">
                        <div className="next-fixture glass-panel">
                          <div className="fixture-label">
                            <span><span className="live-pulse" /> NEXT FIXTURE</span>
                            <small>DECISIVE MOMENT · 5 ROUNDS</small>
                          </div>
                          <div className="fixture-teams">
                            <div>
                              <span className="large-crest" style={{ background: equippedKit }}>{profileShort}</span>
                              <strong>{profileClub.toUpperCase()}</strong>
                              <small>HOME</small>
                            </div>
                            <span className="versus">VS</span>
                            <div>
                              <span
                                className="large-crest opponent"
                                style={{ borderColor: nextCareerOpponent.color, color: nextCareerOpponent.color }}
                              >
                                {nextCareerOpponent.short}
                              </span>
                              <strong>{nextCareerOpponent.club.toUpperCase()}</strong>
                              <small>OVR {nextCareerOpponent.rating}</small>
                            </div>
                          </div>
                          <div className="fixture-scout">
                            <Info size={15} />
                            <p><strong>SCOUTING REPORT</strong>{nextCareerOpponent.description}</p>
                          </div>
                          <button className="primary-action fixture-play" onClick={() => launchMatch("career")}>
                            <Play size={16} /> PLAY WEEK {save.careerWeek}
                            <span>+{money(nextCareerOpponent.reward + 150)} WIN REWARD</span>
                          </button>
                        </div>
                        <div className="career-side">
                          <div className="career-stats glass-panel">
                            <div><strong>{save.matches}</strong><span>MATCHES</span></div>
                            <div><strong>{save.careerWins}</strong><span>WINS</span></div>
                            <div><strong>{save.totalGoals}</strong><span>GOALS</span></div>
                            <div><strong>{winRate}%</strong><span>WIN RATE</span></div>
                          </div>
                          <div className="objectives glass-panel">
                            <div className="panel-title"><span>CLUB OBJECTIVES</span><Award size={16} /></div>
                            {[
                              { label: "Win 10 shootouts", value: Math.min(save.careerWins, 10), max: 10 },
                              { label: "Score 25 goals", value: Math.min(save.totalGoals, 25), max: 25 },
                              { label: "Reach Level 25", value: Math.min(level, 25), max: 25 },
                            ].map((objective) => (
                              <div className="objective" key={objective.label}>
                                <div><span>{objective.label}</span><small>{objective.value}/{objective.max}</small></div>
                                <i><b style={{ width: `${(objective.value / objective.max) * 100}%` }} /></i>
                              </div>
                            ))}
                          </div>
                          <button className="secondary-action full-button" onClick={() => navigate("modes")}>
                            <Grid2X2 size={15} /> EXPLORE OTHER MODES
                          </button>
                        </div>
                      </div>
                    </section>
                  )}

                  {screen === "event" && (
                    <section className="content-view event-view">
                      <ViewHeading
                        eyebrow="LIMITED TIME / LIVE EVENT"
                        title="CHAMPIONS OF THE CITY"
                        onBack={goBackScreen}
                        aside={
                          <div className="event-countdown">
                            <Clock3 size={15} />
                            <span>ENDS IN<strong>{eventDays}D {eventHours}H {eventMinutes}M</strong></span>
                          </div>
                        }
                      />
                      <div className="event-layout">
                        <div className="event-feature glass-panel">
                          <span className="event-number">0{Math.min(save.eventStage + 1, 3)}</span>
                          <span className="eyebrow">
                            {save.eventStage >= 3 ? "TITLE SECURED" : `NEXT / ${EVENT_STAGES[currentEventStage].name.toUpperCase()}`}
                          </span>
                          <h2>{save.eventStage >= 3 ? "THE CITY IS YOURS." : EVENT_STAGES[currentEventStage].opponent.club.toUpperCase()}</h2>
                          <p>
                            {save.eventStage >= 3
                              ? "You completed every stage and earned the Champions badge. Defend your title with a final rematch."
                              : EVENT_STAGES[currentEventStage].opponent.description}
                          </p>
                          <div className="event-reward">
                            <Trophy size={18} />
                            <span>
                              STAGE REWARD
                              <strong>
                                {money(EVENT_STAGES[currentEventStage].reward)} COINS + {EVENT_STAGES[currentEventStage].unlock.toUpperCase()}
                              </strong>
                            </span>
                          </div>
                          <button className="primary-action" onClick={() => launchMatch("event")}>
                            <Play size={16} /> {save.eventStage >= 3 ? "DEFEND THE TITLE" : `PLAY ${EVENT_STAGES[currentEventStage].name.toUpperCase()}`}
                          </button>
                        </div>
                        <div className="event-stages">
                          {EVENT_STAGES.map((stage, index) => {
                            const complete = save.eventStage > index;
                            const current = save.eventStage === index;
                            return (
                              <div className={`event-stage ${complete ? "complete" : ""} ${current ? "current" : ""}`} key={stage.name}>
                                <span className="stage-status">
                                  {complete ? <Check size={17} /> : current ? <Play size={15} /> : <Lock size={15} />}
                                </span>
                                <div>
                                  <small>STAGE 0{index + 1}</small>
                                  <strong>{stage.name.toUpperCase()}</strong>
                                  <span>{stage.opponent.club} · OVR {stage.opponent.rating}</span>
                                </div>
                                <div className="stage-reward">
                                  <Coins size={13} />
                                  {money(stage.reward)}
                                  <small>{complete ? "CLAIMED" : current ? "AVAILABLE" : "LOCKED"}</small>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </section>
                  )}



                  {screen === "info" && (
                    <GameInfoView
                      onBack={goBackScreen}
                      onTrainingLaunch={() => launchMatch("training")}
                      showToast={showToast}
                    />
                  )}
                </div>
              )}

              <footer className="game-footer">
                <div className="control-hints">
                  {footerSelect ? (
                    <button onClick={footerSelect}><kbd className={primaryHint ? "kbd-primary" : ""}>A</kbd> SELECT</button>
                  ) : (
                    <span><kbd>A</kbd> SELECT</span>
                  )}
                  <button onClick={goBack}><kbd>B</kbd> BACK</button>
                </div>
                <span>{footerRight[0]} <i>/</i> {footerRight[1]}</span>
              </footer>
            </>
          )}

          {overlay === "notifications" && (
            <>
              <button className="popover-dismiss" aria-label="Close notifications" onClick={() => setOverlay(null)} />
              <aside className="popover notifications-panel">
                <div className="popover-header">
                  <span>NOTIFICATIONS <small>{unread} NEW</small></span>
                  <button onClick={() => setOverlay(null)} aria-label="Close"><X size={15} /></button>
                </div>
                <button
                  className="mark-read"
                  onClick={() =>
                    setSave((previous) => ({
                      ...previous,
                      notifications: previous.notifications.map((item) => ({ ...item, unread: false })),
                    }))
                  }
                >
                  <Check size={12} /> MARK ALL AS READ
                </button>
                <div className="notification-list">
                  {save.notifications.map((item) => (
                    <div key={item.id} className={`notification-item ${item.unread ? "unread" : ""}`}>
                      <button className="notification-main" onClick={() => openNotification(item)}>
                        <span><strong>{item.title}</strong><small>{item.time}</small></span>
                        <p>{item.body}</p>
                        {item.action && <em>OPEN {item.action.toUpperCase()} <ChevronRight size={11} /></em>}
                      </button>
                      {item.reward && !item.claimed && (
                        <button className="claim-button" onClick={() => claimNotification(item.id, item.reward!)}>
                          <Coins size={12} /> CLAIM {item.reward}
                        </button>
                      )}
                      {item.claimed && <span className="claimed-label"><Check size={11} /> COLLECTED</span>}
                    </div>
                  ))}
                </div>
              </aside>
            </>
          )}

          {overlay === "profile" && (
            <>
              <button className="popover-dismiss" aria-label="Close profile" onClick={() => setOverlay(null)} />
              <aside className="popover profile-panel">
                <div className="profile-card-head">
                  <span className="large-avatar">{playerInitials}</span>
                  <div>
                    <strong>{profileName.toUpperCase()}</strong>
                    <span>{profileClub.toUpperCase()} · #{save.profile.number} · {save.profile.position}</span>
                    <small>LEVEL {level} {save.championsBadge && <em><Trophy size={10} /> CITY CHAMPION</em>}</small>
                  </div>
                </div>
                <div className="level-progress">
                  <div><span>LEVEL PROGRESS</span><strong>{save.xp % 1000} / 1000 XP</strong></div>
                  <i><b style={{ width: `${levelProgress}%` }} /></i>
                </div>
                <div className="profile-stats">
                  <div><strong>{save.matches}</strong><span>PLAYED</span></div>
                  <div><strong>{save.careerWins}</strong><span>WON</span></div>
                  <div><strong>{save.totalGoals}</strong><span>GOALS</span></div>
                </div>
                <div className="profile-links">
                  <button onClick={() => navigate("career")}><Flag size={15} /> CAREER HUB <ChevronRight size={13} /></button>
                  <button onClick={() => setOverlay("store")}><ShoppingBag size={15} /> CLUB INVENTORY <ChevronRight size={13} /></button>
                  <button onClick={() => navigate("options")}><Settings size={15} /> OPTIONS <ChevronRight size={13} /></button>
                </div>
              </aside>
            </>
          )}

          {overlay === "store" && (
            <div className="modal-backdrop" onClick={() => setOverlay(null)}>
              <section className="modal store-modal" role="dialog" aria-modal="true" aria-label="Club shop" onClick={(event) => event.stopPropagation()}>
                <div className="modal-header">
                  <div><span className="eyebrow">CUSTOMISE YOUR GAME</span><h2>CLUB SHOP</h2></div>
                  <div className="store-balance"><Coins size={15} /><strong>{money(save.coins)}</strong></div>
                  <button className="modal-close" onClick={() => setOverlay(null)} aria-label="Close shop"><X size={18} /></button>
                </div>
                <p className="store-note">Spend coins earned in matches. Event items can also be unlocked by winning stages.</p>
                <div className="shop-grid">
                  {SHOP_ITEMS.map((item) => {
                    const owned = save.inventory.includes(item.id);
                    const equipped = save.equipped[item.category] === item.id;
                    return (
                      <article className={`shop-item ${equipped ? "equipped" : ""}`} key={item.id}>
                        <div className="item-visual" style={{ "--item-color": item.color } as CSSProperties}>
                          <span>{item.category === "kit" ? "VF" : item.category === "gloves" ? <Shield size={25} /> : <Sparkles size={25} />}</span>
                          <small>{item.category.toUpperCase()}</small>
                        </div>
                        <div className="item-copy"><h3>{item.name}</h3><p>{item.description}</p></div>
                        <button className={equipped ? "item-equipped" : owned ? "item-owned" : "item-buy"} onClick={() => handleShopItem(item.id)}>
                          {equipped ? (
                            <><Check size={13} /> {item.category === "kit" ? "EQUIPPED" : "UNEQUIP"}</>
                          ) : owned ? (
                            <><User size={13} /> EQUIP</>
                          ) : (
                            <><Coins size={13} /> {money(item.price)}</>
                          )}
                        </button>
                      </article>
                    );
                  })}
                </div>
                <div className="store-footer">
                  <Info size={13} />
                  <span>Pro Grip Gloves modify save chance. Kits and trails change your live match visuals.</span>
                  <button onClick={() => navigate("modes")}>EARN COINS <ArrowRight size={13} /></button>
                </div>
              </section>
            </div>
          )}

          {overlay === "exit" && (
            <div className="modal-backdrop" onClick={() => setOverlay(null)}>
              <section className="modal confirm-modal" role="dialog" aria-modal="true" aria-label="Exit game" onClick={(event) => event.stopPropagation()}>
                <span className="confirm-icon"><LogOut size={23} /></span>
                <span className="eyebrow">END CURRENT SESSION</span>
                <h2>LEAVE THE PITCH?</h2>
                <p>Your career, coins, unlocks, and settings are saved locally. You can relaunch at any time.</p>
                <div className="confirm-actions">
                  <button className="secondary-action" onClick={() => setOverlay(null)}>STAY IN GAME</button>
                  <button className="primary-action" onClick={() => { setOverlay(null); setExited(false); setShowLoading(false); setShowTitle(true); navigate("home"); }}>END SESSION <LogOut size={14} /></button>
                </div>
              </section>
            </div>
          )}

          {(overlay === "help" || overlay === "training") && (
            <div className="modal-backdrop" onClick={() => setOverlay(null)}>
              <section
                className="modal help-modal"
                role="dialog"
                aria-modal="true"
                aria-label={overlay === "training" ? "Training ground" : "How to play"}
                onClick={(event) => event.stopPropagation()}
              >
                <button className="modal-close" onClick={() => setOverlay(null)} aria-label="Close"><X size={18} /></button>
                <span className="eyebrow">{overlay === "training" ? "05 / TRAINING GROUND" : "QUICK START"}</span>
                <h2>{overlay === "training" ? "SHARPEN EVERY KICK." : "OWN EVERY MOMENT."}</h2>
                {overlay === "training" && (
                  <p className="help-lead">A relaxed five-round shootout against a rookie keeper. No coins, XP, or records are at stake — just reps.</p>
                )}
                <div className="help-steps">
                  <div><span>01</span><p><strong>CHOOSE A MODE</strong>Continue your career or pick any mode from the Game Modes hub.</p></div>
                  <div><span>02</span><p><strong>PICK YOUR ZONE</strong>Use arrow keys, number keys 1–9, or select directly inside the goal.</p></div>
                  <div><span>03</span><p><strong>TIME YOUR SHOT</strong>Press Space or Shoot when the moving needle reaches the lime sweet spot.</p></div>
                  <div><span>04</span><p><strong>MAKE THE SAVE</strong>Read the striker, select a zone, then Dive. Correct guesses can stop the shot.</p></div>
                </div>
                <button className="primary-action" autoFocus onClick={() => launchMatch("training")}>
                  <Dumbbell size={15} /> {overlay === "training" ? "START SESSION" : "START TRAINING"}
                </button>
              </section>
            </div>
          )}



          {overlay === "online" && (
            <OnlineMatchmaking
              record={save.online}
              onClose={() => setOverlay(null)}
              playSound={playSound}
            />
          )}

          {toast && (
            <div className="game-toast" role="status">
              <span><Check size={15} /></span>
              <div><strong>{toast.title}</strong><small>{toast.detail}</small></div>
              <button onClick={() => setToast(null)} aria-label="Dismiss notification"><X size={13} /></button>
            </div>
          )}
        </main>
      </div>
      {!showTitle && !showLoading && !needsProfile && <button className="floating-help" onClick={() => setOverlay("help")} aria-label="Open game help"><CircleHelp size={22} /></button>}
    </div>
  );
}
