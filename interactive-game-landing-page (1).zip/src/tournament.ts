import { OPPONENTS, type Opponent } from "./gameData";

export const PLAYER_TEAM_ID = "velocity";

export const TOURNAMENT_ROUNDS = [
  { name: "Quarter-final", short: "QF", reward: 300 },
  { name: "Semi-final", short: "SF", reward: 500 },
  { name: "Final", short: "FINAL", reward: 1200 },
];

export interface TournamentState {
  /** Eight team ids in bracket order. Pairs (0-1, 2-3 ...) meet in the quarter-finals. */
  teams: string[];
  /** 0 = quarter-finals, 1 = semi-finals, 2 = final, 3 = cup complete. */
  round: number;
  winners: string[][];
  scores: string[][];
  eliminated: boolean;
  titles: number;
}

export interface TieResult {
  won: boolean;
  playerScore: number;
  opponentScore: number;
}

function shuffle<T>(items: T[]) {
  const copy = [...items];
  for (let index = copy.length - 1; index > 0; index -= 1) {
    const swap = Math.floor(Math.random() * (index + 1));
    [copy[index], copy[swap]] = [copy[swap], copy[index]];
  }
  return copy;
}

export function createTournament(titles = 0): TournamentState {
  const field = shuffle(OPPONENTS.map((opponent) => opponent.id)).slice(0, 7);
  return { teams: [PLAYER_TEAM_ID, ...field], round: 0, winners: [], scores: [], eliminated: false, titles };
}

export function isValidTournament(value: unknown): value is TournamentState {
  const tournament = value as Partial<TournamentState> | undefined;
  return Boolean(
    tournament &&
      Array.isArray(tournament.teams) &&
      tournament.teams.length === 8 &&
      tournament.teams.includes(PLAYER_TEAM_ID) &&
      typeof tournament.round === "number" &&
      Array.isArray(tournament.winners) &&
      Array.isArray(tournament.scores),
  );
}

export const findOpponent = (id: string): Opponent =>
  OPPONENTS.find((opponent) => opponent.id === id) ?? OPPONENTS[0];

export const roundTeams = (tournament: TournamentState, round: number) =>
  round === 0 ? tournament.teams : tournament.winners[round - 1] ?? [];

export function playerOpponentId(tournament: TournamentState) {
  if (tournament.eliminated || tournament.round > 2) return null;
  const teams = roundTeams(tournament, tournament.round);
  const index = teams.indexOf(PLAYER_TEAM_ID);
  if (index < 0) return null;
  return teams[index % 2 === 0 ? index + 1 : index - 1] ?? null;
}

const ratingOf = (id: string, playerOvr: number) =>
  id === PLAYER_TEAM_ID ? playerOvr : findOpponent(id).rating;

function simulateTie(home: string, away: string, playerOvr: number) {
  const homeChance = 1 / (1 + 10 ** ((ratingOf(away, playerOvr) - ratingOf(home, playerOvr)) / 22));
  const homeWins = Math.random() < homeChance;
  const suddenDeath = Math.random() < 0.18;
  const winnerGoals = suddenDeath ? 6 + Math.floor(Math.random() * 2) : 3 + Math.floor(Math.random() * 3);
  const loserGoals = suddenDeath ? winnerGoals - 1 : Math.max(0, winnerGoals - 1 - Math.floor(Math.random() * 2));
  return {
    winner: homeWins ? home : away,
    score: homeWins ? `${winnerGoals}-${loserGoals}` : `${loserGoals}-${winnerGoals}`,
  };
}

function playRound(tournament: TournamentState, playerOvr: number, result?: TieResult): TournamentState {
  const round = tournament.round;
  const teams = roundTeams(tournament, round);
  const winners: string[] = [];
  const scores: string[] = [];

  for (let index = 0; index < teams.length; index += 2) {
    const home = teams[index];
    const away = teams[index + 1];
    if (result && (home === PLAYER_TEAM_ID || away === PLAYER_TEAM_ID)) {
      const playerHome = home === PLAYER_TEAM_ID;
      winners.push(result.won ? PLAYER_TEAM_ID : playerHome ? away : home);
      scores.push(
        playerHome ? `${result.playerScore}-${result.opponentScore}` : `${result.opponentScore}-${result.playerScore}`,
      );
    } else {
      const tie = simulateTie(home, away, playerOvr);
      winners.push(tie.winner);
      scores.push(tie.score);
    }
  }

  return {
    ...tournament,
    round: round + 1,
    winners: [...tournament.winners.slice(0, round), winners],
    scores: [...tournament.scores.slice(0, round), scores],
  };
}

/** Records the player's tie, simulates the other ties, and finishes the cup if the player is knocked out. */
export function resolveTournamentRound(tournament: TournamentState, result: TieResult, playerOvr: number) {
  let next = playRound(tournament, playerOvr, result);
  if (!result.won) {
    next = { ...next, eliminated: true };
    while (next.round < 3) next = playRound(next, playerOvr);
    return next;
  }
  if (tournament.round === 2) next = { ...next, titles: tournament.titles + 1 };
  return next;
}
