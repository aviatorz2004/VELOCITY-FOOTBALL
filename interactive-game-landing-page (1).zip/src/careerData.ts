import type { KeeperStyle, Opponent, StrikerStyle } from "./gameData";

export type CareerMatchType = "friendly" | "penalty";
export type RegionId =
  | "europe1"
  | "europe2"
  | "europe3"
  | "africa"
  | "americas"
  | "southAmerica"
  | "asia"
  | "middleEast"
  | "oceania";

export interface Nation {
  code: string; // ISO 3166-1 alpha-2, used for the flag
  name: string;
  short: string;
  rating: number;
  kit: string; // shirt colour used in matches
  keeperStyle: KeeperStyle;
  strikerStyle: StrikerStyle;
}

export interface Region {
  id: RegionId;
  name: string;
  subtitle: string;
  nationCount: 9 | 11 | 13;
  nations: Nation[];
}

const n = (
  code: string,
  name: string,
  short: string,
  rating: number,
  kit: string,
  keeperStyle: KeeperStyle,
  strikerStyle: StrikerStyle,
): Nation => ({ code, name, short, rating, kit, keeperStyle, strikerStyle });

export const REGIONS: Region[] = [
  {
    id: "europe1",
    name: "EUROPE 1",
    subtitle: "Western Europe's elite football nations",
    nationCount: 13,
    nations: [
      n("FR", "France", "FRA", 88, "#2c4fd8", "acrobat", "placement"),
      n("DE", "Germany", "GER", 86, "#f2f2ee", "wall", "power"),
      n("ES", "Spain", "ESP", 87, "#d4252b", "reader", "placement"),
      n("IT", "Italy", "ITA", 85, "#2f73d6", "wall", "deceiver"),
      n("PT", "Portugal", "POR", 86, "#c8102e", "acrobat", "power"),
      n("NL", "Netherlands", "NED", 84, "#ff7f00", "reader", "placement"),
      n("BE", "Belgium", "BEL", 83, "#e30613", "wall", "power"),
      n("HR", "Croatia", "CRO", 82, "#f4f4f4", "reader", "deceiver"),
      n("CH", "Switzerland", "SUI", 80, "#e2001a", "wall", "placement"),
      n("GB-ENG", "England", "ENG", 89, "#f4f4f4", "reader", "power"),
      n("GB-SCT", "Scotland", "SCO", 78, "#1b3c8c", "wall", "power"),
      n("IS", "Iceland", "ISL", 75, "#02529c", "wall", "power"),
      n("IE", "Ireland", "IRL", 76, "#169b62", "reader", "placement"),
    ],
  },
  {
    id: "europe2",
    name: "EUROPE 2",
    subtitle: "Northern, central and eastern Europe",
    nationCount: 11,
    nations: [
      n("DK", "Denmark", "DEN", 81, "#c8102e", "reader", "placement"),
      n("SE", "Sweden", "SWE", 78, "#fecc02", "wall", "power"),
      n("NO", "Norway", "NOR", 79, "#ba0c2f", "acrobat", "power"),
      n("PL", "Poland", "POL", 78, "#f4f4f4", "wall", "power"),
      n("AT", "Austria", "AUT", 79, "#ed2939", "reader", "deceiver"),
      n("RS", "Serbia", "SRB", 78, "#c6363c", "acrobat", "power"),
      n("TR", "Turkey", "TUR", 79, "#e30a17", "acrobat", "deceiver"),
      n("UA", "Ukraine", "UKR", 78, "#ffd500", "reader", "placement"),
      n("CZ", "Czechia", "CZE", 77, "#d7141a", "wall", "placement"),
      n("HU", "Hungary", "HUN", 79, "#cd2a3e", "reader", "placement"),
      n("RO", "Romania", "ROU", 77, "#002b7f", "wall", "power"),
    ],
  },
  {
    id: "africa",
    name: "AFRICA",
    subtitle: "The heartbeat of Velocity Football",
    nationCount: 13,
    nations: [
      n("ZA", "South Africa", "RSA", 76, "#ffb612", "reader", "placement"),
      n("KE", "Kenya", "KEN", 72, "#bb0000", "wall", "power"),
      n("TZ", "Tanzania", "TAN", 71, "#1eb53a", "acrobat", "deceiver"),
      n("NG", "Nigeria", "NGA", 82, "#008751", "acrobat", "power"),
      n("GH", "Ghana", "GHA", 79, "#f4f4f4", "reader", "placement"),
      n("EG", "Egypt", "EGY", 80, "#ce1126", "wall", "deceiver"),
      n("MA", "Morocco", "MAR", 84, "#c1272d", "reader", "placement"),
      n("SN", "Senegal", "SEN", 83, "#00853f", "acrobat", "power"),
      n("CM", "Cameroon", "CMR", 78, "#007a5e", "wall", "power"),
      n("CI", "Ivory Coast", "CIV", 80, "#ff8200", "acrobat", "power"),
      n("UG", "Uganda", "UGA", 70, "#fcdc04", "wall", "power"),
      n("DZ", "Algeria", "ALG", 81, "#006633", "reader", "deceiver"),
      n("TN", "Tunisia", "TUN", 77, "#e70013", "wall", "placement"),
    ],
  },
  {
    id: "americas",
    name: "AMERICAS",
    subtitle: "North America and the Caribbean",
    nationCount: 9,
    nations: [
      n("MX", "Mexico", "MEX", 80, "#006847", "acrobat", "placement"),
      n("US", "United States", "USA", 80, "#f4f4f4", "wall", "power"),
      n("CA", "Canada", "CAN", 77, "#d80621", "reader", "power"),
      n("JM", "Jamaica", "JAM", 74, "#009b3a", "acrobat", "power"),
      n("CR", "Costa Rica", "CRC", 75, "#ce1126", "wall", "placement"),
      n("PA", "Panama", "PAN", 73, "#da121a", "wall", "power"),
      n("HN", "Honduras", "HON", 71, "#0073cf", "reader", "power"),
      n("CU", "Cuba", "CUB", 68, "#cf142b", "wall", "placement"),
      n("TT", "Trinidad and Tobago", "TRI", 70, "#ce1126", "acrobat", "power"),
    ],
  },
  {
    id: "asia",
    name: "ASIA",
    subtitle: "East, Southeast and Central Asia",
    nationCount: 11,
    nations: [
      n("JP", "Japan", "JPN", 82, "#1c3faa", "reader", "placement"),
      n("KR", "South Korea", "KOR", 81, "#cd2e3a", "acrobat", "power"),
      n("CN", "China", "CHN", 72, "#de2910", "wall", "power"),
      n("TH", "Thailand", "THA", 70, "#241d4f", "reader", "placement"),
      n("VN", "Vietnam", "VIE", 69, "#da251d", "acrobat", "deceiver"),
      n("ID", "Indonesia", "IDN", 70, "#ce1126", "wall", "power"),
      n("MY", "Malaysia", "MAS", 69, "#f4f4f4", "reader", "placement"),
      n("IN", "India", "IND", 68, "#ff9933", "wall", "power"),
      n("KZ", "Kazakhstan", "KAZ", 71, "#00afca", "reader", "power"),
      n("UZ", "Uzbekistan", "UZB", 73, "#0099b5", "wall", "placement"),
      n("PH", "Philippines", "PHI", 67, "#0038a8", "acrobat", "power"),
    ],
  },
  {
    id: "europe3",
    name: "EUROPE 3",
    subtitle: "Southern Europe and the Balkans",
    nationCount: 9,
    nations: [
      n("GR", "Greece", "GRE", 77, "#0d5eaf", "wall", "placement"),
      n("BG", "Bulgaria", "BUL", 73, "#00966e", "wall", "power"),
      n("SI", "Slovenia", "SVN", 75, "#f4f4f4", "reader", "placement"),
      n("SK", "Slovakia", "SVK", 76, "#0b4ea2", "wall", "power"),
      n("BA", "Bosnia and Herzegovina", "BIH", 75, "#002395", "reader", "power"),
      n("ME", "Montenegro", "MNE", 72, "#c40308", "acrobat", "power"),
      n("MK", "North Macedonia", "MKD", 71, "#d20000", "wall", "placement"),
      n("AL", "Albania", "ALB", 74, "#e41e20", "reader", "deceiver"),
      n("FI", "Finland", "FIN", 75, "#f4f4f4", "wall", "power"),
    ],
  },
  {
    id: "southAmerica",
    name: "SOUTH AMERICA",
    subtitle: "CONMEBOL's football heartland",
    nationCount: 9,
    nations: [
      n("BR", "Brazil", "BRA", 89, "#ffdf00", "acrobat", "deceiver"),
      n("AR", "Argentina", "ARG", 90, "#75aadb", "reader", "placement"),
      n("UY", "Uruguay", "URU", 83, "#5cbfeb", "wall", "power"),
      n("CO", "Colombia", "COL", 82, "#fcd116", "acrobat", "deceiver"),
      n("CL", "Chile", "CHI", 78, "#d52b1e", "wall", "deceiver"),
      n("EC", "Ecuador", "ECU", 79, "#ffdd00", "reader", "power"),
      n("PE", "Peru", "PER", 77, "#d91023", "wall", "placement"),
      n("VE", "Venezuela", "VEN", 74, "#800020", "reader", "power"),
      n("PY", "Paraguay", "PAR", 76, "#d52b1e", "wall", "power"),
    ],
  },
  {
    id: "middleEast",
    name: "MIDDLE EAST",
    subtitle: "West Asia and the Arabian peninsula",
    nationCount: 9,
    nations: [
      n("SA", "Saudi Arabia", "KSA", 76, "#f4f4f4", "wall", "placement"),
      n("IR", "Iran", "IRN", 78, "#f4f4f4", "wall", "power"),
      n("QA", "Qatar", "QAT", 74, "#8a1538", "acrobat", "deceiver"),
      n("AE", "United Arab Emirates", "UAE", 73, "#f4f4f4", "reader", "deceiver"),
      n("IQ", "Iraq", "IRQ", 74, "#007a3d", "acrobat", "power"),
      n("JO", "Jordan", "JOR", 72, "#ce1126", "wall", "placement"),
      n("KW", "Kuwait", "KUW", 69, "#007a3d", "wall", "power"),
      n("OM", "Oman", "OMA", 70, "#db161b", "reader", "placement"),
      n("BH", "Bahrain", "BHR", 69, "#ce1126", "acrobat", "power"),
    ],
  },
  {
    id: "oceania",
    name: "OCEANIA",
    subtitle: "Pacific nations and island football",
    nationCount: 9,
    nations: [
      n("AU", "Australia", "AUS", 79, "#ffcd00", "reader", "power"),
      n("NZ", "New Zealand", "NZL", 75, "#f4f4f4", "wall", "power"),
      n("FJ", "Fiji", "FIJ", 66, "#68bfe5", "acrobat", "power"),
      n("PG", "Papua New Guinea", "PNG", 64, "#ce1126", "wall", "placement"),
      n("SB", "Solomon Islands", "SOL", 63, "#215b33", "wall", "power"),
      n("VU", "Vanuatu", "VAN", 62, "#d21034", "reader", "placement"),
      n("NC", "New Caledonia", "NCL", 65, "#009543", "acrobat", "power"),
      n("WS", "Samoa", "SAM", 60, "#ce1126", "wall", "power"),
      n("TO", "Tonga", "TGA", 59, "#c10000", "reader", "placement"),
    ],
  },
];

export interface Formation {
  id: string;
  name: string; // e.g. "4-3-3"
  lines: number[]; // outfield lines from defence to attack; always sums to 10
  style: string;
}

export const FORMATIONS: Formation[] = [
  { id: "433", name: "4-3-3", lines: [4, 3, 3], style: "Balanced attack with wide forwards" },
  { id: "442", name: "4-4-2", lines: [4, 4, 2], style: "Classic, compact and reliable" },
  { id: "4231", name: "4-2-3-1", lines: [4, 2, 3, 1], style: "Double pivot, creative number 10" },
  { id: "352", name: "3-5-2", lines: [3, 5, 2], style: "Controls midfield with wing-backs" },
  { id: "343", name: "3-4-3", lines: [3, 4, 3], style: "All-out pressing and attack" },
  { id: "451", name: "4-5-1", lines: [4, 5, 1], style: "Midfield overload, quick counters" },
  { id: "532", name: "5-3-2", lines: [5, 3, 2], style: "Solid back five, direct strikers" },
  { id: "541", name: "5-4-1", lines: [5, 4, 1], style: "Park the bus, hit on the break" },
];

export const CUSTOM_LIMITS = { defenders: [1, 6], midfielders: [1, 6], forwards: [1, 5] } as const;

export const formationName = (lines: number[]) => lines.join("-");

/** Attack/defence strength derived from the shape. Midfielders count half towards each. */
export function formationProfile(lines: number[]) {
  const defenders = lines[0] ?? 4;
  const forwards = lines.length > 1 ? lines[lines.length - 1] : 2;
  const midfielders = 10 - defenders - forwards;
  const attack = forwards + midfielders * 0.5;
  const defence = defenders + midfielders * 0.5;
  return {
    attack: attack / 4.5, // 4-3-3 baseline ≈ 1.0
    defence: defence / 5.5,
    control: midfielders / 3.5,
    defenders,
    midfielders,
    forwards,
  };
}

export const randomFormation = () => FORMATIONS[Math.floor(Math.random() * FORMATIONS.length)];

export function nationToOpponent(nation: Nation): Opponent {
  const keeperNames: Record<KeeperStyle, string> = { reader: "The Reader", acrobat: "The Acrobat", wall: "The Wall" };
  return {
    id: `nation-${nation.code.toLowerCase()}`,
    club: nation.name,
    short: nation.short,
    captain: `${nation.name} captain`,
    keeper: keeperNames[nation.keeperStyle],
    keeperStyle: nation.keeperStyle,
    strikerStyle: nation.strikerStyle,
    rating: nation.rating,
    reward: 300 + Math.max(0, nation.rating - 70) * 15,
    color: nation.kit,
    description: `${nation.name} national team.`,
  };
}
