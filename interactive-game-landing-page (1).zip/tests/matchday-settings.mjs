import assert from "node:assert/strict";
import { mkdirSync } from "node:fs";

// Run against the dev or production server with Playwright installed in the test environment.
const { chromium } = await import(process.env.PLAYWRIGHT_MODULE ?? "playwright");
const baseUrl = process.env.TEST_URL ?? "http://localhost:5173";
const browser = await chromium.launch({ headless: true, args: ["--no-sandbox"] });
const errors = [];
mkdirSync(".screenshots", { recursive: true });

const STADIUMS = [
  { name: "Uhuru Arena", price: 0, id: "uhuru-arena" },
  { name: "Kilimani Park", price: 15000, id: "kilimani-park" },
  { name: "Atlantic Stadium", price: 25000, id: "atlantic-stadium" },
  { name: "Metro Ground", price: 40000, id: "metro-ground" },
  { name: "Neon Arena", price: 60000, id: "neon-arena" },
  { name: "Nile Arena", price: 85000, id: "nile-arena" },
];
const fmt = (n) => n.toLocaleString("en-US");

/** Opens the app past the title screen. `save` and `prefs` seed browser storage before the app starts. */
async function makePage({ save = {}, prefs, ...options } = {}) {
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 }, ...options });
  await context.addInitScript(({ save, prefs }) => {
    if (!localStorage.getItem("afrokick-save")) {
      localStorage.setItem("afrokick-save", JSON.stringify({
        profile: { completed: true, name: "Denise McGregor", club: "Velocity FC", number: 9, position: "FWD", accountId: "VF-123456" },
        ...save,
      }));
    }
    if (prefs && !localStorage.getItem("afrokick-match-preferences")) {
      localStorage.setItem("afrokick-match-preferences", JSON.stringify(prefs));
    }
    localStorage.setItem("afrokick-settings", JSON.stringify({ muted: true, reducedMotion: true }));
    window.matchdayEvents = [];
    window.addEventListener("afrokick:match-ready", (event) => window.matchdayEvents.push(event.detail));
  }, { save, prefs });
  const page = await context.newPage();
  page.on("pageerror", (error) => errors.push(error.message));
  page.setDefaultTimeout(10000);
  await page.goto(baseUrl, { waitUntil: "networkidle" });
  await page.getByRole("button", { name: "Velocity Football. Tap to continue.", exact: true }).click();
  await page.getByRole("button", { name: "GAME MODES", exact: true }).waitFor({ timeout: 25000 });
  await page.getByRole("button", { name: "GAME MODES", exact: true }).click();
  return { context, page };
}

async function openQuickPreview(page) {
  await page.locator(".mode-tile-quick").click();
  await page.locator(".quick-setup .apply-changes-btn").click();
  await page.getByRole("tab", { name: "MATCH SETTINGS", exact: true }).click();
}

const group = (page, name) => page.getByRole("radiogroup", { name, exact: true });
const stadiumCard = (page, name) => group(page, "Choose a stadium").getByRole("radio", { name: new RegExp(`^${name},`) });
const selectedVenue = (page) => group(page, "Choose a stadium").getByRole("radio", { checked: true });
const dialog = (page) => page.locator(".mdv-unlock");
const readSave = (page) => page.evaluate(() => JSON.parse(localStorage.getItem("afrokick-save")));
const wallet = async (page) => (await page.locator(".mdv-wallet b").textContent()).trim();
const lockedCount = (page) => page.locator(".mdv-stadium-card.is-locked").count();
const selectedName = async (page) => (await selectedVenue(page).getAttribute("aria-label")).split(",")[0];
const waitForSave = (page, predicate) => page.waitForFunction(predicate, null, { timeout: 5000 });

async function closeDialogWithEscape(page) {
  await page.keyboard.press("Escape");
  await dialog(page).waitFor({ state: "detached" });
}

async function buy(page, stadium) {
  await stadiumCard(page, stadium.name).click();
  await dialog(page).waitFor();
  await dialog(page).getByRole("button", { name: `UNLOCK FOR ${fmt(stadium.price)}`, exact: true }).click();
  await dialog(page).waitFor({ state: "detached" });
}

try {
  // ================= 1. A new player: one free venue, five locked, nothing spent by browsing =================
  {
    const { page, context } = await makePage();
    const saveBefore = await readSave(page);
    await openQuickPreview(page);

    assert.equal(await group(page, "Choose a stadium").getByRole("radio").count(), 6, "six stadiums");
    assert.equal(await group(page, "Match duration").getByRole("radio").count(), 5);
    assert.equal(await group(page, "Opponent difficulty").getByRole("radio").count(), 4);
    assert.equal(await lockedCount(page), 5, "five of six start locked");
    assert.equal(await selectedName(page), "Uhuru Arena", "the free venue starts selected");
    assert.equal(await page.locator(".mdv-tag.starter").count(), 1);
    assert.equal((await page.locator(".mdv-tag.starter").textContent()).trim(), "FREE STARTER");
    assert.deepEqual(await page.locator(".mdv-price").allTextContents(), ["15,000", "25,000", "40,000", "60,000", "85,000"]);
    assert.equal(await wallet(page), "12,480");
    assert((await page.locator(".mdv-owned-count").textContent()).includes("1 / 6 UNLOCKED"));
    assert.equal(await page.locator(".mdv-lock-badge").count(), 5, "every locked venue shows a padlock");
    assert((await stadiumCard(page, "Kilimani Park").getAttribute("aria-label")).includes("locked, 15,000 coins"));
    assert.equal(await page.getByRole("button", { name: "Unlock Nile Arena for 85,000 coins", exact: true }).count(), 1);

    // All six images load, including the venue that reuses existing artwork.
    const images = await page.locator(".mdv-stadium-image").evaluateAll((elements) =>
      Promise.all(elements.map((element) => new Promise((resolve) => {
        const image = new Image();
        image.onload = () => resolve(image.naturalWidth > 0);
        image.onerror = () => resolve(false);
        image.src = getComputedStyle(element).backgroundImage.slice(5, -2);
      }))));
    assert.equal(images.length, 6);
    assert(images.every(Boolean), "All six stadium images must load");

    await page.screenshot({ path: ".screenshots/stadiums-locked-desktop.png", fullPage: true });

    // Tapping a locked venue opens the purchase dialog and changes nothing.
    await stadiumCard(page, "Kilimani Park").click();
    await dialog(page).waitFor();
    assert.equal(await selectedName(page), "Uhuru Arena", "a locked venue is never selected");
    const text = await dialog(page).textContent();
    // A new player starts with 12,480 coins, which is 2,520 short of the cheapest venue.
    assert(text.includes("Unlock Kilimani Park?") && text.includes("12,480") && text.includes("15,000") && text.includes("2,520") && text.includes("Not enough"));
    assert.equal(await dialog(page).getByRole("button", { name: "UNLOCK FOR 15,000", exact: true }).isDisabled(), true);
    await closeDialogWithEscape(page);
    assert.equal(await page.locator(".matchday-screen").count(), 1, "Escape closes only the dialog, not the whole preview");
    assert.equal(await page.getByRole("tab", { name: "MATCH SETTINGS", exact: true }).getAttribute("aria-selected"), "true");

    await stadiumCard(page, "Metro Ground").click();
    await dialog(page).getByRole("button", { name: "NOT NOW", exact: true }).click();
    await dialog(page).waitFor({ state: "detached" });
    await stadiumCard(page, "Neon Arena").click();
    await page.locator(".mdv-unlock-backdrop").click({ position: { x: 8, y: 8 } });
    await dialog(page).waitFor({ state: "detached" });
    await page.getByRole("button", { name: "Unlock Nile Arena for 85,000 coins", exact: true }).click();
    await dialog(page).waitFor();
    await closeDialogWithEscape(page);
    assert.deepEqual(await readSave(page), saveBefore, "cancelling never spends coins or unlocks anything");

    // Dragging the rail with the mouse over a locked card browses; it must not open a purchase.
    const track = page.locator(".mdv-stadium-track");
    // Tapping a venue reveals it, so earlier steps left the rail near the end. Start the arrow checks from the beginning.
    await track.evaluate((element) => { element.scrollLeft = 0; });
    await page.waitForFunction(() => !document.querySelector('[aria-label="Next stadiums"]').disabled);
    await page.getByRole("button", { name: "Next stadiums", exact: true }).click();
    await page.waitForFunction(() => document.querySelector(".mdv-stadium-track").scrollLeft > 20);
    await page.getByRole("button", { name: "Previous stadiums", exact: true }).click();
    await page.waitForFunction(() => document.querySelector(".mdv-stadium-track").scrollLeft < 5);
    const box = await track.boundingBox();
    await page.mouse.move(box.x + 700, box.y + 60);
    await page.mouse.down();
    await page.mouse.move(box.x + 200, box.y + 62, { steps: 14 });
    await page.mouse.up();
    await page.waitForTimeout(300);
    assert((await track.evaluate((element) => element.scrollLeft)) > 50, "dragging scrolls the rail");
    assert.equal(await dialog(page).count(), 0, "a drag over a locked card must not open the dialog");
    assert.equal(await selectedName(page), "Uhuru Arena");

    // Keyboard: arrows only move focus along the rail; Enter on a locked venue asks to buy it.
    await selectedVenue(page).focus();
    await page.keyboard.press("Home");
    assert((await page.evaluate(() => document.activeElement.getAttribute("aria-label"))).startsWith("Uhuru Arena"));
    await page.keyboard.press("ArrowRight");
    assert((await page.evaluate(() => document.activeElement.getAttribute("aria-label"))).startsWith("Kilimani Park"));
    assert.equal(await dialog(page).count(), 0, "arrow keys never open a purchase");
    assert.equal(await selectedName(page), "Uhuru Arena", "arrow keys never change the selection");
    await page.keyboard.press("Enter");
    await dialog(page).waitFor();
    await closeDialogWithEscape(page);
    await page.waitForFunction(() => document.activeElement?.getAttribute("aria-label")?.startsWith("Kilimani Park"));
    await page.keyboard.press("End");
    assert((await page.evaluate(() => document.activeElement.getAttribute("aria-label"))).startsWith("Nile Arena"));
    assert.deepEqual(await readSave(page), saveBefore, "keyboard browsing never spends coins");

    // The free venue can be re-selected and the rest of the settings still work.
    await stadiumCard(page, "Uhuru Arena").click();
    for (const minutes of [3, 5, 10, 15, 30]) {
      const radio = group(page, "Match duration").getByRole("radio", { name: `${minutes} minutes`, exact: true });
      await radio.click();
      assert.equal(await radio.getAttribute("aria-checked"), "true");
      assert.equal((await page.locator(".md-versus small").textContent()).trim(), `${minutes} MIN`);
    }
    for (const difficulty of ["Easy", "Medium", "Hard", "Very Hard"]) {
      const radio = group(page, "Opponent difficulty").getByRole("radio", { name: difficulty, exact: true });
      await radio.click();
      assert.equal(await radio.getAttribute("aria-checked"), "true");
    }
    await context.close();
    console.log("PASS 1: six venues, one free and five locked, prices, wallet, cancel/Escape/backdrop, drag and keyboard never charge.");
  }

  // ================= 2. Buying a venue: coins are spent once and the unlock is saved =================
  {
    const { page, context } = await makePage({ save: { coins: 100000 } });
    await openQuickPreview(page);
    await stadiumCard(page, "Atlantic Stadium").click();
    await dialog(page).waitFor();
    const affordable = await dialog(page).textContent();
    assert(affordable.includes("Unlock Atlantic Stadium?") && affordable.includes("100,000") && affordable.includes("25,000") && affordable.includes("75,000"));
    await page.waitForTimeout(400); // let the backdrop finish fading in so the picture shows the settled dialog
    await page.screenshot({ path: ".screenshots/unlock-dialog-desktop.png" });
    await closeDialogWithEscape(page);
    await buy(page, STADIUMS[2]); // Atlantic Stadium, 25,000

    assert.equal(await selectedName(page), "Atlantic Stadium", "a bought venue is selected straight away");
    assert.equal(await lockedCount(page), 4);
    assert.equal(await wallet(page), "75,000");
    assert((await page.locator(".mdv-owned-count").textContent()).includes("2 / 6 UNLOCKED"));
    assert((await page.locator(".matchday-toast").textContent()).includes("Atlantic Stadium unlocked"));
    await waitForSave(page, () => JSON.parse(localStorage.getItem("afrokick-save")).coins === 75000);
    let save = await readSave(page);
    assert.equal(save.coins, 100000 - 25000);
    assert.deepEqual(save.unlockedStadiums, ["uhuru-arena", "atlantic-stadium"]);
    assert.equal(await stadiumCard(page, "Atlantic Stadium").evaluate((el) => el.classList.contains("is-locked")), false);
    assert.equal(await page.locator(".mdv-tag.owned").count(), 1);

    // An owned venue switches instantly with no dialog, in both directions.
    await stadiumCard(page, "Uhuru Arena").click();
    assert.equal(await selectedName(page), "Uhuru Arena");
    await stadiumCard(page, "Atlantic Stadium").click();
    assert.equal(await dialog(page).count(), 0, "owned venues are never sold twice");
    assert.equal(await selectedName(page), "Atlantic Stadium");
    assert.equal((await readSave(page)).coins, 75000);

    // Lineup, formation and venue choices all survive switching tabs.
    await group(page, "Match duration").getByRole("radio", { name: "15 minutes", exact: true }).click();
    await group(page, "Opponent difficulty").getByRole("radio", { name: "Very Hard", exact: true }).click();
    await page.getByRole("tab", { name: "LINEUP & FORMATION", exact: true }).click();
    await page.getByRole("button", { name: "4-4-2", exact: true }).click();
    await page.locator(".pitch-chip:not(.gk)").first().click();
    await page.locator(".bench-row").filter({ has: page.locator(".pos-def") }).first().click();
    assert((await page.locator(".md-summary").textContent()).includes("1 SUBS"));
    await page.getByRole("tab", { name: "FULL SQUAD", exact: true }).click();
    assert.equal(await page.locator(".squad-row-wrap").count(), 25);
    await page.getByRole("tab", { name: "MATCH SETTINGS", exact: true }).click();
    assert.equal(await selectedName(page), "Atlantic Stadium");

    const saveBeforeKickOff = await readSave(page);
    await page.locator(".matchday-start").click();
    await page.locator(".modes-screen").waitFor();
    const result = await page.evaluate(() => ({
      handoff: JSON.parse(localStorage.getItem("afrokick-match-handoff")),
      event: window.matchdayEvents[0],
    }));
    assert.deepEqual(result.handoff.lineup.matchSettings, { stadiumId: "atlantic-stadium", durationMinutes: 15, opponentDifficulty: "very-hard" });
    assert.deepEqual(result.handoff.lineup.formation, [4, 4, 2]);
    assert.equal(result.handoff.lineup.startingXI.length, 11);
    assert.equal(result.handoff.lineup.bench.length, 14);
    assert.equal(result.handoff.stadium.sceneKey, "stadium_atlantic_stadium");
    assert.deepEqual(result.event, result.handoff);
    assert.deepEqual(await readSave(page), saveBeforeKickOff, "kick-off never changes coins or unlocks");

    // Reload: the purchase, the balance and the venue choice are all still there.
    await page.reload({ waitUntil: "networkidle" });
    await page.getByRole("button", { name: "Velocity Football. Tap to continue.", exact: true }).click();
    await page.getByRole("button", { name: "GAME MODES", exact: true }).waitFor({ timeout: 25000 });
    await page.getByRole("button", { name: "GAME MODES", exact: true }).click();
    await openQuickPreview(page);
    assert.equal(await selectedName(page), "Atlantic Stadium");
    assert.equal(await lockedCount(page), 4);
    assert.equal(await wallet(page), "75,000");
    await context.close();
    console.log("PASS 2: purchase deducts coins once, selects the venue, survives tab changes, kick-off and a reload.");
  }

  // ================= 3. Double confirm cannot charge twice =================
  {
    const { page, context } = await makePage({ save: { coins: 100000 } });
    await openQuickPreview(page);
    await stadiumCard(page, "Metro Ground").click();
    await dialog(page).waitFor();
    await dialog(page).getByRole("button", { name: "UNLOCK FOR 40,000", exact: true }).evaluate((button) => { button.click(); button.click(); });
    await dialog(page).waitFor({ state: "detached" });
    await waitForSave(page, () => JSON.parse(localStorage.getItem("afrokick-save")).unlockedStadiums.includes("metro-ground"));
    const save = await readSave(page);
    assert.equal(save.coins, 100000 - 40000, "two rapid confirms charge exactly once");
    assert.deepEqual(save.unlockedStadiums, ["uhuru-arena", "metro-ground"]);
    await context.close();
    console.log("PASS 3: a double confirm charges once.");
  }

  // ================= 4. Not enough coins, and exactly enough coins =================
  {
    const poor = await makePage({ save: { coins: 1000 } });
    await openQuickPreview(poor.page);
    assert.equal(await wallet(poor.page), "1,000");
    assert((await poor.page.locator(".mdv-venue-state.is-short").first().textContent()).includes("NEED 14,000 MORE"));
    assert.equal(await poor.page.locator(".mdv-venue-state.is-short").count(), 5, "every venue is out of reach");
    await stadiumCard(poor.page, "Kilimani Park").click();
    await dialog(poor.page).waitFor();
    const confirm = dialog(poor.page).getByRole("button", { name: "UNLOCK FOR 15,000", exact: true });
    assert.equal(await confirm.isDisabled(), true, "cannot confirm without enough coins");
    const poorText = await dialog(poor.page).textContent();
    assert(poorText.includes("14,000") && poorText.includes("more coins") && poorText.includes("Not enough"));
    await poor.page.waitForTimeout(400);
    await poor.page.screenshot({ path: ".screenshots/unlock-dialog-short.png" });
    await confirm.click({ force: true }).catch(() => {});
    assert.equal(await dialog(poor.page).count(), 1, "a disabled confirm does nothing");
    await closeDialogWithEscape(poor.page);
    const poorSave = await readSave(poor.page);
    assert.equal(poorSave.coins, 1000);
    assert.deepEqual(poorSave.unlockedStadiums ?? ["uhuru-arena"], ["uhuru-arena"]);
    await poor.context.close();

    const exact = await makePage({ save: { coins: 15000 } });
    await openQuickPreview(exact.page);
    await buy(exact.page, STADIUMS[1]);
    assert.equal(await wallet(exact.page), "0");
    assert.equal(await selectedName(exact.page), "Kilimani Park");
    assert((await exact.page.locator(".mdv-venue-state.is-short").first().textContent()).includes("NEED 25,000 MORE"));
    await waitForSave(exact.page, () => JSON.parse(localStorage.getItem("afrokick-save")).coins === 0);
    await exact.context.close();
    console.log("PASS 4: short of coins is blocked with the exact shortfall; exactly enough buys and leaves zero.");
  }

  // ================= 5. Old or damaged saves can never lock a player out or hand out venues =================
  {
    const legacy = await makePage({ prefs: { stadiumId: "neon-arena", durationMinutes: 10, opponentDifficulty: "hard" } });
    await openQuickPreview(legacy.page);
    assert.equal(await selectedName(legacy.page), "Uhuru Arena", "a remembered venue the player does not own falls back to the free one");
    assert.equal(await stadiumCard(legacy.page, "Neon Arena").evaluate((el) => el.classList.contains("is-locked")), true);
    assert.equal(await group(legacy.page, "Match duration").getByRole("radio", { name: "10 minutes" }).getAttribute("aria-checked"), "true");
    await legacy.page.locator(".matchday-start").click();
    const handoff = await legacy.page.evaluate(() => JSON.parse(localStorage.getItem("afrokick-match-handoff")));
    assert.equal(handoff.lineup.matchSettings.stadiumId, "uhuru-arena", "a locked venue can never reach the match");
    assert.equal(await legacy.page.evaluate(() => JSON.parse(localStorage.getItem("afrokick-match-preferences")).stadiumId), "uhuru-arena");
    await legacy.context.close();

    const tampered = await makePage({ save: { coins: 100, unlockedStadiums: ["neon-arena", "bogus", 5, null, "neon-arena"] } });
    await openQuickPreview(tampered.page);
    assert.equal(await lockedCount(tampered.page), 4, "free venue plus the one valid owned venue, junk ignored");
    await stadiumCard(tampered.page, "Neon Arena").click();
    assert.equal(await selectedName(tampered.page), "Neon Arena", "an owned venue from the save is usable");
    await tampered.context.close();

    const empty = await makePage({ save: { unlockedStadiums: [] } });
    await openQuickPreview(empty.page);
    assert.equal(await selectedName(empty.page), "Uhuru Arena", "the free venue is always owned");
    await empty.context.close();
    console.log("PASS 5: unowned remembered venue falls back; junk in a save is ignored; the free venue is always owned.");
  }

  // ================= 6. Every venue can be bought and played =================
  {
    const { page, context } = await makePage({ save: { coins: 300000 } });
    await openQuickPreview(page);
    for (const stadium of STADIUMS.slice(1)) await buy(page, stadium);
    assert.equal(await lockedCount(page), 0);
    assert.equal(await wallet(page), fmt(300000 - 225000));
    assert((await page.locator(".mdv-owned-count").textContent()).includes("6 / 6 UNLOCKED"));
    for (const stadium of STADIUMS) {
      await stadiumCard(page, stadium.name).click();
      assert.equal(await selectedName(page), stadium.name);
    }
    await page.locator(".matchday-start").click();
    const handoff = await page.evaluate(() => JSON.parse(localStorage.getItem("afrokick-match-handoff")));
    assert.equal(handoff.lineup.matchSettings.stadiumId, "nile-arena");
    assert.equal(handoff.stadium.sceneKey, "stadium_nile_arena");
    const save = await readSave(page);
    assert.equal(save.coins, 75000);
    assert.equal(save.unlockedStadiums.length, 6);
    await context.close();
    console.log("PASS 6: all five paid venues can be bought (total 225,000), selected and handed to the match.");
  }

  // ================= 7. Career penalty route has the same locks =================
  {
    const career = await makePage();
    await career.page.locator(".mode-tile-career").click();
    await career.page.locator(".type-card").filter({ hasText: "PENALTY" }).click();
    await career.page.locator(".region-card").filter({ has: career.page.getByText("AFRICA", { exact: true }) }).click();
    await career.page.locator(".nation-card").filter({ hasText: "Tanzania" }).click();
    await career.page.locator(".nation-card").filter({ hasText: "Kenya" }).click();
    await career.page.locator(".career-setup .apply-changes-btn").click();
    await career.page.locator(".career-setup .apply-changes-btn").click();
    await career.page.getByRole("tab", { name: "MATCH SETTINGS", exact: true }).click();
    assert.equal(await group(career.page, "Choose a stadium").getByRole("radio").count(), 6);
    assert.equal(await lockedCount(career.page), 5);
    assert.equal((await career.page.locator(".md-versus small").textContent()).trim(), "5 ROUNDS");
    await group(career.page, "Match duration").getByRole("radio", { name: "3 minutes" }).click();
    await group(career.page, "Opponent difficulty").getByRole("radio", { name: "Easy", exact: true }).click();
    await career.page.locator(".matchday-start").click();
    const handoff = await career.page.evaluate(() => JSON.parse(localStorage.getItem("afrokick-match-handoff")));
    assert.equal(handoff.fixture.mode, "career");
    assert.equal(handoff.fixture.type, "penalty");
    assert.equal(handoff.lineup.matchSettings.stadiumId, "uhuru-arena");
    assert.equal(handoff.lineup.matchSettings.durationMinutes, 3);
    assert.equal(handoff.lineup.matchSettings.opponentDifficulty, "easy");
    await career.context.close();
    console.log("PASS 7: Career penalty preview shows the same locks and hands off the free venue.");
  }

  // ================= 8. Phone: swipe, dialog fits and covers the screen even when scrolled, no overflow =================
  {
    const mobile = await makePage({ save: { coins: 100000 }, viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 1 });
    const { page } = mobile;
    await openQuickPreview(page);
    const mobileTrack = page.locator(".mdv-stadium-track");
    await mobileTrack.scrollIntoViewIfNeeded();
    const bounds = await mobileTrack.boundingBox();
    const cdp = await mobile.context.newCDPSession(page);
    const sx = bounds.x + bounds.width - 25;
    const sy = bounds.y + 65;
    await cdp.send("Input.dispatchTouchEvent", { type: "touchStart", touchPoints: [{ x: sx, y: sy }] });
    for (let i = 1; i <= 10; i += 1) {
      await cdp.send("Input.dispatchTouchEvent", { type: "touchMove", touchPoints: [{ x: sx - i * 22, y: sy }] });
      await page.waitForTimeout(20);
    }
    await cdp.send("Input.dispatchTouchEvent", { type: "touchEnd", touchPoints: [] });
    await page.waitForTimeout(400);
    assert((await mobileTrack.evaluate((element) => element.scrollLeft)) > 50, "touch swipe moves the rail");
    assert.equal(await dialog(page).count(), 0, "a swipe never opens a purchase");
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth), false, "no horizontal overflow");
    await page.screenshot({ path: ".screenshots/stadiums-locked-mobile.png", fullPage: true });

    // The player has scrolled down the screen: the dialog must still be fully on screen.
    const scroller = page.locator(".matchday-screen");
    const room = await scroller.evaluate((el) => el.scrollHeight - el.clientHeight);
    assert(room > 120, `the phone layout must scroll (room ${room}px)`);
    await scroller.evaluate((el) => { el.scrollTop = 140; });
    assert((await scroller.evaluate((el) => el.scrollTop)) >= 120, "the matchday screen is scrolled down");
    await stadiumCard(page, "Kilimani Park").tap();
    await dialog(page).waitFor();
    const box = await dialog(page).boundingBox();
    const viewport = page.viewportSize();
    assert(box.x >= 0 && box.x + box.width <= viewport.width, "dialog fits the phone width");
    assert(box.y >= 0 && box.y + box.height <= viewport.height, "dialog is fully visible after scrolling");
    const confirm = dialog(page).getByRole("button", { name: "UNLOCK FOR 15,000", exact: true });
    const confirmBox = await confirm.boundingBox();
    assert(confirmBox.y + confirmBox.height <= viewport.height, "confirm button is on screen");
    await page.waitForTimeout(400);
    await page.screenshot({ path: ".screenshots/unlock-dialog-mobile.png" });
    await confirm.tap();
    await dialog(page).waitFor({ state: "detached" });
    assert.equal(await selectedName(page), "Kilimani Park");
    await group(page, "Match duration").getByRole("radio", { name: "10 minutes" }).tap();
    await group(page, "Opponent difficulty").getByRole("radio", { name: "Hard", exact: true }).tap();
    await page.locator(".matchday-start").tap();
    const handoff = await page.evaluate(() => JSON.parse(localStorage.getItem("afrokick-match-handoff")));
    assert.deepEqual(handoff.lineup.matchSettings, { stadiumId: "kilimani-park", durationMinutes: 10, opponentDifficulty: "hard" });
    await mobile.context.close();
    console.log("PASS 8: phone swipe, dialog visible after scrolling, purchase by tap and hand-off.");
  }

  assert.deepEqual(errors, [], "No browser runtime errors");
  console.log("All stadium unlock browser checks passed.");
} finally {
  await browser.close();
}
