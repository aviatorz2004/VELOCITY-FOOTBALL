import assert from "node:assert/strict";
import { mkdirSync } from "node:fs";

const { chromium } = await import(process.env.PLAYWRIGHT_MODULE ?? "playwright");
const baseURL = process.env.TEST_URL ?? "http://127.0.0.1:5173";
const browser = await chromium.launch({ headless: true, args: ["--no-sandbox"] });
const errors = [];
mkdirSync(".screenshots", { recursive: true });

async function openLoading({ returning = true, reducedMotion = false, ...contextOptions } = {}) {
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 }, ...contextOptions });
  await context.addInitScript(({ returning, reducedMotion }) => {
    localStorage.setItem("afrokick-settings", JSON.stringify({ muted: true, reducedMotion }));
    if (returning) {
      localStorage.setItem("afrokick-save", JSON.stringify({
        coins: 12480,
        unlockedStadiums: ["uhuru-arena"],
        profile: { completed: true, name: "Denise McGregor", club: "Velocity FC", number: 9, position: "FWD", accountId: "VF-123456" },
      }));
    }
  }, { returning, reducedMotion });
  const page = await context.newPage();
  page.on("pageerror", (error) => errors.push(error.message));
  await page.goto(baseURL, { waitUntil: "networkidle" });
  const saveBefore = await page.evaluate(() => localStorage.getItem("afrokick-save"));
  const startedAt = performance.now();
  await page.getByRole("button", { name: "Velocity Football. Tap to continue.", exact: true }).click();
  await page.getByRole("progressbar", { name: "Loading Velocity Football", exact: true }).waitFor();
  return { context, page, startedAt, saveBefore };
}

async function checkGeometry(page) {
  const result = await page.locator(".loading-screen").evaluate((screen) => {
    const bounds = screen.getBoundingClientRect();
    const rect = (selector) => screen.querySelector(selector).getBoundingClientRect();
    const topbar = rect(".loading-topbar");
    const banner = rect(".loading-venue-banner");
    const dock = rect(".loading-dock");
    const readout = rect(".loading-readout");
    const stepsWrap = rect(".loading-steps");
    const progress = rect(".loading-progress");
    const inside = (box) => box.left >= bounds.left - 1 && box.right <= bounds.right + 1 && box.top >= bounds.top - 1 && box.bottom <= bounds.bottom + 1;
    const steps = [...screen.querySelectorAll(".loading-steps > li")].map((li) => li.getBoundingClientRect());
    const readoutClearOfSteps = readout.right <= stepsWrap.left + 1 || readout.bottom <= stepsWrap.top + 1;
    const stepsHorizontal = steps.every((box, i) =>
      i === 0 || (box.left >= steps[i - 1].right - 1 && Math.abs(box.top - steps[0].top) <= 2),
    );
    return {
      contentInside: [topbar, banner, dock, readout, stepsWrap].every(inside),
      noOverlap: topbar.bottom <= banner.top + 1 && banner.bottom <= dock.top + 1 && readoutClearOfSteps,
      stepsHorizontal,
      progressHorizontal: progress.width > progress.height * 20,
      hasVerticalRail: Boolean(screen.querySelector(".loading-rail")),
      stepCount: steps.length,
      internalOverflow: screen.scrollHeight > screen.clientHeight + 1,
      horizontalOverflow: document.documentElement.scrollWidth > window.innerWidth,
    };
  });
  assert.equal(result.hasVerticalRail, false, "Vertical right sidebar must be gone");
  assert.equal(result.progressHorizontal, true, "Progress bar must span horizontally");
  assert.equal(result.stepsHorizontal, true, "Preparation steps must sit horizontally side-by-side");
  assert.equal(result.contentInside, true, "All loading elements should stay inside the screen");
  assert.equal(result.noOverlap, true, "Topbar, venue banner and bottom dock must not overlap");
  assert.equal(result.stepCount, 5, "All five preparation stages stay visible");
  assert.equal(result.internalOverflow, false, "Loading screen should not clip or scroll its content");
  assert.equal(result.horizontalOverflow, false, "Loading screen must not overflow the page horizontally");
}

try {
  // Real wall-clock check: the loading page must last 20 seconds, show all five slides, and go home.
  const desktop = await openLoading();
  const { page } = desktop;
  await page.waitForTimeout(1200);
  await checkGeometry(page);
  assert.equal(await page.locator(".loading-bg-slide").count(), 5);
  assert.equal(await page.locator(".loading-spinner-comet").isVisible(), true);
  assert.equal(await page.locator(".loading-scene-pill, .loading-tip-card, .spinner-core").count(), 0, "No detached panels or duplicate loading displays");
  // The loading page must not advertise a stage count or an authored credit line.
  assert.equal((await page.locator(".loading-screen").textContent()).match(/CREATED BY|SCENE 0/i), null, "No scene counter or credit line on the loading page");

  const imagesLoaded = await page.locator(".loading-bg-slide").evaluateAll((slides) =>
    Promise.all(slides.map((slide) => new Promise((resolve) => {
      const image = new Image();
      image.onload = () => resolve(image.naturalWidth > 0);
      image.onerror = () => resolve(false);
      image.src = getComputedStyle(slide).backgroundImage.slice(5, -2);
    }))));
  assert(imagesLoaded.every(Boolean), "All background photographs must load");

  await page.keyboard.press("Enter");
  await page.keyboard.press("Space");
  await page.keyboard.press("Escape");
  assert.equal(await page.locator(".loading-screen").count(), 1, "Key presses must not skip loading");
  assert.equal(await page.locator(".home-view, .floating-help, .register-screen").count(), 0, "Other screens should remain hidden while loading");

  const slidesSeen = [];
  let previousProgress = -1;
  for (const [index, id] of ["arena", "training", "knockout", "arena-night", "champions"].entries()) {
    const targetMs = 1700 + index * 4000;
    const waitMs = targetMs - (performance.now() - desktop.startedAt);
    if (waitMs > 0) await page.waitForTimeout(waitMs);
    const current = await page.locator(".loading-bg-slide.is-active").getAttribute("data-slide");
    assert.equal(current, id);
    slidesSeen.push(current);
    const progress = Number(await page.getByRole("progressbar", { name: "Loading Velocity Football", exact: true }).getAttribute("aria-valuenow"));
    assert(progress > previousProgress && progress < 100, "Progress increases without reaching 100 before 20 seconds");
    previousProgress = progress;
    if (id === "knockout") await page.screenshot({ path: ".screenshots/loading-desktop-final.png", fullPage: true });
  }
  await page.locator(".home-view").waitFor({ timeout: 6000 });
  const realDuration = performance.now() - desktop.startedAt;
  assert(realDuration >= 19800 && realDuration < 23000, `Expected 20 seconds, got ${realDuration}ms`);
  assert.equal(await page.evaluate(() => localStorage.getItem("afrokick-save")), desktop.saveBefore, "Loading must never change the save");
  await page.getByRole("button", { name: "GAME MODES", exact: true }).click();
  await page.locator(".modes-screen").waitFor();
  await desktop.context.close();
  console.log(`PASS: ${(realDuration / 1000).toFixed(2)}s transition to home, all five photos (${slidesSeen.join(", ")}), increasing progress, normal navigation and unchanged save.`);

  // First-time players must still reach registration, rather than bypass it.
  const firstTime = await openLoading({ returning: false });
  await firstTime.page.locator(".register-screen").waitFor({ timeout: 24000 });
  assert(performance.now() - firstTime.startedAt >= 19800);
  assert.equal(await firstTime.page.locator(".home-view").count(), 0);
  await firstTime.context.close();
  console.log("PASS: first-time players reach registration after loading.");

  // Check both portrait and short landscape layouts, including a 320px-wide phone.
  for (const [name, viewport] of [
    ["phone", { width: 390, height: 844 }],
    ["narrow-phone", { width: 320, height: 700 }],
    ["tablet", { width: 768, height: 1024 }],
    ["short-desktop", { width: 1024, height: 600 }],
    ["landscape", { width: 844, height: 390 }],
  ]) {
    const responsive = await openLoading({ viewport });
    await responsive.page.waitForTimeout(1300);
    await checkGeometry(responsive.page);
    await responsive.page.screenshot({ path: `.screenshots/loading-${name}-final.png`, fullPage: true });
    await responsive.context.close();
    console.log(`PASS: ${name} ${viewport.width}x${viewport.height}, no overlap or overflow.`);
  }

  // Honour both the in-game reduced motion option and the system preference.
  for (const options of [{ reducedMotion: true }, { reducedMotion: "reduce" }]) {
    // The context option uses the same name as the saved setting, so handle the OS case separately.
    const test = typeof options.reducedMotion === "boolean"
      ? await openLoading({ reducedMotion: true })
      : await openLoading();
    if (typeof options.reducedMotion === "string") await test.page.emulateMedia({ reducedMotion: "reduce" });
    const motion = await test.page.locator(".loading-spinner-comet").evaluate((spinner) => ({
      spin: getComputedStyle(spinner).animationName,
      image: getComputedStyle(document.querySelector(".loading-bg-slide.is-active")).transform,
    }));
    assert.equal(motion.spin, "none");
    assert.equal(motion.image, "none");
    const before = Number(await test.page.getByRole("progressbar").getAttribute("aria-valuenow"));
    await test.page.waitForTimeout(500);
    const after = Number(await test.page.getByRole("progressbar").getAttribute("aria-valuenow"));
    assert(after > before, "Reduced motion must not stop loading progress");
    await test.context.close();
  }
  console.log("PASS: in-game and system reduced motion work without stopping the timer.");

  assert.deepEqual(errors, [], "No browser runtime errors");
  console.log("All loading screen checks passed.");
} finally {
  await browser.close();
}